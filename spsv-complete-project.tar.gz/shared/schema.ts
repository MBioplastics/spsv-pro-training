import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  role: text("role").default("user").notNull(),
  vehicleType: text("vehicle_type").default("taxi").notNull(), // Default to taxi if not specified
  createdAt: timestamp("created_at").defaultNow().notNull(),
  stripeCustomerId: text("stripe_customer_id"),
  hasPurchased: boolean("has_purchased").default(false),
});

export const trainingProgress = pgTable("training_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  moduleId: integer("module_id").notNull(),
  vehicleType: text("vehicle_type").notNull(),
  progress: integer("progress").default(0).notNull(),
  isCompleted: boolean("is_completed").default(false).notNull(),
  lastAccessed: timestamp("last_accessed").defaultNow().notNull(),
});

export const practiceTests = pgTable("practice_tests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  testType: text("test_type").notNull(),
  vehicleType: text("vehicle_type").notNull(),
  score: integer("score").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  dateTaken: timestamp("date_taken").defaultNow().notNull(),
});

export const checklists = pgTable("checklists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  checklistType: text("checklist_type").notNull(),
  vehicleType: text("vehicle_type"),
  items: json("items").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  documentType: text("document_type").notNull(),
  fileName: text("file_name").notNull(),
  uploadDate: timestamp("upload_date").defaultNow().notNull(),
  expiryDate: timestamp("expiry_date"),
  status: text("status").default("pending").notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  fullName: true,
  vehicleType: true,
});

export const insertTrainingProgressSchema = createInsertSchema(trainingProgress).pick({
  userId: true,
  moduleId: true,
  vehicleType: true,
  progress: true,
  isCompleted: true,
});

export const insertPracticeTestSchema = createInsertSchema(practiceTests).pick({
  userId: true,
  testType: true,
  vehicleType: true,
  score: true,
  totalQuestions: true,
});

export const insertChecklistSchema = createInsertSchema(checklists).pick({
  userId: true,
  checklistType: true,
  vehicleType: true,
  items: true,
});

export const insertDocumentSchema = createInsertSchema(documents).pick({
  userId: true,
  documentType: true,
  fileName: true,
  expiryDate: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTrainingProgress = z.infer<typeof insertTrainingProgressSchema>;
export type TrainingProgress = typeof trainingProgress.$inferSelect;

export type InsertPracticeTest = z.infer<typeof insertPracticeTestSchema>;
export type PracticeTest = typeof practiceTests.$inferSelect;

export type InsertChecklist = z.infer<typeof insertChecklistSchema>;
export type Checklist = typeof checklists.$inferSelect;

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

// Auth schemas
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export type LoginInput = z.infer<typeof loginSchema>;
