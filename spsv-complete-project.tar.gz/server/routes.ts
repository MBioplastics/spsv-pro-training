import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import express from "express";
import { storage } from "./storage";
import { loginSchema, insertUserSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import Stripe from "stripe";
import { PRICING_PLANS, LICENSE_DURATIONS } from "../client/src/lib/constants";
import session from "express-session";
import MemoryStore from "memorystore";
import { sendRegistrationConfirmation, sendPaymentConfirmation, sendEmail, sendAdminPurchaseNotification } from "./email";
import { ntaMonitor } from "./nta-monitor";

// Extend express-session with our custom properties
declare module 'express-session' {
  interface SessionData {
    userId?: number;
  }
}

const MemoryStoreSession = MemoryStore(session);

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing STRIPE_SECRET_KEY environment variable. Payment functionality requires a valid secret key.');
}

// Verify the key format - accept both secret keys (sk_) and restricted keys (rk_)
if (!process.env.STRIPE_SECRET_KEY.startsWith('sk_') && !process.env.STRIPE_SECRET_KEY.startsWith('rk_')) {
  throw new Error('STRIPE_SECRET_KEY must be a secret key (starting with sk_) or restricted key (starting with rk_), not a publishable key.');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { 
  apiVersion: "2023-10-16" as any 
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session middleware
  app.use(session({
    secret: 'SPSV-training-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }, // 1 day
    store: new MemoryStoreSession({
      checkPeriod: 86400000 // prune expired entries every 24h
    })
  }));

  // SEO and indexing fixes
  app.get('/sitemap.xml', (req, res) => {
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${req.protocol}://${req.get('host')}/</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${req.protocol}://${req.get('host')}/pricing</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${req.protocol}://${req.get('host')}/training</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${req.protocol}://${req.get('host')}/practice-tests</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${req.protocol}://${req.get('host')}/vehicle-search</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
</urlset>`;
    
    res.set('Content-Type', 'application/xml');
    res.send(sitemap);
  });

  // Robots.txt for proper crawling
  app.get('/robots.txt', (req, res) => {
    const robots = `User-agent: *
Allow: /
Allow: /pricing
Allow: /training
Allow: /practice-tests
Allow: /vehicle-search

Disallow: /api/
Disallow: /dashboard
Disallow: /settings
Disallow: /checkout
Disallow: /login
Disallow: /register

Sitemap: ${req.protocol}://${req.get('host')}/sitemap.xml`;
    
    res.set('Content-Type', 'text/plain');
    res.send(robots);
  });

  // Handle redirects properly with 301 status
  app.get('/home', (req, res) => {
    res.redirect(301, '/');
  });

  app.get('/test', (req, res) => {
    res.redirect(301, '/practice-tests');
  });

  app.get('/tests', (req, res) => {
    res.redirect(301, '/practice-tests');
  });

  // Handle common incorrect URLs with proper redirects
  app.get('/index.html', (req, res) => {
    res.redirect(301, '/');
  });

  app.get('/index.php', (req, res) => {
    res.redirect(301, '/');
  });

  app.get('/main', (req, res) => {
    res.redirect(301, '/');
  });

  // API health check endpoint for monitoring
  app.get('/api/health', (req, res) => {
    res.status(200).json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      service: 'SPSV Pro Training API'
    });
  });

  // Handle successful payment processing
  async function handleSuccessfulPayment(paymentIntent: any) {
    try {
      const { metadata, amount, receipt_email } = paymentIntent;
      const planType = metadata?.planType;
      
      if (!planType || !PRICING_PLANS[planType as keyof typeof PRICING_PLANS]) {
        console.error('Invalid plan type in payment metadata:', planType);
        return;
      }

      const plan = PRICING_PLANS[planType as keyof typeof PRICING_PLANS];
      const amountInEur = (amount / 100).toFixed(2);

      // Send customer confirmation email
      if (receipt_email) {
        await sendPaymentConfirmation(
          receipt_email,
          'Customer',
          plan.name,
          `€${amountInEur}`,
          plan.duration
        );
      }

      // Send admin notification email
      const adminEmail = 'support@spsvprotraining.ie'; // Replace with your actual email
      await sendAdminPurchaseNotification({
        customerEmail: receipt_email || 'Unknown',
        planName: plan.name,
        amount: `€${amountInEur}`,
        paymentId: paymentIntent.id,
        timestamp: new Date().toISOString()
      });

      console.log(`Payment processed successfully: ${paymentIntent.id}`);
    } catch (error) {
      console.error('Error processing successful payment:', error);
    }
  }

  // Handle failed payment processing
  async function handleFailedPayment(paymentIntent: any) {
    try {
      const adminEmail = 'support@spsvprotraining.ie'; // Replace with your actual email
      await sendEmail({
        to: adminEmail,
        subject: 'SPSV Training - Payment Failed',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #dc2626;">Payment Failed Notification</h2>
            <p><strong>Payment ID:</strong> ${paymentIntent.id}</p>
            <p><strong>Amount:</strong> €${(paymentIntent.amount / 100).toFixed(2)}</p>
            <p><strong>Customer Email:</strong> ${paymentIntent.receipt_email || 'Unknown'}</p>
            <p><strong>Failure Reason:</strong> ${paymentIntent.last_payment_error?.message || 'Unknown'}</p>
            <p><strong>Time:</strong> ${new Date().toLocaleString()}</p>
          </div>
        `
      });
    } catch (error) {
      console.error('Error processing failed payment notification:', error);
    }
  }

  // Stripe webhook handler for payment notifications
  app.post('/api/stripe-webhook', async (req, res) => {
    const sig = req.headers['stripe-signature'] as string;
    let event;

    try {
      // For development, you can use a webhook secret from Stripe CLI
      // For production, set STRIPE_WEBHOOK_SECRET environment variable
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || 'whsec_development';
      event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } catch (err: any) {
      console.log(`Webhook signature verification failed.`, err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // Handle the event
    switch (event.type) {
      case 'payment_intent.succeeded':
        const paymentIntent = event.data.object;
        console.log('Payment succeeded:', paymentIntent.id);
        
        // Process the successful payment
        await handleSuccessfulPayment(paymentIntent);
        break;
      
      case 'payment_intent.payment_failed':
        const failedPayment = event.data.object;
        console.log('Payment failed:', failedPayment.id);
        
        // Handle failed payment
        await handleFailedPayment(failedPayment);
        break;
      
      default:
        console.log(`Unhandled event type ${event.type}`);
    }

    res.json({received: true});
  });

  // Handle 404s for API routes with proper JSON response
  app.use('/api/*', (req, res) => {
    res.status(404).json({
      error: 'API endpoint not found',
      path: req.path,
      method: req.method,
      timestamp: new Date().toISOString()
    });
  });
  // Auth routes
  app.post("/api/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(validatedData.username);
      
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(validatedData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      const user = await storage.createUser(validatedData);
      
      // Send registration confirmation email
      if (user.email) {
        try {
          await sendRegistrationConfirmation(user.email, user.username);
          console.log(`Registration confirmation email sent to ${user.email}`);
        } catch (emailError) {
          console.error("Failed to send registration email:", emailError);
          // Continue with registration even if email fails
        }
      }
      
      return res.status(201).json({ id: user.id, username: user.username });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      return res.status(500).json({ message: "Server error during registration" });
    }
  });

  app.post("/api/login", (req, res) => {
    try {
      console.log("Login attempt with:", req.body);
      
      // Perform simple validation without using zod for now
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      // Directly check against our test credentials
      if (username === "testuser" && password === "password123") {
        console.log("Login successful for testuser");
        
        if (req.session) {
          req.session.userId = 2; // Hardcoded for testuser
        }
        
        return res.status(200).json({
          id: 2,
          username: "testuser",
          hasPurchased: false
        });
      }
      
      // Try looking up the user in storage
      return storage.getUserByUsername(username)
        .then(user => {
          if (!user || user.password !== password) {
            return res.status(401).json({ message: "Invalid username or password" });
          }
          
          console.log("Login successful for:", user.username);
          
          if (req.session) {
            req.session.userId = user.id;
          }
          
          return res.status(200).json({
            id: user.id,
            username: user.username,
            hasPurchased: user.hasPurchased
          });
        })
        .catch(err => {
          console.error("Storage error:", err);
          return res.status(500).json({ message: "Error retrieving user" });
        });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Server error during login" });
    }
  });

  app.get("/api/logout", (req, res) => {
    req.session!.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Password reset route
  app.post("/api/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }

      // Check if user exists
      const user = await storage.getUserByEmail(email);
      if (!user) {
        // Return success even if user doesn't exist for security
        return res.status(200).json({ message: "Password reset email sent if account exists" });
      }

      // Send password reset email
      try {
        const { sendEmail } = await import("./email");
        await sendEmail({
          to: email,
          subject: "SPSV Pro Training - Password Reset",
          html: `
            <h2>Password Reset Request</h2>
            <p>Hello ${user.username},</p>
            <p>You requested a password reset for your SPSV Pro Training account.</p>
            <p>For security reasons, please contact our support team at support@spsvprotraining.ie to reset your password.</p>
            <p>If you didn't request this reset, please ignore this email.</p>
            <br>
            <p>Best regards,<br>SPSV Pro Training Team</p>
          `
        });
      } catch (emailError) {
        console.error("Failed to send password reset email:", emailError);
        return res.status(500).json({ message: "Failed to send password reset email" });
      }

      return res.status(200).json({ message: "Password reset email sent if account exists" });
    } catch (error) {
      console.error("Password reset error:", error);
      return res.status(500).json({ message: "Server error during password reset" });
    }
  });

  app.get("/api/user", async (req, res) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      return res.status(200).json({
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        hasPurchased: user.hasPurchased,
        vehicleType: user.vehicleType
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error fetching user data" });
    }
  });

  // Training progress routes
  app.get("/api/training/progress", async (req, res) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Check if user has purchased access
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!user.hasPurchased) {
        return res.status(403).json({ message: "Access denied. Please purchase a subscription to access training materials." });
      }

      const progress = await storage.getTrainingProgressByUserId(req.session.userId);
      return res.status(200).json(progress);
    } catch (error) {
      return res.status(500).json({ message: "Server error fetching training progress" });
    }
  });

  app.post("/api/training/progress", async (req, res) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Check if user has purchased access
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!user.hasPurchased) {
        return res.status(403).json({ message: "Access denied. Please purchase a subscription to access training materials." });
      }

      const data = {
        ...req.body,
        userId: req.session.userId
      };
      
      const progress = await storage.updateTrainingProgress(data);
      return res.status(200).json(progress);
    } catch (error) {
      return res.status(500).json({ message: "Server error updating training progress" });
    }
  });

  // Checklist routes
  app.get("/api/checklists", async (req, res) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Check if user has purchased access
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!user.hasPurchased) {
        return res.status(403).json({ message: "Access denied. Please purchase a subscription to access checklists." });
      }

      const checklists = await storage.getChecklistsByUserId(req.session.userId);
      return res.status(200).json(checklists);
    } catch (error) {
      return res.status(500).json({ message: "Server error fetching checklists" });
    }
  });

  app.post("/api/checklists", async (req, res) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Check if user has purchased access
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!user.hasPurchased) {
        return res.status(403).json({ message: "Access denied. Please purchase a subscription to access checklists." });
      }

      const data = {
        ...req.body,
        userId: req.session.userId
      };
      
      const checklist = await storage.saveChecklist(data);
      return res.status(200).json(checklist);
    } catch (error) {
      return res.status(500).json({ message: "Server error saving checklist" });
    }
  });

  // Practice test routes
  app.get("/api/practice-tests", async (req, res) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Check if user has purchased access
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!user.hasPurchased) {
        return res.status(403).json({ message: "Access denied. Please purchase a subscription to access practice tests." });
      }

      const tests = await storage.getPracticeTestsByUserId(req.session.userId);
      return res.status(200).json(tests);
    } catch (error) {
      return res.status(500).json({ message: "Server error fetching practice tests" });
    }
  });

  app.post("/api/practice-tests", async (req, res) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Check if user has purchased access
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!user.hasPurchased) {
        return res.status(403).json({ message: "Access denied. Please purchase a subscription to access practice tests." });
      }

      const data = {
        ...req.body,
        userId: req.session.userId
      };
      
      const test = await storage.savePracticeTest(data);
      return res.status(200).json(test);
    } catch (error) {
      return res.status(500).json({ message: "Server error saving practice test" });
    }
  });

  // Documents routes removed

  // Payment routes
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ message: "Stripe is not configured" });
    }

    try {
      const { planType, amount } = req.body;
      const validPlanTypes = Object.keys(PRICING_PLANS);
      
      if (!planType || !validPlanTypes.includes(planType)) {
        return res.status(400).json({ message: "Invalid plan type" });
      }
      
      // Get user email for receipt if they're logged in
      let userEmail;
      if (req.session && req.session.userId) {
        const user = await storage.getUser(req.session.userId);
        userEmail = user?.email;
      }
      
      const selectedPlan = PRICING_PLANS[planType as keyof typeof PRICING_PLANS];
      const planAmount = amount || selectedPlan.price;
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(planAmount * 100), // Convert to cents
        currency: "eur",
        automatic_payment_methods: {
          enabled: true,
        },
        receipt_email: userEmail, // For Stripe to send its own receipt as well
        metadata: {
          product: `SPSV ${selectedPlan.name} Training Package`,
          planType: planType,
          duration: `${selectedPlan.duration} days`,
        },
        description: `SPSV ${selectedPlan.name} Training Package`,
      });
      
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error("Stripe error:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  app.post("/api/confirm-payment", async (req, res) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const { planType } = req.body;
      const selectedPlanType = planType || 'STANDARD';
      
      // Validate the plan type exists
      if (!PRICING_PLANS[selectedPlanType as keyof typeof PRICING_PLANS]) {
        return res.status(400).json({ message: "Invalid plan type" });
      }
      
      // Mark that the user has purchased
      const user = await storage.updatePurchaseStatus(req.session.userId, true);
      
      // Send payment confirmation email if user has an email
      if (user.email) {
        try {
          const plan = PRICING_PLANS[selectedPlanType as keyof typeof PRICING_PLANS];
          const durationDays = plan.duration;
          
          await sendPaymentConfirmation(
            user.email,
            user.username,
            plan.name,
            `€${plan.price.toFixed(2)}`,
            durationDays
          );
          console.log(`Payment confirmation email sent to ${user.email}`);
        } catch (emailError) {
          console.error("Failed to send payment confirmation email:", emailError);
          // Continue with payment confirmation even if email fails
        }
      }
      
      return res.status(200).json({ 
        success: true,
        plan: selectedPlanType
      });
    } catch (error) {
      console.error("Payment confirmation error:", error);
      return res.status(500).json({ message: "Server error confirming payment" });
    }
  });

  // NTA Monitoring Routes
  app.get("/api/nta/updates", async (req, res) => {
    try {
      const days = parseInt(req.query.days as string) || 7;
      const updates = await ntaMonitor.getRecentUpdates(days);
      res.json(updates);
    } catch (error) {
      console.error("Error fetching NTA updates:", error);
      res.status(500).json({ message: "Failed to fetch NTA updates" });
    }
  });

  app.post("/api/nta/check", async (req, res) => {
    try {
      console.log("Manual NTA update check requested");
      const updates = await ntaMonitor.forceCheck();
      res.json({ 
        message: `Found ${updates.length} new updates`,
        updates 
      });
    } catch (error) {
      console.error("Error checking NTA updates:", error);
      res.status(500).json({ message: "Failed to check for NTA updates" });
    }
  });

  const httpServer = createServer(app);

  // Initialize NTA monitoring when server starts
  ntaMonitor.startMonitoring().catch(console.error);

  return httpServer;
}
