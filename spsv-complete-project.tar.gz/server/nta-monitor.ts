import axios from 'axios';
import * as cheerio from 'cheerio';
import { promises as fs } from 'fs';
import path from 'path';

interface NTAUpdate {
  id: string;
  title: string;
  url: string;
  lastModified: string;
  content: string;
  type: 'regulation' | 'fee' | 'requirement' | 'guidance' | 'exam';
  priority: 'high' | 'medium' | 'low';
}

interface MonitoringConfig {
  checkInterval: number; // hours
  ntaBaseUrl: string;
  monitoredPages: string[];
  lastCheck: string;
  updates: NTAUpdate[];
}

export class NTAMonitor {
  private config: MonitoringConfig;
  private configPath: string;

  constructor() {
    this.configPath = path.join(process.cwd(), 'data', 'nta-monitoring.json');
    this.config = {
      checkInterval: 24, // Check daily
      ntaBaseUrl: 'https://www.nationaltransport.ie',
      monitoredPages: [
        '/small-public-service-vehicles/',
        '/small-public-service-vehicles/taxi-regulation/',
        '/small-public-service-vehicles/vehicle-licensing/',
        '/small-public-service-vehicles/driver-licensing/',
        '/small-public-service-vehicles/enforcement/'
      ],
      lastCheck: new Date().toISOString(),
      updates: []
    };
  }

  async initialize(): Promise<void> {
    try {
      const configData = await fs.readFile(this.configPath, 'utf-8');
      this.config = { ...this.config, ...JSON.parse(configData) };
    } catch (error) {
      // Config file doesn't exist, create it
      await this.saveConfig();
    }
  }

  private async saveConfig(): Promise<void> {
    const dataDir = path.dirname(this.configPath);
    try {
      await fs.mkdir(dataDir, { recursive: true });
      await fs.writeFile(this.configPath, JSON.stringify(this.config, null, 2));
    } catch (error) {
      console.error('Failed to save NTA monitoring config:', error);
    }
  }

  async checkForUpdates(): Promise<NTAUpdate[]> {
    console.log('🔍 Checking NTA website for updates...');
    const newUpdates: NTAUpdate[] = [];

    for (const page of this.config.monitoredPages) {
      try {
        const update = await this.checkPage(page);
        if (update && this.isNewUpdate(update)) {
          newUpdates.push(update);
          console.log(`📋 Found update: ${update.title}`);
        }
        // Rate limiting - wait 2 seconds between requests
        await new Promise(resolve => setTimeout(resolve, 2000));
      } catch (error) {
        // Simplified error logging to avoid spam
        console.warn(`⚠️ Failed to check page ${page}`);
      }
    }

    // Update last check time
    this.config.lastCheck = new Date().toISOString();
    
    // Add new updates to config
    this.config.updates.push(...newUpdates);
    
    // Keep only last 100 updates
    this.config.updates = this.config.updates.slice(-100);
    
    await this.saveConfig();
    
    if (newUpdates.length > 0) {
      console.log(`✅ Found ${newUpdates.length} new NTA updates!`);
      await this.notifyOfUpdates(newUpdates);
    } else {
      console.log('ℹ️ No new NTA updates found');
    }

    return newUpdates;
  }

  private async checkPage(pagePath: string): Promise<NTAUpdate | null> {
    try {
      const url = `${this.config.ntaBaseUrl}${pagePath}`;
      const response = await axios.get(url, {
        timeout: 10000,
        headers: {
          'User-Agent': 'SPSV-Training-Monitor/1.0'
        },
        validateStatus: (status) => status === 200 // Only accept 200 status codes
      });

      // Check if we got an actual HTML page, not an error page
      const contentType = response.headers['content-type'] || '';
      if (!contentType.includes('text/html')) {
        console.warn(`⚠️ Non-HTML response from ${url}`);
        return null;
      }

      const $ = cheerio.load(response.data);
      
      // Check if this is an error page (404, etc.)
      const title = $('title').text() || $('h1').first().text() || '';
      const bodyClass = $('body').attr('class') || '';
      
      if (title.includes('404') || title.includes('Not Found') || 
          bodyClass.includes('error404') || bodyClass.includes('not-found')) {
        console.warn(`⚠️ Page not found: ${url}`);
        return null;
      }
      
      const lastModified = response.headers['last-modified'] || new Date().toISOString();
      
      // Extract main content
      const content = this.extractRelevantContent($);
      
      // Skip if content is too short (likely an error page)
      if (content.length < 50) {
        console.warn(`⚠️ Insufficient content from ${url}`);
        return null;
      }
      
      // Determine update type and priority
      const type = this.categoriseUpdate(title, content);
      const priority = this.assessPriority(title, content);

      return {
        id: this.generateUpdateId(url, lastModified),
        title: title.trim(),
        url,
        lastModified,
        content,
        type,
        priority
      };
    } catch (error) {
      // Improved error handling - don't log massive HTML responses
      if (axios.isAxiosError(error)) {
        if (error.response?.status === 404) {
          console.warn(`⚠️ Page not found (404): ${pagePath}`);
        } else if (error.response?.status) {
          console.warn(`⚠️ HTTP ${error.response.status} error for page: ${pagePath}`);
        } else if (error.code === 'ECONNABORTED') {
          console.warn(`⚠️ Timeout checking page: ${pagePath}`);
        } else {
          console.warn(`⚠️ Network error checking page: ${pagePath} - ${error.message}`);
        }
      } else {
        console.warn(`⚠️ Error checking page ${pagePath}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
      return null;
    }
  }

  private extractRelevantContent($: cheerio.CheerioAPI): string {
    // Extract text from main content areas
    const selectors = [
      '.content',
      '.main-content', 
      'main',
      '.page-content',
      'article',
      '.entry-content'
    ];

    for (const selector of selectors) {
      const content = $(selector).text();
      if (content && content.length > 100) {
        return content.trim().substring(0, 2000); // Limit content size
      }
    }

    // Fallback to body text
    return $('body').text().trim().substring(0, 2000);
  }

  private categoriseUpdate(title: string, content: string): NTAUpdate['type'] {
    const text = (title + ' ' + content).toLowerCase();
    
    if (text.includes('fee') || text.includes('cost') || text.includes('price') || text.includes('€')) {
      return 'fee';
    }
    if (text.includes('exam') || text.includes('test') || text.includes('assessment')) {
      return 'exam';
    }
    if (text.includes('regulation') || text.includes('rule') || text.includes('compliance')) {
      return 'regulation';
    }
    if (text.includes('requirement') || text.includes('standard') || text.includes('criteria')) {
      return 'requirement';
    }
    
    return 'guidance';
  }

  private assessPriority(title: string, content: string): NTAUpdate['priority'] {
    const text = (title + ' ' + content).toLowerCase();
    
    // High priority keywords
    if (text.includes('urgent') || text.includes('immediate') || text.includes('mandatory') || 
        text.includes('new requirement') || text.includes('fee change') || text.includes('exam change')) {
      return 'high';
    }
    
    // Medium priority keywords
    if (text.includes('update') || text.includes('change') || text.includes('amendment') || 
        text.includes('guidance') || text.includes('clarification')) {
      return 'medium';
    }
    
    return 'low';
  }

  private generateUpdateId(url: string, lastModified: string): string {
    return Buffer.from(url + lastModified).toString('base64').substring(0, 16);
  }

  private isNewUpdate(update: NTAUpdate): boolean {
    return !this.config.updates.some(existing => existing.id === update.id);
  }

  private async notifyOfUpdates(updates: NTAUpdate[]): Promise<void> {
    // Log updates for now - could expand to email notifications
    console.log('\n🚨 NEW NTA UPDATES DETECTED:');
    console.log('════════════════════════════════');
    
    updates.forEach(update => {
      console.log(`📌 ${update.title}`);
      console.log(`   Type: ${update.type} | Priority: ${update.priority}`);
      console.log(`   URL: ${update.url}`);
      console.log(`   Updated: ${new Date(update.lastModified).toLocaleDateString()}`);
      console.log('');
    });
    
    console.log('💡 Consider reviewing these updates and updating your training content accordingly.');
  }

  async getRecentUpdates(days: number = 7): Promise<NTAUpdate[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    return this.config.updates.filter(update => 
      new Date(update.lastModified) > cutoffDate
    );
  }

  async startMonitoring(): Promise<void> {
    console.log('🚀 Starting NTA monitoring service...');
    await this.initialize();
    
    // Initial check
    await this.checkForUpdates();
    
    // Set up periodic checking
    setInterval(async () => {
      await this.checkForUpdates();
    }, this.config.checkInterval * 60 * 60 * 1000); // Convert hours to milliseconds
    
    console.log(`✅ NTA monitoring active - checking every ${this.config.checkInterval} hours`);
  }

  // Manual trigger for immediate check
  async forceCheck(): Promise<NTAUpdate[]> {
    console.log('🔄 Manual NTA update check triggered...');
    return await this.checkForUpdates();
  }
}

// Export singleton instance
export const ntaMonitor = new NTAMonitor();