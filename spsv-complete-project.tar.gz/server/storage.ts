import { 
  User, InsertUser, users, 
  InsertTrainingProgress, TrainingProgress, trainingProgress,
  PracticeTest, InsertPracticeTest, practiceTests,
  Checklist, InsertChecklist, checklists,
  Document, InsertDocument, documents
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updatePurchaseStatus(userId: number, hasPurchased: boolean): Promise<User>;
  
  // Training progress methods
  getTrainingProgressByUserId(userId: number): Promise<TrainingProgress[]>;
  getTrainingProgress(userId: number, moduleId: number, vehicleType: string): Promise<TrainingProgress | undefined>;
  updateTrainingProgress(progress: Partial<InsertTrainingProgress>): Promise<TrainingProgress>;
  
  // Practice test methods
  getPracticeTestsByUserId(userId: number): Promise<PracticeTest[]>;
  savePracticeTest(test: InsertPracticeTest): Promise<PracticeTest>;
  
  // Checklist methods
  getChecklistsByUserId(userId: number): Promise<Checklist[]>;
  getChecklist(userId: number, checklistType: string): Promise<Checklist | undefined>;
  saveChecklist(checklist: InsertChecklist): Promise<Checklist>;
  
  // Document methods
  getDocumentsByUserId(userId: number): Promise<Document[]>;
  saveDocument(document: InsertDocument): Promise<Document>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private trainingProgresses: Map<number, TrainingProgress>;
  private practiceTests: Map<number, PracticeTest>;
  private checklists: Map<number, Checklist>;
  private documents: Map<number, Document>;
  
  private userId: number = 1;
  private progressId: number = 1;
  private testId: number = 1;
  private checklistId: number = 1;
  private documentId: number = 1;

  constructor() {
    this.users = new Map();
    this.trainingProgresses = new Map();
    this.practiceTests = new Map();
    this.checklists = new Map();
    this.documents = new Map();
    

    
    // Add test user
    this.users.set(2, {
      id: 2,
      username: "testuser",
      password: "password123",
      email: "test@example.com",
      fullName: "Test User",
      role: "user",
      vehicleType: "taxi",
      createdAt: new Date(),
      hasPurchased: false, 
      stripeCustomerId: null
    } as User);
    
    this.userId = 3; // Next available ID
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      role: "user", 
      createdAt: now,
      hasPurchased: false,
      stripeCustomerId: null
    };
    this.users.set(id, user);
    return user;
  }
  
  async updatePurchaseStatus(userId: number, hasPurchased: boolean): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = {
      ...user,
      hasPurchased
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Training progress methods
  async getTrainingProgressByUserId(userId: number): Promise<TrainingProgress[]> {
    return Array.from(this.trainingProgresses.values()).filter(
      (progress) => progress.userId === userId
    );
  }
  
  async getTrainingProgress(userId: number, moduleId: number, vehicleType: string): Promise<TrainingProgress | undefined> {
    return Array.from(this.trainingProgresses.values()).find(
      (progress) => progress.userId === userId && 
                    progress.moduleId === moduleId &&
                    progress.vehicleType === vehicleType
    );
  }
  
  async updateTrainingProgress(progressData: Partial<InsertTrainingProgress>): Promise<TrainingProgress> {
    const { userId, moduleId, vehicleType } = progressData;
    
    if (!userId || !moduleId || !vehicleType) {
      throw new Error("Missing required fields");
    }
    
    const existingProgress = await this.getTrainingProgress(userId, moduleId, vehicleType);
    
    if (existingProgress) {
      const updatedProgress = {
        ...existingProgress,
        ...progressData,
        lastAccessed: new Date()
      };
      
      this.trainingProgresses.set(existingProgress.id, updatedProgress);
      return updatedProgress;
    } else {
      const id = this.progressId++;
      const now = new Date();
      
      const newProgress: TrainingProgress = {
        id,
        userId,
        moduleId,
        vehicleType,
        progress: progressData.progress || 0,
        isCompleted: progressData.isCompleted || false,
        lastAccessed: now
      };
      
      this.trainingProgresses.set(id, newProgress);
      return newProgress;
    }
  }

  // Practice test methods
  async getPracticeTestsByUserId(userId: number): Promise<PracticeTest[]> {
    return Array.from(this.practiceTests.values()).filter(
      (test) => test.userId === userId
    );
  }
  
  async savePracticeTest(testData: InsertPracticeTest): Promise<PracticeTest> {
    const id = this.testId++;
    const now = new Date();
    
    const newTest: PracticeTest = {
      id,
      ...testData,
      dateTaken: now
    };
    
    this.practiceTests.set(id, newTest);
    return newTest;
  }

  // Checklist methods
  async getChecklistsByUserId(userId: number): Promise<Checklist[]> {
    return Array.from(this.checklists.values()).filter(
      (checklist) => checklist.userId === userId
    );
  }
  
  async getChecklist(userId: number, checklistType: string): Promise<Checklist | undefined> {
    return Array.from(this.checklists.values()).find(
      (checklist) => checklist.userId === userId && checklist.checklistType === checklistType
    );
  }
  
  async saveChecklist(checklistData: InsertChecklist): Promise<Checklist> {
    const { userId, checklistType } = checklistData;
    const existingChecklist = await this.getChecklist(userId, checklistType);
    
    if (existingChecklist) {
      const updatedChecklist = {
        ...existingChecklist,
        ...checklistData,
        updatedAt: new Date()
      };
      
      this.checklists.set(existingChecklist.id, updatedChecklist);
      return updatedChecklist;
    } else {
      const id = this.checklistId++;
      const now = new Date();
      
      const newChecklist: Checklist = {
        id,
        ...checklistData,
        updatedAt: now
      };
      
      this.checklists.set(id, newChecklist);
      return newChecklist;
    }
  }

  // Document methods
  async getDocumentsByUserId(userId: number): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(
      (document) => document.userId === userId
    );
  }
  
  async saveDocument(documentData: InsertDocument): Promise<Document> {
    const id = this.documentId++;
    const now = new Date();
    
    const newDocument: Document = {
      id,
      ...documentData,
      uploadDate: now,
      status: "pending"
    };
    
    this.documents.set(id, newDocument);
    return newDocument;
  }
}

export const storage = new MemStorage();
