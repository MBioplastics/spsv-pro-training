import sgMail from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  throw new Error("SENDGRID_API_KEY environment variable must be set");
}

// Set the API key
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

// Set default sender email addresses
// Note: For production, you need to verify this domain in SendGrid or use a verified sender
const FROM_EMAIL = 'noreply@spsvprotraining.ie';
const REPLY_TO = 'support@spsvprotraining.ie';

interface EmailParams {
  to: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  try {
    console.log(`Attempting to send email to: ${params.to}`);
    console.log(`From: ${FROM_EMAIL}`);
    console.log(`Subject: ${params.subject}`);
    
    const result = await sgMail.send({
      to: params.to,
      from: FROM_EMAIL,
      replyTo: REPLY_TO,
      subject: params.subject,
      text: params.text || params.html?.replace(/<[^>]*>/g, '') || 'Email content',
      html: params.html || params.text || 'Email content',
    });
    
    console.log(`Email sent successfully to ${params.to}. SendGrid response:`, result[0].statusCode);
    return true;
  } catch (error: any) {
    console.error('SendGrid email error:', error);
    console.error('Error details:', error.response?.body || error.message);
    return false;
  }
}

export async function sendRegistrationConfirmation(to: string, username: string): Promise<boolean> {
  const subject = 'Welcome to SPSV Pro Training - Registration Confirmation';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
      <div style="text-align: center; margin-bottom: 20px;">
        <h1 style="color: #3b82f6;">SPSV Pro Training</h1>
        <p style="font-size: 18px; color: #4b5563;">Registration Confirmation</p>
      </div>
      
      <div style="margin-bottom: 30px;">
        <p>Hello ${username},</p>
        <p>Thank you for registering with SPSV Pro Training. Your account has been created successfully.</p>
        <p>You now have access to our comprehensive training platform to help you prepare for your SPSV certification in Ireland.</p>
      </div>
      
      <div style="margin-bottom: 30px;">
        <p>Next Steps:</p>
        <ol>
          <li>Complete your purchase to unlock all training materials</li>
          <li>Begin your training modules</li>
          <li>Practice with our sample tests</li>
          <li>Prepare for your exam with our checklists</li>
        </ol>
      </div>
      
      <div style="background-color: #f3f4f6; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
        <p style="margin: 0; font-weight: bold;">Account Information:</p>
        <p style="margin: 5px 0;">Username: ${username}</p>
      </div>
      
      <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; color: #6b7280; font-size: 14px;">
        <p>If you have any questions or need assistance, please contact our support team at support@spsvprotraining.ie.</p>
        <p>© ${new Date().getFullYear()} SPSV Pro Training. All rights reserved.</p>
      </div>
    </div>
  `;

  return sendEmail({ to, subject, html });
}

export async function sendPaymentConfirmation(
  to: string, 
  username: string, 
  planName: string, 
  planPrice: string,
  durationDays: number
): Promise<boolean> {
  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + durationDays);
  
  const formattedDate = expiryDate.toLocaleDateString('en-IE', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const subject = 'Your SPSV Pro Training Purchase Confirmation';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
      <div style="text-align: center; margin-bottom: 20px;">
        <h1 style="color: #3b82f6;">SPSV Pro Training</h1>
        <p style="font-size: 18px; color: #4b5563;">Payment Confirmation</p>
      </div>
      
      <div style="margin-bottom: 30px;">
        <p>Hello ${username},</p>
        <p>Thank you for your purchase! Your payment has been successfully processed.</p>
        <p>You now have full access to the SPSV Pro Training platform until <strong>${formattedDate}</strong>.</p>
      </div>
      
      <div style="background-color: #f3f4f6; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
        <p style="margin: 0; font-weight: bold;">Purchase Details:</p>
        <p style="margin: 5px 0;">Plan: ${planName}</p>
        <p style="margin: 5px 0;">Amount: ${planPrice}</p>
        <p style="margin: 5px 0;">Access Period: ${durationDays} days (until ${formattedDate})</p>
      </div>
      
      <div style="margin-bottom: 30px;">
        <p>What's included in your plan:</p>
        <ul>
          <li>Comprehensive SPSV training modules</li>
          <li>Practice tests with detailed feedback</li>
          <li>Vehicle regulation checklists</li>
          <li>SPSV vehicle finder tool</li>
          <li>Area knowledge training for all counties</li>
        </ul>
      </div>
      
      <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0; color: #6b7280; font-size: 14px;">
        <p>If you have any questions or need assistance, please contact our support team at support@spsvprotraining.ie.</p>
        <p>© ${new Date().getFullYear()} SPSV Pro Training. All rights reserved.</p>
      </div>
    </div>
  `;

  return sendEmail({ to, subject, html });
}

interface AdminPurchaseData {
  customerEmail: string;
  planName: string;
  amount: string;
  paymentId: string;
  timestamp: string;
}

export async function sendAdminPurchaseNotification(data: AdminPurchaseData): Promise<boolean> {
  const subject = `New SPSV Training Purchase - ${data.planName}`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
      <div style="text-align: center; margin-bottom: 20px;">
        <h1 style="color: #16a34a;">SPSV Pro Training</h1>
        <p style="font-size: 18px; color: #4b5563;">New Purchase Notification</p>
      </div>
      
      <div style="background-color: #f0fdf4; padding: 15px; border-radius: 5px; border-left: 4px solid #16a34a; margin-bottom: 20px;">
        <h2 style="margin: 0 0 10px 0; color: #16a34a;">New Customer Purchase!</h2>
        <p style="margin: 0;">A customer has successfully purchased an SPSV training plan.</p>
      </div>
      
      <div style="background-color: #f9fafb; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
        <h3 style="margin: 0 0 10px 0;">Purchase Details:</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="padding: 5px 0; font-weight: bold;">Customer Email:</td>
            <td style="padding: 5px 0;">${data.customerEmail}</td>
          </tr>
          <tr>
            <td style="padding: 5px 0; font-weight: bold;">Plan:</td>
            <td style="padding: 5px 0;">${data.planName}</td>
          </tr>
          <tr>
            <td style="padding: 5px 0; font-weight: bold;">Amount:</td>
            <td style="padding: 5px 0; color: #16a34a; font-weight: bold;">${data.amount}</td>
          </tr>
          <tr>
            <td style="padding: 5px 0; font-weight: bold;">Payment ID:</td>
            <td style="padding: 5px 0; font-family: monospace; font-size: 12px;">${data.paymentId}</td>
          </tr>
          <tr>
            <td style="padding: 5px 0; font-weight: bold;">Date/Time:</td>
            <td style="padding: 5px 0;">${new Date(data.timestamp).toLocaleString('en-IE')}</td>
          </tr>
        </table>
      </div>
      
      <div style="margin-bottom: 20px;">
        <p style="margin: 0; color: #6b7280; font-size: 14px;">
          This notification was automatically generated when the customer completed their payment through Stripe.
        </p>
      </div>
      
      <div style="text-align: center; padding: 15px; background-color: #f3f4f6; border-radius: 5px;">
        <p style="margin: 0; font-size: 12px; color: #6b7280;">
          SPSV Pro Training Admin Notification System
        </p>
      </div>
    </div>
  `;

  // Send to admin email - replace with your actual email address
  const adminEmail = 'support@spsvprotraining.ie';
  return sendEmail({ to: adminEmail, subject, html });
}