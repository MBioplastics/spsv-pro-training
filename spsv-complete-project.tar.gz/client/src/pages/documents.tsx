import { useEffect } from "react";
import { useLocation } from "wouter";

// Page removed - redirects to checklists
export default function Documents() {
  const [, navigate] = useLocation();
  
  // Redirect to checklists page
  useEffect(() => {
    navigate("/checklists");
  }, [navigate]);
  
  // In case the redirect fails, show a loading indicator
  return (
    <div className="h-screen flex items-center justify-center">
      <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full" aria-label="Loading"/>
    </div>
  );
}