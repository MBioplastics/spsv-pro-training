import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Sidebar } from "@/components/dashboard/sidebar";
import { PageHeader } from "@/components/shared/page-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { CheckCircle, Clock, Award, ArrowRight, FileText } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { TRAINING_MODULES, SPSV_TYPES } from "@/lib/constants";
import { TestInterface } from "@/components/practice-tests/test-interface";
import { CountySelector } from "@/components/practice-tests/county-selector";
import { PRACTICE_TESTS } from "@/data/practice-test-data";
import { COUNTY_AREA_KNOWLEDGE } from "@/data/county-area-knowledge";

export default function PracticeTests() {
  const [, navigate] = useLocation();
  const [selectedCounty, setSelectedCounty] = useState("Dublin");
  const [activeTest, setActiveTest] = useState<number | null>(null);
  const [countyTest, setCountyTest] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch user data
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ["/api/user"],
    retry: false,
  });
  
  // Use user's selected vehicle type
  const selectedVehicle = user?.vehicleType || "taxi";
  
  // Fetch practice test history
  const { data: testHistory, isLoading: historyLoading } = useQuery({
    queryKey: ["/api/practice-tests"],
    enabled: !!user,
  });
  
  // Get vehicle name
  const getVehicleName = () => {
    return SPSV_TYPES.find(type => type.id === selectedVehicle)?.name || "Vehicle";
  };
  
  // Get relevant modules for a test
  const getModulesString = (moduleIds: number[]) => {
    return moduleIds.map(id => {
      const module = TRAINING_MODULES.find(m => m.id === id);
      return module ? `Module ${id}` : '';
    }).join(', ');
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IE', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };
  
  // Start a test
  const handleStartTest = (testId: number) => {
    setActiveTest(testId);
  };
  
  // Handle test completion
  const handleTestComplete = (score: number, total: number) => {
    queryClient.invalidateQueries({ queryKey: ["/api/practice-tests"] });
    setActiveTest(null);
    
    const passThreshold = 0.8;
    const percentage = Math.round((score / total) * 100);
    const passed = score / total >= passThreshold;
    
    toast({
      title: passed ? "Test Passed!" : "Test Completed",
      description: `You scored ${score} out of ${total} (${percentage}%)${passed ? " - Congratulations!" : ""}`,
      variant: passed ? "default" : "destructive",
    });
  };
  
  // Check if user is authenticated
  useEffect(() => {
    if (userError) {
      navigate("/login");
    }
  }, [userError, navigate]);

  // Check if user has purchased access
  if (user && !user.hasPurchased) {
    return (
      <div className="min-h-screen flex flex-col lg:flex-row">
        <Sidebar userName={user.username} userRole="user" />
        <main className="flex-1 p-8 lg:ml-64">
          <div className="max-w-4xl mx-auto">
            <PageHeader title="Practice Tests" description="Subscription Required" />
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-6">
              <h2 className="text-xl font-semibold text-yellow-800 mb-2">Unlock Practice Tests</h2>
              <p className="text-yellow-700 mb-4">
                Practice tests are available with a paid subscription. Get unlimited access to exam preparation materials.
              </p>
              <button
                onClick={() => navigate("/pricing")}
                className="bg-primary-500 hover:bg-primary-600 text-white font-medium py-2 px-4 rounded"
              >
                Choose Your Plan
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }
  
  // Filter test history by vehicle type
  const filteredHistory = testHistory?.filter(
    (test: any) => test.vehicleType === selectedVehicle
  ) || [];
  
  // Loading state
  if (userLoading || historyLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }
  
  // If a test is active, show the test interface
  if (activeTest !== null) {
    let testData;
    
    if (countyTest) {
      // Get county-specific test data, or fall back to "Other Counties" if not available
      testData = COUNTY_AREA_KNOWLEDGE[selectedCounty] || COUNTY_AREA_KNOWLEDGE["Other Counties"];
    } else {
      testData = PRACTICE_TESTS.find(test => test.id === activeTest);
    }
    
    if (!testData) {
      setActiveTest(null);
      setCountyTest(false);
      return null;
    }
    
    return (
      <TestInterface 
        testData={testData}
        vehicleType={selectedVehicle}
        onClose={() => {
          setActiveTest(null);
          setCountyTest(false);
        }}
        onComplete={handleTestComplete}
      />
    );
  }
  
  // Modules covered for each test
  const testModuleMapping = [
    { id: 1, modules: [1, 2, 3] },             // Industry Knowledge
    { id: 2, modules: [4, 5, 6] },             // Area Knowledge
    { id: 3, modules: [7, 8, 9] },             // Customer Service
    { id: 4, modules: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] }  // Full Mock Exam - covers all modules
  ];
  
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar 
        userName={user?.username || "User"} 
        userRole="SPSV Pro Training Driver Trainee" 
      />
      
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <PageHeader 
            title="Practice Tests" 
            description="Test your knowledge with these practice exams to prepare for your SPSV driver test"
          />
          
          <div className="mb-6">
            <h2 className="text-xl font-semibold">{getVehicleName()} Practice Tests</h2>
            <p className="text-neutral-600">
              Tests are customized for your vehicle type: {getVehicleName()}
            </p>
          </div>
          
          {/* County Selector for Area Knowledge Test */}
          {PRACTICE_TESTS.some(test => test.id === 2) && (
            <div className="mb-8">
              <Card>
                <CardHeader>
                  <CardTitle>Area Knowledge Test</CardTitle>
                  <CardDescription>
                    Test your knowledge of specific counties and locations in Ireland. Select a county to begin.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <CountySelector
                    selectedCounty={selectedCounty}
                    onCountyChange={setSelectedCounty}
                  />
                  
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-md font-medium mb-1">{selectedCounty} Area Knowledge Test</h3>
                      <p className="text-sm text-neutral-600">
                        {COUNTY_AREA_KNOWLEDGE[selectedCounty] ? 
                          `30 questions - ${COUNTY_AREA_KNOWLEDGE[selectedCounty].timeLimit} minutes` : 
                          `30 questions - ${COUNTY_AREA_KNOWLEDGE["Other Counties"].timeLimit} minutes`
                        }
                      </p>
                      <p className="text-sm text-neutral-600 mt-1">
                        <strong>Covers:</strong> {getModulesString(testModuleMapping.find(mapping => mapping.id === 2)?.modules || [])}
                      </p>
                    </div>
                    
                    <Button 
                      className="bg-primary-500 hover:bg-primary-600"
                      onClick={() => {
                        setActiveTest(2); // Area Knowledge Test ID
                        setCountyTest(true);
                      }}
                    >
                      Start County Test
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
          
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {PRACTICE_TESTS.filter(test => test.id !== 2).map((test, index) => (
              <Card key={test.id}>
                <CardHeader>
                  <CardTitle>{test.title}</CardTitle>
                  <CardDescription>{test.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center">
                      <FileText className="mr-2 h-4 w-4 text-neutral-500" />
                      <span className="text-sm text-neutral-600">
                        {test.id === 1 ? 40 : 
                         test.id === 3 ? 25 : 
                         test.id === 4 ? 80 : 
                         test.questions.length} Questions
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="mr-2 h-4 w-4 text-neutral-500" />
                      <span className="text-sm text-neutral-600">{test.timeLimit} Minutes</span>
                    </div>
                  </div>
                  <div className="text-sm text-neutral-600 mb-4">
                    <strong>Covers:</strong> {getModulesString(testModuleMapping.find(mapping => mapping.id === test.id)?.modules || [])}
                  </div>
                  
                  {/* Test results power bar */}
                  {filteredHistory.some((historyItem: any) => historyItem.testType === test.title) && (
                    <div className="mt-2">
                      {(() => {
                        const bestResult = filteredHistory
                          .filter((item: any) => item.testType === test.title)
                          .reduce((best: any, current: any) => {
                            const bestScore = best ? best.score / best.totalQuestions : 0;
                            const currentScore = current.score / current.totalQuestions;
                            return currentScore > bestScore ? current : best;
                          }, null);
                        
                        if (bestResult) {
                          const percentage = Math.round((bestResult.score / bestResult.totalQuestions) * 100);
                          const isPassing = percentage >= 80;
                          
                          return (
                            <>
                              <div className="flex justify-between text-xs mb-1">
                                <span>Best Score: {bestResult.score}/{bestResult.totalQuestions}</span>
                                <span className={isPassing ? "text-green-600 font-medium" : "text-orange-600 font-medium"}>
                                  {percentage}%
                                </span>
                              </div>
                              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full rounded-full ${
                                    isPassing ? "bg-green-500" : percentage >= 60 ? "bg-yellow-500" : "bg-orange-500"
                                  }`} 
                                  style={{ width: `${percentage}%` }}
                                />
                              </div>
                              <div className="text-xs text-right mt-1">
                                {isPassing ? (
                                  <span className="text-green-600 flex items-center justify-end">
                                    <CheckCircle className="h-3 w-3 mr-1" />
                                    Passed
                                  </span>
                                ) : (
                                  <span className="text-orange-600">
                                    Need {Math.ceil(bestResult.totalQuestions * 0.8) - bestResult.score} more correct to pass
                                  </span>
                                )}
                              </div>
                            </>
                          );
                        }
                        
                        return null;
                      })()}
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full bg-primary-500 hover:bg-primary-600"
                    onClick={() => handleStartTest(test.id)}
                  >
                    Start Test
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
          
          <div>
            <h2 className="text-xl font-semibold mb-4">Test History</h2>
            {filteredHistory.length > 0 ? (
              <Table>
                <TableCaption>Your recent test attempts for {getVehicleName()}</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Test Type</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Result</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredHistory.map((test: any, index: number) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{test.testType}</TableCell>
                      <TableCell>{formatDate(test.dateTaken)}</TableCell>
                      <TableCell>{test.score}/{test.totalQuestions}</TableCell>
                      <TableCell>
                        {(test.score / test.totalQuestions) >= 0.8 ? (
                          <div className="flex items-center text-green-600">
                            <CheckCircle className="mr-1 h-4 w-4" />
                            Pass
                          </div>
                        ) : (
                          <div className="text-orange-600">
                            Try Again
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center p-6">
                  <Award className="h-12 w-12 text-neutral-300 mb-4" />
                  <p className="text-center text-neutral-600 mb-2">
                    You haven't taken any tests for {getVehicleName()} yet.
                  </p>
                  <p className="text-center text-neutral-500 text-sm">
                    Start a practice test above to see your results here.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
