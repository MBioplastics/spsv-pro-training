import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";
import { PRICING_PLANS } from "@/lib/constants";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { MetaTags } from "@/components/meta-tags";

export default function Pricing() {
  const [selectedPlan, setSelectedPlan] = useState<string>("STANDARD");

  return (
    <div className="min-h-screen flex flex-col">
      <MetaTags 
        title="SPSV Training Pricing Plans | €9.99 Basic, €19.99 Standard, €49.99 Premium | Ireland"
        description="Choose your SPSV training plan: Basic €9.99 (30 days), Standard €19.99 (60 days), Premium €49.99 (365 days). Comprehensive taxi, hackney, and limousine certification training for Ireland."
        keywords="SPSV training pricing, SPSV course cost, taxi training price Ireland, hackney training cost, limousine training pricing, PSV training fees, SPSV certification cost"
        canonicalUrl="https://www.spsvprotraining.ie/pricing"
      />
      <Header />
      <main className="flex-grow py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-primary-500 mb-4">Choose Your SPSV Training Plan</h1>
            <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
              Select the plan that works best for your SPSV preparation needs. All plans include comprehensive training materials and practice tests.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {/* Basic Plan */}
            <div className={`bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 transform ${selectedPlan === "BASIC" ? "scale-105 ring-2 ring-primary-500" : "hover:scale-102"}`}>
              <div className="bg-primary-500 p-6 text-center text-white relative">
                <h3 className="text-2xl font-bold mb-2">{PRICING_PLANS.BASIC.name}</h3>
                <div className="text-4xl font-bold mb-2">€{PRICING_PLANS.BASIC.price}</div>
                <p className="text-primary-100">{PRICING_PLANS.BASIC.duration} days access</p>
              </div>
              
              <div className="p-6">
                <div className="space-y-3 min-h-[280px]">
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">All training modules for every SPSV category</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Practice tests with detailed feedback</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Interactive checklists for documentation</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Basic SPSV vehicle finder tool</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Links to official NTA and NCT resources</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Basic fee calculator</span>
                  </div>
                </div>
                
                <Link href={`/checkout?plan=BASIC`}>
                  <Button 
                    className={`w-full font-bold py-3 px-6 rounded-md mt-4 ${selectedPlan === "BASIC" ? "bg-secondary-500 hover:bg-secondary-600 text-white" : "bg-primary-500 hover:bg-primary-600 text-white"}`}
                    onClick={() => setSelectedPlan("BASIC")}
                  >
                    Select Basic Plan - €{PRICING_PLANS.BASIC.price}
                  </Button>
                </Link>
              </div>
            </div>
            
            {/* Standard Plan */}
            <div className={`bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 transform ${selectedPlan === "STANDARD" ? "scale-105 ring-2 ring-primary-500" : "hover:scale-102"}`}>
              <div className="bg-primary-500 p-6 text-center text-white relative">
                {/* Popular badge */}
                <div className="absolute top-0 right-0 bg-secondary-500 text-white text-xs px-3 py-1 rounded-bl-lg font-bold uppercase tracking-wider">
                  Popular
                </div>
                <h3 className="text-2xl font-bold mb-2">{PRICING_PLANS.STANDARD.name}</h3>
                <div className="text-4xl font-bold mb-2">€{PRICING_PLANS.STANDARD.price}</div>
                <p className="text-primary-100">{PRICING_PLANS.STANDARD.duration} days access</p>
              </div>
              
              <div className="p-6">
                <div className="space-y-3 min-h-[280px]">
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">All training modules for every SPSV category</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Unlimited practice tests with detailed feedback</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Interactive checklists for all documentation</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">SPSV vehicle finder tool</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Links to official NTA and NCT resources</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Fee calculator and payment guidance</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Email support</span>
                  </div>
                </div>
                
                <Link href={`/checkout?plan=STANDARD`}>
                  <Button 
                    className={`w-full font-bold py-3 px-6 rounded-md mt-4 ${selectedPlan === "STANDARD" ? "bg-secondary-500 hover:bg-secondary-600 text-white" : "bg-primary-500 hover:bg-primary-600 text-white"}`}
                    onClick={() => setSelectedPlan("STANDARD")}
                  >
                    Select Standard Plan - €{PRICING_PLANS.STANDARD.price}
                  </Button>
                </Link>
              </div>
            </div>
            
            {/* Premium Plan */}
            <div className={`bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 transform ${selectedPlan === "PREMIUM" ? "scale-105 ring-2 ring-primary-500" : "hover:scale-102"}`}>
              <div className="bg-primary-600 p-6 text-center text-white relative">
                <h3 className="text-2xl font-bold mb-2">{PRICING_PLANS.PREMIUM.name}</h3>
                <div className="text-4xl font-bold mb-2">€{PRICING_PLANS.PREMIUM.price}</div>
                <p className="text-primary-100">{PRICING_PLANS.PREMIUM.duration} days access</p>
              </div>
              
              <div className="p-6">
                <div className="space-y-3 min-h-[280px]">
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">All training modules for every SPSV category</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Unlimited practice tests with detailed feedback</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Interactive checklists for all documentation</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">SPSV vehicle finder tool</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Links to official NTA and NCT resources</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Advanced fee calculator and payment guidance</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Priority email support</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-neutral-700 text-sm">Free updates when regulations change</span>
                  </div>
                </div>
                
                <Link href={`/checkout?plan=PREMIUM`}>
                  <Button 
                    className={`w-full font-bold py-3 px-6 rounded-md mt-4 ${selectedPlan === "PREMIUM" ? "bg-secondary-500 hover:bg-secondary-600 text-white" : "bg-primary-500 hover:bg-primary-600 text-white"}`}
                    onClick={() => setSelectedPlan("PREMIUM")}
                  >
                    Select Premium Plan - €{PRICING_PLANS.PREMIUM.price}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <p className="text-neutral-600 mb-4">
              All plans include a money-back guarantee and secure payment processing through Stripe.
            </p>
            <p className="text-sm text-neutral-500">
              VAT (23%) is included in all prices. Billing occurs once at the start of your subscription period.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}