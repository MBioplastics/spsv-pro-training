import { useEffect } from "react";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

export default function Logout() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    const performLogout = async () => {
      try {
        await apiRequest("GET", "/api/logout");
        // Clear user data from cache
        queryClient.setQueryData(["/api/user"], null);
        toast({
          title: "Logged out",
          description: "You have been successfully logged out.",
        });
        // Redirect to home page
        navigate("/");
      } catch (error) {
        console.error("Logout error:", error);
        toast({
          title: "Logout failed",
          description: "There was an error logging out. Please try again.",
          variant: "destructive",
        });
        navigate("/");
      }
    };

    performLogout();
  }, [navigate, toast]);

  return (
    <div className="h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <h1 className="text-xl font-medium mb-2">Logging out...</h1>
        <p className="text-neutral-500">Please wait while we sign you out.</p>
      </div>
    </div>
  );
}