import { useState, useEffect } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";

console.log("Stripe public key:", import.meta.env.VITE_STRIPE_PUBLIC_KEY);
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY!);

const PaymentForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Force ready state after 3 seconds if Stripe is loaded
    const timer = setTimeout(() => {
      if (stripe && elements) {
        console.log("Force setting ready state");
        setIsReady(true);
      }
    }, 3000);

    if (stripe && elements) {
      setIsReady(true);
      clearTimeout(timer);
    }

    return () => clearTimeout(timer);
  }, [stripe, elements]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!stripe || !elements || !isReady) {
      console.log("Stripe not ready:", { stripe: !!stripe, elements: !!elements, isReady });
      return;
    }
    
    setIsLoading(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/checkout`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    }
    
    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="text-neutral-700">
        <p className="mb-2 font-medium">SPSV Training - Standard Plan</p>
        <div className="flex items-center justify-between pb-4 border-b border-gray-200">
          <span>60 days access</span>
          <span className="font-semibold">€109.00</span>
        </div>
      </div>
      
      <PaymentElement 
        options={{
          layout: "tabs"
        }}
        onReady={() => setIsReady(true)}
      />
      
      <Button 
        type="submit" 
        className="w-full bg-primary-500 hover:bg-primary-600"
        disabled={!stripe || !elements || !isReady || isLoading}
      >
        {isLoading ? "Processing..." : isReady ? "Pay €109.00" : "Loading..."}
      </Button>
      
      <div className="text-xs text-neutral-500 text-center">
        Your payment is secured by Stripe. We do not store your payment details.
      </div>
    </form>
  );
};

export default function PaymentTest() {
  const [clientSecret, setClientSecret] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const createPaymentIntent = async () => {
      try {
        const response = await apiRequest("POST", "/api/create-payment-intent", {
          planType: "STANDARD",
          amount: 109
        });
        
        const data = await response.json();
        
        if (data.clientSecret) {
          setClientSecret(data.clientSecret);
        } else {
          setError("Payment setup failed");
        }
      } catch (err) {
        console.error("Payment setup error:", err);
        setError("Payment setup failed");
      }
    };

    createPaymentIntent();
  }, []);

  if (error) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center px-4 py-12 bg-gray-50">
          <Card className="w-full max-w-md">
            <CardContent className="p-6">
              <div className="text-center text-red-600">
                <p>Unable to initialise payment. Please try again later.</p>
                <Button 
                  onClick={() => window.location.reload()} 
                  className="mt-4"
                  variant="outline"
                >
                  Retry
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center px-4 py-12 bg-gray-50">
          <Card className="w-full max-w-md">
            <CardContent className="p-6">
              <div className="text-center">
                <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full mx-auto mb-4" />
                <p>Setting up payment...</p>
              </div>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow flex items-center justify-center px-4 py-12 bg-gray-50">
        <div className="w-full max-w-md">
          <Card>
            <CardHeader>
              <CardTitle>Complete Your Purchase</CardTitle>
              <CardDescription>
                Access all SPSV training materials and features
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Elements stripe={stripePromise} options={{ clientSecret }}>
                <PaymentForm />
              </Elements>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}