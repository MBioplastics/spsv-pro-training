import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { HeroSection } from "@/components/home/hero-section";
import { FeaturesSection } from "@/components/home/features-section";
import { ApplicationPreview } from "@/components/home/application-preview";
import { TrainingModules } from "@/components/home/training-modules";
import { ChecklistExample } from "@/components/home/checklist-example";
import { PricingSection } from "@/components/home/pricing-section";
import { Testimonials } from "@/components/home/testimonials";
import { FAQSection } from "@/components/home/faq-section";
import { AboutSection } from "@/components/home/about-section";
import { ContactSection } from "@/components/home/contact-section";
import { CTASection } from "@/components/home/cta-section";
import { SEOContent } from "@/components/home/seo-content";
import { MetaTags } from "@/components/meta-tags";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <MetaTags 
        title="SPSV Training Ireland | PSV Training | Licence Training | Limo Licence | Wheelchair Accessible"
        description="Ireland's #1 SPSV Training, PSV Training & Licence Training platform. Complete training for taxi, hackney, limo licence & wheelchair accessible vehicles. Pass your SPSV exam first time with comprehensive training modules and specialised area knowledge for select Irish counties."
        keywords="SPSV, PSV, PSV training, SPSV training, licence training, training, limo licence, limousine licence, taxi licence Ireland, hackney licence, wheelchair accessible taxi, wheelchair accessible vehicle training, NTA training, small public service vehicle, PSV certification, SPSV certification, taxi exam preparation, Irish taxi training, taxi driver course Ireland, hackney driver training, limousine driver course, accessible taxi training, Dublin taxi licence, Cork taxi licence, Galway taxi licence"
        canonicalUrl="https://www.spsvprotraining.ie/"
      />
      <Header />
      <main className="flex-grow">
        <HeroSection />
        <FeaturesSection />
        <ApplicationPreview />
        <TrainingModules />
        <ChecklistExample />
        <SEOContent />
        <PricingSection />
        <Testimonials />
        <AboutSection />
        <ContactSection />
        <FAQSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
