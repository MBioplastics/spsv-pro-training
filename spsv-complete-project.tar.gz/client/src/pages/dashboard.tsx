import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Sidebar } from "@/components/dashboard/sidebar";
import { ProgressOverview } from "@/components/dashboard/progress-overview";
import { TrainingModule } from "@/components/dashboard/training-module";
import { TRAINING_MODULES } from "@/lib/constants";

export default function Dashboard() {
  const [, navigate] = useLocation();

  // Fetch user data
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ["/api/user"],
    retry: false,
  });
  
  // Use the user's selected vehicle type from their profile
  const selectedVehicle = user?.vehicleType || "taxi";

  // Fetch training progress
  const { data: trainingProgress, isLoading: progressLoading } = useQuery({
    queryKey: ["/api/training/progress"],
    enabled: !!user,
  });

  // Calculate progress percentages
  const calculateTrainingProgress = () => {
    if (!trainingProgress || !trainingProgress.length) return 0;
    
    const moduleCount = TRAINING_MODULES.length;
    const completedCount = trainingProgress.filter(p => p.isCompleted).length;
    
    return Math.round((completedCount / moduleCount) * 100);
  };

  const calculatePracticeTestProgress = () => {
    // In a real app, this would be calculated from actual test data
    return 40;
  };

  const calculateChecklistProgress = () => {
    // In a real app, this would be calculated from actual checklist data
    return 60;
  };

  // Current module the user is working on
  const getCurrentModule = () => {
    if (!trainingProgress || !trainingProgress.length) {
      return TRAINING_MODULES[0];
    }
    
    // Find the first incomplete module for the selected vehicle type
    const incompleteModules = trainingProgress
      .filter(p => p.vehicleType === selectedVehicle && !p.isCompleted)
      .sort((a, b) => a.moduleId - b.moduleId);
    
    if (incompleteModules.length > 0) {
      const moduleId = incompleteModules[0].moduleId;
      return TRAINING_MODULES.find(m => m.id === moduleId) || TRAINING_MODULES[0];
    }
    
    // If all modules are complete, show the first one
    return TRAINING_MODULES[0];
  };

  // Handle continue button click
  const handleContinueModule = () => {
    const currentModule = getCurrentModule();
    navigate(`/module/${currentModule.id}?type=${selectedVehicle}`);
  };

  // Upcoming tasks section removed

  // Check if user is authenticated
  useEffect(() => {
    if (userError) {
      navigate("/login");
    }
  }, [userError, navigate]);
  
  // Check if user has purchased access
  if (user && !user.hasPurchased) {
    return (
      <div className="min-h-screen flex flex-col lg:flex-row">
        <Sidebar userName={user.username} userRole="user" />
        <main className="flex-1 p-8 lg:ml-64">
          <div className="max-w-4xl mx-auto">
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-6">
              <h2 className="text-xl font-semibold text-yellow-800 mb-2">Subscription Required</h2>
              <p className="text-yellow-700 mb-4">
                To access training materials, practice tests, and other premium features, you need to purchase a subscription.
              </p>
              <button
                onClick={() => navigate("/pricing")}
                className="bg-primary-500 hover:bg-primary-600 text-white font-medium py-2 px-4 rounded"
              >
                Choose Your Plan
              </button>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">What You'll Get With Your Subscription:</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Complete SPSV training modules for your vehicle type</li>
                <li>• Unlimited practice tests with detailed feedback</li>
                <li>• Interactive checklists for documentation requirements</li>
                <li>• SPSV vehicle finder tool</li>
                <li>• County-specific area knowledge training</li>
                <li>• Mock exams with real-time scoring</li>
              </ul>
            </div>
          </div>
        </main>
      </div>
    );
  }

  // Loading state
  if (userLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }

  const currentModule = getCurrentModule();
  const moduleProgress = trainingProgress?.find(p => 
    p.moduleId === currentModule.id && p.vehicleType === selectedVehicle
  )?.progress || 0;

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar 
        userName={user?.username || "User"} 
        userRole="SPSV Pro Training Driver Trainee" 
      />
      
      <div className="flex-1 overflow-auto pt-16 md:pt-0">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-neutral-800 mb-6">Dashboard</h1>
          
          <ProgressOverview
            trainingProgress={calculateTrainingProgress()}
            practiceTestProgress={calculatePracticeTestProgress()}
            checklistProgress={calculateChecklistProgress()}
          />
          
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-neutral-700">Continue Your Training</h2>
              <div className="text-sm bg-blue-50 text-blue-700 px-3 py-1 rounded">
                {selectedVehicle === 'taxi' && 'Taxi Training'}
                {selectedVehicle === 'hackney' && 'Hackney Training'}
                {selectedVehicle === 'limousine' && 'Limousine Training'}
                {selectedVehicle === 'wheelchair_accessible_taxi' && 'WAT Training'}
                {selectedVehicle === 'wheelchair_accessible_hackney' && 'WAH Training'}
                {selectedVehicle === 'local_area_hackney' && 'Local Area Hackney Training'}
              </div>
            </div>
            
            <TrainingModule
              title={`Module ${currentModule.id}: ${currentModule.title}`}
              description="Learn about the day-to-day responsibilities and best practices for SPSV operators."
              progress={moduleProgress}
              onContinue={handleContinueModule}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
