import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { SimpleCheckout } from "@/components/payment/simple-checkout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle } from "lucide-react";
import { PRICING_PLANS } from "@/lib/constants";
import { apiRequest } from "@/lib/queryClient";

export default function Checkout() {
  const [, navigate] = useLocation();
  const [isSuccess, setIsSuccess] = useState(false);
  // Get plan from URL immediately, don't wait for useEffect
  const searchParams = new URLSearchParams(window.location.search);
  const urlPlan = searchParams.get("plan");
  const initialPlan = (urlPlan && urlPlan in PRICING_PLANS) ? urlPlan as keyof typeof PRICING_PLANS : "BASIC";
  
  const [selectedPlan, setSelectedPlan] = useState<keyof typeof PRICING_PLANS>(initialPlan);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Update plan if URL changes
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const planParam = searchParams.get("plan");
    console.log("URL plan parameter:", planParam);
    if (planParam && planParam in PRICING_PLANS) {
      console.log("Setting selected plan to:", planParam);
      setSelectedPlan(planParam as keyof typeof PRICING_PLANS);
    }
  }, [window.location.search]);
  
  // Fetch user data
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ["/api/user"],
    retry: false,
  });
  
  // Check if payment in URL
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const paymentIntent = searchParams.get("payment_intent");
    const paymentIntentClientSecret = searchParams.get("payment_intent_client_secret");
    const redirectStatus = searchParams.get("redirect_status");
    
    // If payment was successful
    if (paymentIntent && paymentIntentClientSecret && redirectStatus === "succeeded") {
      setIsSuccess(true);
      
      // Confirm payment with server
      if (user) {
        apiRequest("POST", "/api/confirm-payment", { planType: selectedPlan })
          .then(() => {
            queryClient.invalidateQueries({ queryKey: ["/api/user"] });
            toast({
              title: "Payment confirmed",
              description: `Your ${PRICING_PLANS[selectedPlan].name} subscription has been activated.`,
            });
          })
          .catch(() => {
            toast({
              title: "Error",
              description: "There was an issue confirming your payment. Please contact support.",
              variant: "destructive",
            });
          });
      }
    }
  }, [window.location.search, user, queryClient, toast]);
  
  // Check if user is authenticated
  useEffect(() => {
    if (userError) {
      navigate("/login");
    }
  }, [userError, navigate]);
  
  // Already purchased
  if (user && user.hasPurchased) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center px-4 py-12 bg-gray-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <div className="flex items-center justify-center mb-4">
                <div className="rounded-full bg-secondary-100 p-3">
                  <CheckCircle className="h-8 w-8 text-secondary-500" />
                </div>
              </div>
              <CardTitle className="text-center">Already Subscribed</CardTitle>
              <CardDescription className="text-center">
                You already have access to all SPSV Pro Training materials
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="mb-4 text-neutral-600">
                You have already purchased the SPSV Pro Training package. You can access all training materials and features from your dashboard.
              </p>
              <button
                className="bg-primary-500 hover:bg-primary-600 text-white font-medium py-2 px-4 rounded"
                onClick={() => navigate("/dashboard")}
              >
                Go to Dashboard
              </button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }
  
  // Payment success
  if (isSuccess) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center px-4 py-12 bg-gray-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <div className="flex items-center justify-center mb-4">
                <div className="rounded-full bg-secondary-100 p-3">
                  <CheckCircle className="h-8 w-8 text-secondary-500" />
                </div>
              </div>
              <CardTitle className="text-center">Payment Successful</CardTitle>
              <CardDescription className="text-center">
                Thank you for purchasing the {PRICING_PLANS[selectedPlan].name} Plan
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="mb-4 text-neutral-600">
                Your payment has been processed successfully. You now have full access to all training materials and features
                for {PRICING_PLANS[selectedPlan].duration} days.
              </p>
              <button
                className="bg-primary-500 hover:bg-primary-600 text-white font-medium py-2 px-4 rounded"
                onClick={() => navigate("/dashboard")}
              >
                Go to Dashboard
              </button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }
  
  // Loading state
  if (userLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }
  
  // Normal checkout page
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow flex items-center justify-center px-4 py-12 bg-gray-50">
        <div className="w-full max-w-2xl">
          <SimpleCheckout selectedPlan={selectedPlan} />
        </div>
      </main>
      <Footer />
    </div>
  );

  // Old complex layout - keeping as backup
  const oldLayout = (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow flex items-center justify-center px-4 py-12 bg-gray-50">
        <div className="w-full max-w-4xl grid md:grid-cols-2 gap-8">
          <div>
            <h1 className="text-3xl font-bold mb-6">Complete Your Purchase</h1>
            <div className="bg-white rounded-lg p-6 mb-6 shadow-sm">
              <h2 className="text-xl font-semibold mb-4">What You're Getting</h2>
              <ul className="space-y-3">
                {selectedPlan === "BASIC" && (
                  <>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>All training modules for every SPSV category</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Practice tests with detailed feedback</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Interactive checklists for documentation</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Basic SPSV vehicle finder tool</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Links to official NTA and NCT resources</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Basic fee calculator</span>
                    </li>
                  </>
                )}
                {selectedPlan === "STANDARD" && (
                  <>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>All training modules for every SPSV category</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Unlimited practice tests with detailed feedback</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Interactive checklists for all documentation</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>SPSV vehicle finder tool</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Links to official NTA and NCT resources</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Fee calculator and payment guidance</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Email support</span>
                    </li>
                  </>
                )}
                {selectedPlan === "PREMIUM" && (
                  <>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>All training modules for every SPSV category</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Unlimited practice tests with detailed feedback</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Interactive checklists for all documentation</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>SPSV vehicle finder tool</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Links to official NTA and NCT resources</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Advanced fee calculator and payment guidance</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Priority email support</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-secondary-500 mr-2 mt-0.5" />
                      <span>Free updates when regulations change</span>
                    </li>
                  </>
                )}
              </ul>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
              <div className="flex justify-between py-2 border-b">
                <span>SPSV Pro Training - {PRICING_PLANS[selectedPlan].name} Plan</span>
                <span>€{PRICING_PLANS[selectedPlan].price.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span>VAT (23%)</span>
                <span>Included</span>
              </div>
              <div className="flex justify-between py-4 font-bold text-lg">
                <span>Total</span>
                <span>€{PRICING_PLANS[selectedPlan].price.toFixed(2)}</span>
              </div>
              <p className="text-sm text-neutral-500 mt-2">
                {PRICING_PLANS[selectedPlan].duration} days access to all features
              </p>
            </div>
          </div>
          <div>
            <SimpleCheckout selectedPlan={selectedPlan} />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
