import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { RegisterForm } from "@/components/auth/register-form";
import { useSearch } from "wouter";

export default function Register() {
  // Get the plan from URL parameters
  const search = useSearch();
  const params = new URLSearchParams(search);
  const selectedPlan = params.get('plan') || undefined;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow flex items-center justify-center px-4 py-12 bg-gray-50">
        <RegisterForm selectedPlan={selectedPlan} />
      </main>
      <Footer />
    </div>
  );
}
