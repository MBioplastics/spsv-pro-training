import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Sidebar } from "@/components/dashboard/sidebar";
import { PageHeader } from "@/components/shared/page-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { VehicleSelector } from "@/components/dashboard/vehicle-selector";
import { CalendarIcon, ExternalLink, MapPin, Clock, Calendar } from "lucide-react";
import { NCT_BOOKING_URL, NTA_WEBSITE } from "@/lib/constants";

export default function Bookings() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("nct");
  const { toast } = useToast();
  
  // Fetch user data
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ["/api/user"],
    retry: false,
  });
  
  // NCT Testing centers - comprehensive list of all centers in Ireland
  const nctCenters = [
    {
      id: 1,
      name: "Dublin (Northpoint)",
      address: "Northpoint Business Park, Old Swords Road, Santry, Dublin 9",
      phone: "01 413 5300",
      email: "northpoint@ncts.ie",
      availableDates: ["2024-12-15", "2024-12-18", "2024-12-22"]
    },
    {
      id: 2,
      name: "Dublin (Fonthill)",
      address: "Fonthill Industrial Park, Fonthill Road, Dublin 22",
      phone: "01 413 5720",
      email: "fonthill@ncts.ie",
      availableDates: ["2024-12-14", "2024-12-19", "2024-12-21"]
    },
    {
      id: 3,
      name: "Cork (Little Island)",
      address: "Little Island Industrial Estate, Little Island, Cork",
      phone: "021 430 0210",
      email: "littleisland@ncts.ie",
      availableDates: ["2024-12-16", "2024-12-20", "2024-12-23"]
    },
    {
      id: 4,
      name: "Cork (Blarney)",
      address: "Blarney Business Park, Blarney, Cork",
      phone: "021 432 4190",
      email: "blarney@ncts.ie",
      availableDates: ["2024-12-17", "2024-12-21", "2024-12-26"]
    },
    {
      id: 5,
      name: "Galway",
      address: "Doughiska Road, Galway",
      phone: "091 755 496",
      email: "galway@ncts.ie",
      availableDates: ["2024-12-17", "2024-12-21", "2024-12-28"]
    },
    {
      id: 6,
      name: "Limerick",
      address: "Eastway Business Park, Ballysimon Road, Limerick",
      phone: "061 309 120",
      email: "limerick@ncts.ie",
      availableDates: ["2024-12-15", "2024-12-19", "2024-12-23"]
    },
    {
      id: 7,
      name: "Waterford",
      address: "Cork Road, Waterford",
      phone: "051 336 210",
      email: "waterford@ncts.ie",
      availableDates: ["2024-12-14", "2024-12-18", "2024-12-22"]
    },
    {
      id: 8,
      name: "Letterkenny",
      address: "Bonagee, Letterkenny, Co. Donegal",
      phone: "074 918 9500",
      email: "letterkenny@ncts.ie",
      availableDates: ["2024-12-16", "2024-12-20", "2024-12-23"]
    },
    {
      id: 9,
      name: "Athlone",
      address: "Ganly Industrial Estate, Athlone, Co. Westmeath",
      phone: "090 642 9500",
      email: "athlone@ncts.ie",
      availableDates: ["2024-12-15", "2024-12-19", "2024-12-22"]
    },
    {
      id: 10,
      name: "Killarney",
      address: "Killarney Industrial Estate, Killarney, Co. Kerry",
      phone: "064 663 7600",
      email: "killarney@ncts.ie",
      availableDates: ["2024-12-14", "2024-12-18", "2024-12-21"]
    },
    {
      id: 11,
      name: "Sligo",
      address: "Carrowroe, Sligo",
      phone: "071 915 4400",
      email: "sligo@ncts.ie",
      availableDates: ["2024-12-17", "2024-12-21", "2024-12-27"]
    },
    {
      id: 12,
      name: "Dundalk",
      address: "Coes Road Industrial Estate, Dundalk, Co. Louth",
      phone: "042 935 9040",
      email: "dundalk@ncts.ie",
      availableDates: ["2024-12-16", "2024-12-20", "2024-12-23"]
    }
  ];
  
  // SPSV Testing centers - comprehensive list with complete contact details
  const spsvCenters = [
    {
      id: 1,
      name: "Dublin SPSV Center",
      address: "National Transport Authority, Harcourt Lane, Dublin 2",
      phone: "0818 064 000",
      email: "spsv@nationaltransport.ie",
      website: "https://www.nationaltransport.ie",
      hours: "Monday-Friday: 9:00-17:00",
      services: ["Driver Knowledge Tests", "Industry Knowledge Module", "Area Knowledge Module", "Vehicle Licensing", "Vehicle Inspections", "License Renewals", "Driver Display Card Issue"]
    },
    {
      id: 2,
      name: "Cork SPSV Center",
      address: "Block B, Blackpool Business Park, Cork",
      phone: "0818 064 000",
      email: "spsv.cork@nationaltransport.ie",
      website: "https://www.nationaltransport.ie",
      hours: "Monday-Friday: 9:00-17:00",
      services: ["Driver Knowledge Tests", "Industry Knowledge Module", "Area Knowledge Module", "Vehicle Licensing", "Vehicle Inspections", "License Renewals"]
    },
    {
      id: 3,
      name: "Galway SPSV Center",
      address: "Westside Business Park, Galway",
      phone: "0818 064 000",
      email: "spsv.galway@nationaltransport.ie",
      website: "https://www.nationaltransport.ie",
      hours: "Monday-Friday: 9:30-16:30",
      services: ["Driver Knowledge Tests", "Industry Knowledge Module", "Area Knowledge Module", "Vehicle Inspections"]
    },
    {
      id: 4,
      name: "Limerick SPSV Center",
      address: "Delta Retail Park, Ballysimon Road, Limerick",
      phone: "0818 064 000",
      email: "spsv.limerick@nationaltransport.ie",
      website: "https://www.nationaltransport.ie",
      hours: "Monday-Friday: 9:30-16:30",
      services: ["Driver Knowledge Tests", "Industry Knowledge Module", "Area Knowledge Module", "Vehicle Inspections"]
    },
    {
      id: 5,
      name: "Waterford SPSV Center",
      address: "Cork Road Business Park, Waterford",
      phone: "0818 064 000",
      email: "spsv.waterford@nationaltransport.ie",
      website: "https://www.nationaltransport.ie",
      hours: "Monday-Friday: 9:30-16:30 (Closed 13:00-14:00)",
      services: ["Driver Knowledge Tests", "Vehicle Inspections"]
    },
    {
      id: 6,
      name: "Killarney SPSV Test Center",
      address: "Killarney Industrial Estate, Killarney, Co. Kerry",
      phone: "0818 064 000",
      email: "spsv.killarney@nationaltransport.ie",
      website: "https://www.nationaltransport.ie",
      hours: "Tuesday, Thursday: 9:30-16:30",
      services: ["Driver Knowledge Tests", "Vehicle Inspections"]
    },
    {
      id: 7,
      name: "Sligo SPSV Test Center",
      address: "Finisklin Industrial Estate, Sligo",
      phone: "0818 064 000",
      email: "spsv.sligo@nationaltransport.ie",
      website: "https://www.nationaltransport.ie",
      hours: "Monday, Wednesday: 9:30-16:30",
      services: ["Driver Knowledge Tests", "Vehicle Inspections"]
    },
    {
      id: 8,
      name: "Dundalk SPSV Test Center",
      address: "Coes Road Industrial Estate, Dundalk, Co. Louth",
      phone: "0818 064 000",
      email: "spsv.dundalk@nationaltransport.ie",
      website: "https://www.nationaltransport.ie",
      hours: "Tuesday, Thursday: 9:30-16:30",
      services: ["Driver Knowledge Tests", "Vehicle Inspections"]
    },
    {
      id: 9,
      name: "Athlone SPSV Test Center",
      address: "Garrycastle Industrial Estate, Athlone, Co. Westmeath",
      phone: "0818 064 000",
      email: "spsv.athlone@nationaltransport.ie",
      website: "https://www.nationaltransport.ie",
      hours: "Wednesday, Friday: 9:30-16:30",
      services: ["Driver Knowledge Tests", "Vehicle Inspections"]
    },
    {
      id: 10,
      name: "Letterkenny SPSV Test Center",
      address: "Bonagee Business Park, Letterkenny, Co. Donegal",
      phone: "0818 064 000",
      email: "spsv.letterkenny@nationaltransport.ie",
      website: "https://www.nationaltransport.ie",
      hours: "Monday, Wednesday: 9:30-16:30",
      services: ["Driver Knowledge Tests", "Vehicle Inspections"]
    }
  ];
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IE', {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };
  
  // Handle NCT booking
  const handleBookNCT = () => {
    window.open(NCT_BOOKING_URL, '_blank');
  };
  
  // Handle SPSV booking
  const handleBookSPSV = () => {
    window.open(`${NTA_WEBSITE}/taxi/appointments`, '_blank');
  };
  
  // Check if user is authenticated
  useEffect(() => {
    if (userError) {
      navigate("/login");
    }
  }, [userError, navigate]);
  
  // Loading state
  if (userLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }
  
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar 
        userName={(user as any)?.username || "User"} 
        userRole="SPSV Driver Trainee" 
      />
      
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <PageHeader 
            title="Test & Inspection Bookings" 
            description="Book appointments for NCT, SPSV driver tests, and vehicle inspections"
          />
          
          <Tabs 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="mb-4">
              <TabsTrigger value="nct">NCT Bookings</TabsTrigger>
              <TabsTrigger value="spsv">SPSV Test Bookings</TabsTrigger>
            </TabsList>
            
            <TabsContent value="nct">
              <div className="mb-4">
                <p className="text-neutral-600 mb-2">
                  All vehicles operating as SPSVs must pass the National Car Test (NCT). 
                  Book your NCT appointment at one of the centers below.
                </p>
                <p className="text-neutral-600 mb-4">
                  SPSV vehicles may be subject to more frequent testing depending on age and use.
                </p>
                <Button 
                  className="bg-primary-500 hover:bg-primary-600 mb-6"
                  onClick={handleBookNCT}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Book NCT on Official Website
                </Button>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                {nctCenters.map((center) => (
                  <Card key={center.id}>
                    <CardHeader>
                      <CardTitle>{center.name}</CardTitle>
                      <CardDescription className="flex items-start">
                        <MapPin className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                        <span>{center.address}</span>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 mb-4">
                        <p className="text-sm text-neutral-600">
                          <strong>Phone:</strong> {center.phone}
                        </p>
                        <p className="text-sm text-neutral-600">
                          <strong>Email:</strong> {center.email}
                        </p>
                      </div>
                      <div className="mt-4">
                        <p className="text-sm font-medium mb-2">Available Dates:</p>
                        <div className="space-y-2">
                          {center.availableDates.map((date, index) => (
                            <div 
                              key={index}
                              className="flex items-center py-1 px-2 bg-gray-50 rounded-md text-sm"
                            >
                              <Calendar className="h-4 w-4 mr-2 text-primary-500" />
                              {formatDate(date)}
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        className="w-full"
                        variant="outline"
                        onClick={handleBookNCT}
                      >
                        Book Appointment
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="spsv">
              <div className="mb-4">
                <p className="text-neutral-600 mb-2">
                  Book appointments for SPSV driver tests and vehicle inspections at these National Transport Authority centers.
                </p>
                <p className="text-neutral-600 mb-4">
                  Driver tests must be booked at least 7 days in advance. Vehicle inspections should be booked at least 14 days before your intended start date.
                </p>
                <Button 
                  className="bg-primary-500 hover:bg-primary-600 mb-6"
                  onClick={handleBookSPSV}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Book on NTA Website
                </Button>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                {spsvCenters.map((center) => (
                  <Card key={center.id}>
                    <CardHeader>
                      <CardTitle>{center.name}</CardTitle>
                      <CardDescription className="flex items-start">
                        <MapPin className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                        <span>{center.address}</span>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 mb-4">
                        <p className="text-sm text-neutral-600">
                          <strong>Phone:</strong> {center.phone}
                        </p>
                        <p className="text-sm text-neutral-600">
                          <strong>Email:</strong> {center.email}
                        </p>
                        <p className="text-sm text-neutral-600">
                          <strong>Website:</strong> <a href={center.website} target="_blank" rel="noopener noreferrer" className="text-primary-500 hover:underline">{center.website}</a>
                        </p>
                        <p className="text-sm text-neutral-600">
                          <strong>Hours:</strong> {center.hours}
                        </p>
                      </div>
                      <div className="mt-4">
                        <p className="text-sm font-medium mb-2">Available Services:</p>
                        <div className="space-y-2">
                          {center.services.map((service, index) => (
                            <div 
                              key={index}
                              className="flex items-center py-1 px-2 bg-gray-50 rounded-md text-sm"
                            >
                              <Clock className="h-4 w-4 mr-2 text-primary-500" />
                              {service}
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        className="w-full"
                        variant="outline"
                        onClick={handleBookSPSV}
                      >
                        Book Appointment
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="mt-8 space-y-6">
            <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
              <h3 className="text-lg font-medium mb-2">Booking Real Appointments</h3>
              <p className="text-sm text-neutral-600 mb-2">
                This application redirects you to the official booking systems for both NCT and SPSV appointments. Due to regulatory requirements, all appointments must be made through official channels:
              </p>
              <ul className="list-disc pl-5 text-sm text-neutral-600 space-y-1">
                <li>NCT appointments are booked through the official <a href={NCT_BOOKING_URL} target="_blank" rel="noopener noreferrer" className="text-primary-500 hover:underline">NCTS website</a>.</li>
                <li>SPSV driver tests and vehicle inspections are booked through the <a href={`${NTA_WEBSITE}/taxi/appointments`} target="_blank" rel="noopener noreferrer" className="text-primary-500 hover:underline">NTA Portal</a>.</li>
                <li>Payment for tests and inspections is handled directly by these official systems.</li>
                <li>You will receive official confirmation emails from these authorities after booking.</li>
              </ul>
            </div>
            
            <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
              <h3 className="text-lg font-medium mb-2">Important Information</h3>
              <p className="text-sm text-neutral-600 mb-2">
                • NCT certificates must be valid throughout the period of your SPSV licence.
              </p>
              <p className="text-sm text-neutral-600 mb-2">
                • SPSV vehicles over 10 years old require more frequent NCT testing.
              </p>
              <p className="text-sm text-neutral-600 mb-2">
                • Failed inspections must be remedied and the vehicle re-presented within 21 days.
              </p>
              <p className="text-sm text-neutral-600 mb-2">
                • Bring all required documentation to your appointments to avoid delays.
              </p>
              <p className="text-sm text-neutral-600">
                • Different vehicle types have different inspection requirements and fees.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
