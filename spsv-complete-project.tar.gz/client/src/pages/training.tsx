import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Sidebar } from "@/components/dashboard/sidebar";
import { ModuleCard } from "@/components/training/module-card";
import { PageHeader } from "@/components/shared/page-header";
import { SectionHeader } from "@/components/shared/section-header";
import { Button } from "@/components/ui/button";
import { TRAINING_MODULES, SPSV_TYPES } from "@/lib/constants";
import { apiRequest } from "@/lib/queryClient";
import { MetaTags } from "@/components/meta-tags";

export default function Training() {
  const [, navigate] = useLocation();

  // Fetch user data
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ["/api/user"],
    retry: false,
  });
  
  // Use user's vehicle type rather than a selector
  const selectedVehicle = user?.vehicleType || "taxi";

  // Fetch training progress
  const { data: trainingProgress, isLoading: progressLoading, refetch: refetchProgress } = useQuery({
    queryKey: ["/api/training/progress"],
    enabled: !!user,
  });

  // Handle module selection
  const handleModuleClick = (moduleId: number) => {
    navigate(`/module/${moduleId}?type=${selectedVehicle}`);
  };

  // Get module progress
  const getModuleProgress = (moduleId: number) => {
    if (!trainingProgress) return 0;
    
    const module = trainingProgress.find(p => 
      p.moduleId === moduleId && p.vehicleType === selectedVehicle
    );
    
    return module?.progress || 0;
  };

  // Check if module is completed
  const isModuleCompleted = (moduleId: number) => {
    if (!trainingProgress) return false;
    
    const module = trainingProgress.find(p => 
      p.moduleId === moduleId && p.vehicleType === selectedVehicle
    );
    
    return module?.isCompleted || false;
  };

  // Get the selected vehicle name
  const getVehicleName = () => {
    return SPSV_TYPES.find(type => type.id === selectedVehicle)?.name || "Vehicle";
  };

  // Check if user is authenticated
  useEffect(() => {
    if (userError) {
      navigate("/login");
    }
  }, [userError, navigate]);

  // Check if user has purchased access
  if (user && !user.hasPurchased) {
    return (
      <div className="min-h-screen flex flex-col lg:flex-row">
        <Sidebar userName={user.username} userRole="user" />
        <main className="flex-1 p-8 lg:ml-64">
          <div className="max-w-4xl mx-auto">
            <PageHeader title="Training Modules" description="Subscription Required" />
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-6">
              <h2 className="text-xl font-semibold text-yellow-800 mb-2">Unlock Training Modules</h2>
              <p className="text-yellow-700 mb-4">
                Access comprehensive SPSV training materials designed for your vehicle type with a paid subscription.
              </p>
              <button
                onClick={() => navigate("/pricing")}
                className="bg-primary-500 hover:bg-primary-600 text-white font-medium py-2 px-4 rounded"
              >
                Choose Your Plan
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  // Loading state
  if (userLoading || progressLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-100">
      <MetaTags 
        title="SPSV Training Modules | Taxi, Hackney & Limousine Certification | Ireland"
        description="Access comprehensive SPSV training modules for taxi, hackney, and limousine certification. Interactive lessons covering industry knowledge, area knowledge, and customer service for Ireland."
        keywords="SPSV training modules, taxi certification Ireland, hackney training course, limousine driver training, PSV training content, NTA approved training"
        canonicalUrl="https://www.spsvprotraining.ie/training"
      />
      <Sidebar 
        userName={user?.username || "User"} 
        userRole="SPSV Driver Trainee" 
      />
      
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <PageHeader 
            title="Training Modules" 
            description="Complete the required modules to prepare for your SPSV driver test"
          />
          
          <div className="mb-6">
            <div>
              <h2 className="text-xl font-semibold">{getVehicleName()} Training</h2>
              <p className="text-neutral-600">
                Training materials customized for your {getVehicleName().toLowerCase()} license
              </p>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            {TRAINING_MODULES.map((module) => (
              <ModuleCard
                key={module.id}
                id={module.id}
                title={`Module ${module.id}: ${module.title}`}
                description={`Learn all about ${module.title.toLowerCase()} for ${getVehicleName()} operations.`}
                progress={getModuleProgress(module.id)}
                isCompleted={isModuleCompleted(module.id)}
                onClick={handleModuleClick}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
