import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Sidebar } from "@/components/dashboard/sidebar";
import { PageHeader } from "@/components/shared/page-header";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

// Import vehicle data from the constants file
import { SPSV_TYPES } from "@/lib/constants";

// Define types for our vehicle database
type VehicleData = {
  manufacturer: string;
  model: string;
  modelYear?: string;
  suitableTaxi: boolean;
  suitableHackney: boolean;
  suitableLimousine: boolean;
  notes?: string;
};

export default function VehicleSearch() {
  const [location, navigate] = useLocation();
  
  // Get user data from API
  const { data: user, error: userError, isLoading: userLoading } = useQuery({
    queryKey: ["/api/user"],
    queryFn: async ({ signal }) => {
      const res = await fetch("/api/user", { signal });
      if (!res.ok) {
        throw new Error("Unauthorised");
      }
      return res.json();
    },
  });
  
  // Get user's vehicle type for default tab
  const userVehicleType = user?.vehicleType || "taxi";
  
  // State for filters
  const [activeTab, setActiveTab] = useState(userVehicleType !== "local_area_hackney" && userVehicleType !== "wheelchair_accessible_taxi" ? userVehicleType : "taxi");
  const [searchTerm, setSearchTerm] = useState("");
  const [manufacturerFilter, setManufacturerFilter] = useState<string>("all");
  const [filteredVehicles, setFilteredVehicles] = useState<VehicleData[]>([]);

  // Aggregate vehicle data from the NTA PDF documents
  const ALL_VEHICLES: VehicleData[] = [
    { manufacturer: "Audi", model: "A3 (Saloon 2013-2020)", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    { manufacturer: "Audi", model: "A4 (Saloon 2008-2015)", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    { manufacturer: "Audi", model: "A5 Sportback", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Audi", model: "A6", suitableTaxi: true, suitableHackney: true, suitableLimousine: true },
    { manufacturer: "Audi", model: "A7", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Audi", model: "A8/A8L", suitableTaxi: true, suitableHackney: true, suitableLimousine: true },
    { manufacturer: "Audi", model: "Q7", suitableTaxi: true, suitableHackney: true, suitableLimousine: true },
    { manufacturer: "Audi", model: "Q5", suitableTaxi: true, suitableHackney: true, suitableLimousine: true },
    { manufacturer: "Audi", model: "e-tron", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    
    { manufacturer: "BMW", model: "3 Series", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    { manufacturer: "BMW", model: "4 Series", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "BMW", model: "5 Series", suitableTaxi: true, suitableHackney: true, suitableLimousine: true },
    { manufacturer: "BMW", model: "6 Series", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "BMW", model: "7 Series", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "BMW", model: "X4", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "BMW", model: "X5", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "BMW", model: "X6", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    
    { manufacturer: "Chrysler", model: "300C", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Ford", model: "Mondeo", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    { manufacturer: "Ford", model: "Mustang Mach-E", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    
    { manufacturer: "Hyundai", model: "i40", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    
    { manufacturer: "Jaguar", model: "XF", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Jaguar", model: "XJ Series", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    
    { manufacturer: "Kia", model: "Optima", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    
    { manufacturer: "Land Rover", model: "Discovery", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Land Rover", model: "Range Rover", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    
    { manufacturer: "Lexus", model: "GS Series", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Lexus", model: "LS Series", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Lexus", model: "RX Series", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    
    { manufacturer: "Mercedes-Benz", model: "CLS", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Mercedes-Benz", model: "E Class", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Mercedes-Benz", model: "S Class", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Mercedes-Benz", model: "EQ Series", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    
    { manufacturer: "Porsche", model: "Cayenne", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Porsche", model: "Panamera", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    
    { manufacturer: "Skoda", model: "Octavia", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    { manufacturer: "Skoda", model: "Superb", suitableTaxi: true, suitableHackney: true, suitableLimousine: true },
    
    { manufacturer: "Tesla", model: "Model S", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Tesla", model: "Model X", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    
    { manufacturer: "Toyota", model: "Avensis", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    { manufacturer: "Toyota", model: "Corolla", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    { manufacturer: "Toyota", model: "Prius", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    
    { manufacturer: "Volkswagen", model: "Passat", suitableTaxi: true, suitableHackney: true, suitableLimousine: false },
    { manufacturer: "Volkswagen", model: "Phaeton", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    
    { manufacturer: "Volvo", model: "S90", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
    { manufacturer: "Volvo", model: "XC90", suitableTaxi: false, suitableHackney: false, suitableLimousine: true },
  ];

  // Vehicle manufacturers list for filter dropdown
  const manufacturers = Array.from(
    new Set(
      ALL_VEHICLES.map((vehicle) => vehicle.manufacturer)
    )
  ).sort();

  // Filter vehicles when searchTerm or manufacturerFilter changes
  useEffect(() => {
    let filtered = [...ALL_VEHICLES];
    
    // Filter by tab
    if (activeTab === "taxi") {
      filtered = filtered.filter(v => v.suitableTaxi);
    } else if (activeTab === "hackney") {
      filtered = filtered.filter(v => v.suitableHackney);
    } else if (activeTab === "limousine") {
      filtered = filtered.filter(v => v.suitableLimousine);
    }
    
    // Filter by manufacturer
    if (manufacturerFilter !== "all") {
      filtered = filtered.filter(v => v.manufacturer === manufacturerFilter);
    }
    
    // Filter by search term
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(v => 
        v.manufacturer.toLowerCase().includes(search) || 
        v.model.toLowerCase().includes(search)
      );
    }
    
    setFilteredVehicles(filtered);
  }, [searchTerm, manufacturerFilter, activeTab]);

  // Check if user is authenticated
  useEffect(() => {
    if (userError) {
      navigate("/login");
    }
  }, [userError, navigate]);

  // Loading state
  if (userLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar
        userName={(user as any)?.username || "User"}
        userRole="SPSV Driver Trainee"
      />

      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <PageHeader
            title="NTA Approved Vehicles"
            description="Search for suitable vehicles for different SPSV licence types"
          />
          
          {/* Show info about the default filter based on user's vehicle type */}
          <div className="mb-4 bg-blue-50 p-3 rounded-md text-blue-800 text-sm">
            <p>
              Based on your selected vehicle type ({SPSV_TYPES.find(t => t.id === userVehicleType)?.name || 'Taxi'}), 
              we've automatically filtered the list to show appropriate vehicles. You can change the filter using the tabs below.
            </p>
          </div>

          <div className="mb-6 grid grid-cols-1 gap-6 md:grid-cols-[1fr_300px]">
            <div>
              <Input
                placeholder="Search by manufacturer or model..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            <div>
              <Select value={manufacturerFilter} onValueChange={setManufacturerFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Select manufacturer" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Manufacturers</SelectItem>
                  {manufacturers.map((manufacturer) => (
                    <SelectItem key={manufacturer} value={manufacturer}>
                      {manufacturer}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Tabs defaultValue={activeTab} className="mb-6" onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Vehicles</TabsTrigger>
              <TabsTrigger value="taxi">Taxi Suitable</TabsTrigger>
              <TabsTrigger value="hackney">Hackney Suitable</TabsTrigger>
              <TabsTrigger value="limousine">Limousine Suitable</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-0">
              <VehicleList vehicles={filteredVehicles} />
            </TabsContent>
            <TabsContent value="taxi" className="mt-0">
              <VehicleList vehicles={filteredVehicles} />
            </TabsContent>
            <TabsContent value="hackney" className="mt-0">
              <VehicleList vehicles={filteredVehicles} />
            </TabsContent>
            <TabsContent value="limousine" className="mt-0">
              <VehicleList vehicles={filteredVehicles} />
            </TabsContent>
          </Tabs>
          
          <div className="bg-white p-4 rounded-lg shadow-sm text-sm text-gray-500 mt-6">
            <p className="mb-2">
              <strong>Important Notes:</strong>
            </p>
            <ul className="list-disc pl-5 space-y-1">
              <li>This vehicle list is based on NTA guidance documents and may not be exhaustive.</li>
              <li>All vehicles are still required to pass the relevant suitability inspection prior to being granted an SPSV licence.</li>
              <li>Vehicles must meet specific dimensional requirements for each licence type.</li>
              <li>Vehicles with privacy glass generally do not meet the clear windows requirement for taxis and hackneys.</li>
              <li>Vehicles modified for seating require a Technical Assessor's Full Report with supporting test proof.</li>
              <li>Maximum vehicle age is 10 years for most licence types.</li>
              <li>For the most current information, please contact the NTA directly at 0818 064 000.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

// Component to display the list of vehicles
function VehicleList({ vehicles }: { vehicles: VehicleData[] }) {
  if (vehicles.length === 0) {
    return (
      <div className="text-center p-8 bg-white rounded-md shadow-sm">
        <p className="text-gray-500">No vehicles match your search criteria.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {vehicles.map((vehicle, index) => (
        <Card key={index} className="overflow-hidden">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-lg">{vehicle.manufacturer}</CardTitle>
            <CardDescription className="text-sm font-medium">{vehicle.model}</CardDescription>
          </CardHeader>
          <CardContent className="p-4 pt-2">
            <div className="mt-2 grid grid-cols-3 gap-1 text-xs">
              <div className={`p-1 text-center rounded ${vehicle.suitableTaxi ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-500'}`}>
                Taxi {vehicle.suitableTaxi ? '✓' : '✗'}
              </div>
              <div className={`p-1 text-center rounded ${vehicle.suitableHackney ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-500'}`}>
                Hackney {vehicle.suitableHackney ? '✓' : '✗'}
              </div>
              <div className={`p-1 text-center rounded ${vehicle.suitableLimousine ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-500'}`}>
                Limo {vehicle.suitableLimousine ? '✓' : '✗'}
              </div>
            </div>
            {vehicle.notes && (
              <p className="mt-2 text-xs text-gray-500">{vehicle.notes}</p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}