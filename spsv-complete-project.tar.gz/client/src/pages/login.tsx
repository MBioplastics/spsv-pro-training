import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { LoginForm } from "@/components/auth/login-form";
import { useSearch } from "wouter";

export default function Login() {
  // Get the redirect and plan from URL parameters
  const search = useSearch();
  const params = new URLSearchParams(search);
  const redirectTo = params.get('redirectTo') || undefined;
  const selectedPlan = params.get('plan') || undefined;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow flex items-center justify-center px-4 py-12 bg-gray-50">
        <LoginForm redirectTo={redirectTo} selectedPlan={selectedPlan} />
      </main>
      <Footer />
    </div>
  );
}
