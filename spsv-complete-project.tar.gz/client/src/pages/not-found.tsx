import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, Home, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";

export default function NotFound() {
  // Set proper document title for SEO
  useEffect(() => {
    document.title = "Page Not Found - SPSV Pro Training";
    
    // Add meta description for 404 page
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'The page you are looking for could not be found. Return to SPSV Pro Training homepage for Irish taxi, limousine and hackney certification training.');
    }
  }, []);

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gray-50">
      <Card className="w-full max-w-lg mx-4">
        <CardContent className="pt-6 text-center">
          <div className="flex justify-center mb-6">
            <AlertCircle className="h-16 w-16 text-red-500" />
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            404 - Page Not Found
          </h1>

          <p className="text-gray-600 mb-6">
            The page you're looking for doesn't exist or has been moved.
          </p>

          <div className="space-y-3">
            <Link href="/">
              <Button className="w-full" size="lg">
                <Home className="w-4 h-4 mr-2" />
                Return to Homepage
              </Button>
            </Link>
            
            <Link href="/training">
              <Button variant="outline" className="w-full" size="lg">
                <ArrowLeft className="w-4 h-4 mr-2" />
                View Training Modules
              </Button>
            </Link>
          </div>

          <div className="mt-6 text-sm text-gray-500">
            <p>Looking for SPSV training? Try these popular pages:</p>
            <div className="flex flex-wrap justify-center gap-2 mt-2">
              <Link href="/pricing" className="text-blue-600 hover:underline">Pricing</Link>
              <span>•</span>
              <Link href="/practice-tests" className="text-blue-600 hover:underline">Practice Tests</Link>
              <span>•</span>
              <Link href="/vehicle-search" className="text-blue-600 hover:underline">Vehicle Search</Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
