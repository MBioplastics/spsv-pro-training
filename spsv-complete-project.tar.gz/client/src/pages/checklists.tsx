import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Sidebar } from "@/components/dashboard/sidebar";
import { PageHeader } from "@/components/shared/page-header";
import { SectionHeader } from "@/components/shared/section-header";
import { ChecklistGroup } from "@/components/checklist/checklist-group";
import { ChecklistItemData } from "@/components/checklist/checklist-item";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";
import { VEHICLE_REQUIREMENTS, SPSV_TYPES } from "@/lib/constants";

export default function Checklists() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("driver");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch user data
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ["/api/user"],
    retry: false,
  });
  
  // Use user's selected vehicle type
  const selectedVehicle = user?.vehicleType || "taxi";
  
  // Fetch saved checklists
  const { data: savedChecklists, isLoading: checklistsLoading } = useQuery({
    queryKey: ["/api/checklists"],
    enabled: !!user,
  });
  
  // Save checklist mutation
  const saveChecklistMutation = useMutation({
    mutationFn: async (data: { checklistType: string, vehicleType: string, items: any }) => {
      return apiRequest("POST", "/api/checklists", data)
        .then(res => res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/checklists"] });
      toast({
        title: "Checklist saved",
        description: "Your checklist progress has been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save checklist. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Base driver licence checklist - common requirements for all SPSV types
  const baseDriverLicenceChecklist: ChecklistItemData[] = [
    {
      id: "check1",
      title: "Valid Full Irish/EU/EEA Driving Licence",
      description: "Must be held for a minimum of 2 years",
      tooltipText: "Your driving licence must be in date and valid for the categories of vehicles you intend to drive. It must not have any disqualifications or endorsements that would prevent you from providing SPSV services.",
      isCompleted: false
    },
    {
      id: "check2",
      title: "Garda Vetting Application",
      description: "National Vetting Bureau application must be submitted and approved",
      tooltipText: "Garda vetting is required for all SPSV licence applications. This process checks for any criminal convictions or pending prosecutions that could affect your suitability to transport passengers.",
      isCompleted: false
    },
    {
      id: "check3",
      title: "Tax Clearance Certificate",
      description: "Up-to-date Revenue Tax Clearance Certificate",
      tooltipText: "You must have current tax clearance from Revenue. This confirms you are compliant with tax obligations. You can apply for tax clearance online through Revenue's ROS system.",
      isCompleted: false
    },
    {
      id: "check4",
      title: "SPSV Entry Test Certificate",
      description: "Pass certificate from the NTA SPSV entry test",
      tooltipText: "The SPSV Entry Test assesses your knowledge of the industry, regulations, and area knowledge. You must pass this test before being granted an SPSV driver licence.",
      isCompleted: false
    },
    {
      id: "check5",
      title: "Application Fee Payment",
      description: "€250 SPSV driver licence fee",
      tooltipText: "The fee must be paid in full when submitting your application. Payment can be made online through the NTA website or by bank draft/postal order.",
      isCompleted: false
    },
    {
      id: "check6",
      title: "Passport-sized Photographs",
      description: "Two recent passport-sized photographs",
      tooltipText: "Photos must be recent (taken within the last 6 months), in color, with a plain white background. They will be used for your driver display card and records.",
      isCompleted: false
    }
  ];
  
  // Generate vehicle licence checklist based on selected vehicle type
  const getVehicleLicenceChecklist = (vehicleType: string): ChecklistItemData[] => {
    // Get requirements for the selected vehicle type
    const vehicleReqs = VEHICLE_REQUIREMENTS[vehicleType as keyof typeof VEHICLE_REQUIREMENTS];
    
    if (!vehicleReqs) {
      return [];
    }
    
    const baseChecklist = [
      {
        id: "vcheck1",
        title: "Vehicle Ownership or Permission to Use",
        description: "Proof of vehicle ownership or written permission from the owner",
        tooltipText: "You must be the registered owner of the vehicle or have written permission from the owner to use the vehicle as an SPSV.",
        isCompleted: false
      },
      {
        id: "vcheck2",
        title: "Current NCT Certificate",
        description: "Valid National Car Test certificate for the vehicle",
        tooltipText: "Your vehicle must have a valid NCT certificate. Vehicles over 10 years old may be subject to more frequent testing requirements.",
        isCompleted: false
      },
      {
        id: "vcheck3",
        title: "Motor Insurance Certificate",
        description: "Insurance policy covering use as an SPSV",
        tooltipText: "You must have appropriate insurance that specifically covers the use of the vehicle as an SPSV. Standard motor insurance is not sufficient.",
        isCompleted: false
      }
    ];
    
    // Add vehicle type specific items
    const specificItems: ChecklistItemData[] = [
      {
        id: "vcheck4",
        title: "Vehicle Licence Fee Payment",
        description: `€${vehicleReqs.initialLicenseFee} initial licence fee (€${vehicleReqs.renewalFee} for renewals)`,
        tooltipText: vehicleType.includes('wheelchair') 
          ? "Wheelchair accessible vehicles benefit from a 50% reduced fee to encourage their availability."
          : vehicleType === 'limousine'
          ? "Limousines have a one-off fee of €1000 for initial licensing, with annual renewals at €150."
          : "The fee must be paid in full when submitting your application.",
        isCompleted: false
      },
      {
        id: "vcheck5",
        title: "Vehicle Age Compliance",
        description: `Vehicle must be less than ${vehicleReqs.maxAge} years old`,
        tooltipText: vehicleType === 'limousine'
          ? "Limousines can exceed the 10-year age limit if maintained to manufacturer specifications and pass suitability tests."
          : `All ${vehicleType.replace('_', ' ')} vehicles must be less than ${vehicleReqs.maxAge} years old from date of first registration.`,
        isCompleted: false
      },
      {
        id: "vcheck6",
        title: "Vehicle Suitability Inspection",
        description: `€${vehicleReqs.suitabilityTestFee} fee, required every ${vehicleReqs.suitabilityFrequency} months`,
        tooltipText: vehicleType === 'limousine'
          ? "Limousines require suitability inspections every 6 months, more frequently than other SPSV types."
          : `Your vehicle must pass an SPSV suitability inspection every ${vehicleReqs.suitabilityFrequency} months to ensure it meets all requirements.`,
        isCompleted: false
      }
    ];
    
    // Add taximeter requirement for taxis
    if (vehicleType.includes('taxi')) {
      const meterCost = 'meterCost' in vehicleReqs ? vehicleReqs.meterCost : 55;
      specificItems.push({
        id: "vcheck7",
        title: "Taximeter Verification",
        description: `€${meterCost} fee for calibration by Legal Metrology Service`,
        tooltipText: "Taxis must have a properly calibrated taximeter that has been verified by the Legal Metrology Service. This ensures fare calculations are accurate.",
        isCompleted: false
      });
    }
    
    // Add vehicle conformance to approved models
    specificItems.push({
      id: "vcheck8",
      title: "Vehicle Model Compliance",
      description: "Vehicle must be on the NTA approved list for this licence type",
      tooltipText: `Recommended models include: ${vehicleReqs.acceptableVehicles.slice(0, 5).join(', ')}, and others that meet the dimensional requirements.`,
      isCompleted: false
    });
    
    return [...baseChecklist, ...specificItems];
  };

  // Get saved checklist data or generate new checklist based on current vehicle type
  const getChecklistItems = (type: string) => {
    // If we have saved checklists, try to find one matching the current type and vehicle
    if (savedChecklists && Array.isArray(savedChecklists)) {
      const savedList = savedChecklists.find(
        (cl: any) => cl.checklistType === type && cl.vehicleType === selectedVehicle
      );
      
      if (savedList) return savedList.items;
    }
    
    // Otherwise generate a new checklist based on the current vehicle type
    return type === "driver" 
      ? baseDriverLicenceChecklist 
      : getVehicleLicenceChecklist(selectedVehicle);
  };
  
  // Handle saving checklist
  const handleSaveChecklist = (type: string, items: ChecklistItemData[]) => {
    saveChecklistMutation.mutate({
      checklistType: type,
      vehicleType: selectedVehicle,
      items
    });
  };
  
  // Check if user is authenticated
  useEffect(() => {
    if (userError) {
      navigate("/login");
    }
  }, [userError, navigate]);
  
  // State for current checklist items - will force re-render
  const [driverChecklist, setDriverChecklist] = useState<ChecklistItemData[]>([]);
  const [vehicleChecklist, setVehicleChecklist] = useState<ChecklistItemData[]>([]);

  // Update checklists when vehicle type changes
  useEffect(() => {
    // Re-create checklists based on current vehicle type
    setDriverChecklist(getChecklistItems("driver"));
    setVehicleChecklist(getChecklistItems("vehicle"));
    // Also invalidate the cache query
    queryClient.invalidateQueries({ queryKey: ["/api/checklists"] });
  }, [selectedVehicle, queryClient]);
  
  // Loading state
  if (userLoading || checklistsLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }
  
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar 
        userName={(user as any)?.username || "User"} 
        userRole="SPSV Driver Trainee" 
      />
      
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <PageHeader 
            title="Licence Requirements Checklists" 
            description="Track your progress with these comprehensive checklists"
          />
          
          <div className="mb-6 flex justify-between items-center">
            <Tabs 
              value={activeTab} 
              onValueChange={setActiveTab}
              className="w-full"
            >
              <TabsList className="mb-4">
                <TabsTrigger value="driver">Driver Licence</TabsTrigger>
                <TabsTrigger value="vehicle">Vehicle Licence</TabsTrigger>
              </TabsList>
              
              <div className="flex justify-between mb-4">
                <p className="text-neutral-600">
                  Use these checklists to ensure you have all the required documentation and meet all the criteria for your {SPSV_TYPES.find(t => t.id === selectedVehicle)?.name.toLowerCase() || 'vehicle'}.
                </p>
              </div>
              
              <TabsContent value="driver">
                <ChecklistGroup
                  title="Driver Licence Requirements"
                  items={driverChecklist}
                  onSave={(items) => handleSaveChecklist("driver", items)}
                />
              </TabsContent>
              
              <TabsContent value="vehicle">
                <ChecklistGroup
                  title="Vehicle Licence Requirements"
                  items={vehicleChecklist}
                  onSave={(items) => handleSaveChecklist("vehicle", items)}
                />
                
                {/* Vehicle specific guidance */}
                {VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS] && (
                  <div className="mt-8 space-y-6">
                    <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                      <h3 className="text-lg font-medium mb-3">NTA Approved Vehicles - {SPSV_TYPES.find(t => t.id === selectedVehicle)?.name}</h3>
                      <p className="text-sm text-neutral-600 mb-4">
                        The National Transport Authority recommends these vehicle models for use as a {SPSV_TYPES.find(t => t.id === selectedVehicle)?.name.toLowerCase()}.
                        Other models may also be acceptable if they meet the dimensional and technical requirements.
                      </p>
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                        {VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS]?.acceptableVehicles.map((vehicle, index) => (
                          <div 
                            key={index}
                            className="bg-white p-2 rounded border border-neutral-200 text-center text-sm"
                          >
                            {vehicle}
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                      <h3 className="text-lg font-medium mb-3">Licence Fee Structure</h3>
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="font-medium">Initial Licence Fee:</div>
                          <div>€{VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS]?.initialLicenseFee}</div>
                          
                          <div className="font-medium">Renewal Fee:</div>
                          <div>€{VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS]?.renewalFee}</div>
                          
                          <div className="font-medium">Suitability Test Fee:</div>
                          <div>€{VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS]?.suitabilityTestFee}</div>
                          
                          <div className="font-medium">Suitability Test Frequency:</div>
                          <div>Every {VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS]?.suitabilityFrequency} months</div>
                          
                          <div className="font-medium">Maximum Vehicle Age:</div>
                          <div>{VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS]?.maxAge} years</div>
                          
                          {selectedVehicle.includes('taxi') && VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS] && 'meterCost' in VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS] && (
                            <>
                              <div className="font-medium">Taximeter Verification Fee:</div>
                              <div>€{(VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS] as any).meterCost}</div>
                            </>
                          )}
                          
                          {selectedVehicle === 'limousine' && (
                            <>
                              <div className="font-medium col-span-2 pt-2 text-primary-600">
                                Note: Limousines have a one-off €1000 initial licence fee, with subsequent annual renewal at €150.
                                They require more frequent suitability testing (every 6 months) than other vehicle types.
                              </div>
                            </>
                          )}
                          
                          {selectedVehicle.includes('wheelchair') && (
                            <>
                              <div className="font-medium col-span-2 pt-2 text-primary-600">
                                Note: Wheelchair accessible vehicles receive a 50% discount on licence fees to encourage their availability.
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-200">
                      <h3 className="text-lg font-medium mb-3">Vehicle Requirements</h3>
                      <ul className="list-disc pl-5 space-y-1 text-sm">
                        {VEHICLE_REQUIREMENTS[selectedVehicle as keyof typeof VEHICLE_REQUIREMENTS]?.vehicleRequirements.map((req, index) => (
                          <li key={index} className="text-neutral-600">{req}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
