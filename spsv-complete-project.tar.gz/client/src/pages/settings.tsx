import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { PageHeader } from "@/components/shared/page-header";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Button } from "@/components/ui/button";
import { InfoIcon } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { SPSV_TYPES } from "@/lib/constants";

export default function Settings() {
  const [showTestAccounts, setShowTestAccounts] = useState(false);
  const [showVehicleType, setShowVehicleType] = useState(true);
  
  // Get user data from API
  const { data: user, error: userError, isLoading: userLoading } = useQuery({
    queryKey: ["/api/user"],
    queryFn: async ({ signal }) => {
      const res = await fetch("/api/user", { signal });
      if (!res.ok) {
        throw new Error("Unauthorised");
      }
      return res.json();
    },
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow px-4 py-12 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <PageHeader 
            title="Account Settings"
            description="Manage your account settings and preferences"
          />
          
          <div className="grid md:grid-cols-3 gap-8 mt-8">
            <div className="md:col-span-1">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Navigation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <nav className="space-y-2">
                      <Button variant="ghost" className="w-full justify-start font-normal" disabled>
                        Account Information
                      </Button>
                      <Button variant="ghost" className="w-full justify-start font-normal" disabled>
                        Security
                      </Button>
                      <Button variant="ghost" className="w-full justify-start font-normal" disabled>
                        Subscription
                      </Button>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start font-normal"
                        onClick={() => {
                          setShowVehicleType(true);
                          setShowTestAccounts(false);
                        }}
                      >
                        Vehicle Type
                      </Button>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start font-normal" 
                        onClick={() => {
                          setShowTestAccounts(true);
                          setShowVehicleType(false);
                        }}
                      >
                        Test Accounts
                      </Button>
                    </nav>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Need Help?</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-neutral-600 mb-4">
                      If you have any questions or need assistance with your account settings, please don't hesitate to contact our support team.
                    </p>
                    <Button variant="outline" className="w-full" disabled>
                      Contact Support
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
            
            <div className="md:col-span-2">
              {showVehicleType ? (
                <Card>
                  <CardHeader>
                    <CardTitle>Vehicle Type Settings</CardTitle>
                    <CardDescription>
                      Your selected SPSV vehicle type determines the content you see
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {userLoading ? (
                      <div className="flex items-center justify-center py-6">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <>
                        <Alert className="mb-6 border-green-100 bg-green-50">
                          <InfoIcon className="h-4 w-4 mr-2" />
                          <AlertTitle>Your Selected Vehicle Type</AlertTitle>
                          <AlertDescription>
                            Training content, checklists, and practice tests are customized based on your vehicle type.
                          </AlertDescription>
                        </Alert>
                        
                        <div className="space-y-6">
                          <div>
                            <h3 className="font-medium mb-2">Currently Selected Type</h3>
                            <div className="grid gap-4 text-sm">
                              <div>
                                <p className="text-neutral-500 mb-1">Vehicle Type</p>
                                <p className="bg-neutral-100 p-3 rounded font-medium">
                                  {SPSV_TYPES.find(type => type.id === user?.vehicleType)?.name || 'Taxi'}
                                </p>
                              </div>
                              
                              <div className="mt-4">
                                <h4 className="font-medium mb-2">Type Description</h4>
                                <p className="text-neutral-600 bg-neutral-50 p-3 rounded">
                                  {user?.vehicleType === 'taxi' && 'A taxi is a public hire vehicle that can be hailed on the street or at designated taxi ranks.'}
                                  {user?.vehicleType === 'hackney' && 'A hackney is a private hire vehicle that must be pre-booked and cannot be hailed on the street.'}
                                  {user?.vehicleType === 'limousine' && 'A limousine is a private hire luxury vehicle that must be pre-booked for special occasions.'}
                                  {user?.vehicleType === 'wheelchair_accessible_taxi' && 'A wheelchair accessible taxi is specially designed to accommodate wheelchair users.'}
                                  {user?.vehicleType === 'wheelchair_accessible_hackney' && 'A wheelchair accessible hackney is a pre-booked vehicle specially designed for wheelchair users.'}
                                  {user?.vehicleType === 'local_area_hackney' && 'A local area hackney is a restricted hackney licence for specific rural areas.'}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-8 pt-4 border-t">
                          <h3 className="font-medium mb-3">Change Vehicle Type</h3>
                          <p className="text-sm text-neutral-600 mb-4">
                            Changing your vehicle type will update the content you see throughout the application. 
                            This feature will be available in a future update.
                          </p>
                          <Button disabled className="w-full">Change Vehicle Type</Button>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              ) : showTestAccounts ? (
                <Card>
                  <CardHeader>
                    <CardTitle>Test Account Credentials</CardTitle>
                    <CardDescription>
                      These credentials are available for testing purposes
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Alert className="mb-6 border-blue-100 bg-blue-50">
                      <InfoIcon className="h-4 w-4 mr-2" />
                      <AlertTitle>Testing credentials</AlertTitle>
                      <AlertDescription>
                        Use these credentials for testing the application. All data associated with test accounts is reset periodically.
                      </AlertDescription>
                    </Alert>
                    
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-medium mb-2">Standard User Account</h3>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-neutral-500 mb-1">Username</p>
                            <p className="font-mono bg-neutral-100 p-2 rounded">testuser</p>
                          </div>
                          <div>
                            <p className="text-neutral-500 mb-1">Password</p>
                            <p className="font-mono bg-neutral-100 p-2 rounded">password123</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Account Information</CardTitle>
                    <CardDescription>
                      This is where your account information will be displayed
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-neutral-600">
                      Select an option from the left navigation panel to view and edit your account details.
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}