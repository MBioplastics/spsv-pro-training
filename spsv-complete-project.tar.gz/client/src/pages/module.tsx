import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { ModuleContent } from "@/components/training/module-content";
import { TRAINING_MODULES } from "@/lib/constants";
import { apiRequest } from "@/lib/queryClient";

export default function Module({ params }: { params: { id: string } }) {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const moduleId = parseInt(params.id, 10);
  
  // Get the vehicle type from the URL query
  const searchParams = new URLSearchParams(window.location.search);
  const vehicleType = searchParams.get("type") || "taxi";
  
  // Fetch user data
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ["/api/user"],
    retry: false,
  });
  
  // Get module info
  const moduleInfo = TRAINING_MODULES.find(m => m.id === moduleId);
  
  // Update training progress mutation
  const updateProgressMutation = useMutation({
    mutationFn: async (data: { moduleId: number, vehicleType: string, progress: number, isCompleted: boolean }) => {
      return apiRequest("POST", "/api/training/progress", data)
        .then(res => res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training/progress"] });
      toast({
        title: "Progress saved",
        description: "Your training progress has been updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update progress. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Handle module completion
  const handleComplete = () => {
    updateProgressMutation.mutate({
      moduleId,
      vehicleType,
      progress: 100,
      isCompleted: true
    });
    
    navigate("/training");
  };
  
  // Handle back button
  const handleBack = () => {
    navigate("/training");
  };
  
  // Check if user is authenticated
  useEffect(() => {
    if (userError) {
      navigate("/login");
    }
  }, [userError, navigate]);
  
  // Check if module exists
  useEffect(() => {
    if (!moduleInfo) {
      navigate("/training");
    }
  }, [moduleInfo, navigate]);
  
  // Loading state
  if (userLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }
  
  if (!moduleInfo) {
    return null;
  }
  
  return (
    <div className="min-h-screen bg-gray-100">
      <ModuleContent
        moduleId={moduleId}
        vehicleType={vehicleType}
        onComplete={handleComplete}
        onBack={handleBack}
      />
    </div>
  );
}
