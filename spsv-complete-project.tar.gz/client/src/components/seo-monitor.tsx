import { useEffect } from "react";
import { useLocation } from "wouter";

interface SEOData {
  title: string;
  description: string;
  keywords?: string;
  canonical?: string;
  ogTitle?: string;
  ogDescription?: string;
  structuredData?: any;
}

const routeSEOData: Record<string, SEOData> = {
  "/": {
    title: "SPSV Pro Training - Ireland's Leading Small Public Service Vehicle Training Platform",
    description: "Pass your SPSV exam first time with Ireland's most comprehensive taxi, limousine and hackney training platform. Interactive modules, practice tests, and county-specific area knowledge.",
    keywords: "SPSV training, PSV training, taxi licence Ireland, hackney licence, limousine licence, wheelchair accessible vehicle training, NTA training",
    canonical: "https://www.spsvprotraining.ie",
    ogTitle: "SPSV Pro Training - Complete Irish Taxi & Limousine Certification",
    ogDescription: "Ireland's #1 SPSV training platform. Complete certification for taxi, hackney, limousine and wheelchair accessible vehicles."
  },
  "/pricing": {
    title: "SPSV Training Pricing - Affordable Irish Taxi Licence Training Plans",
    description: "Choose from flexible SPSV training plans starting at €9.99. 30-day, 60-day, and 12-month access options for complete Irish taxi, limousine and hackney certification.",
    keywords: "SPSV training cost, taxi licence training price, PSV training pricing Ireland, affordable SPSV course",
    canonical: "https://www.spsvprotraining.ie/pricing"
  },
  "/training": {
    title: "SPSV Training Modules - Complete Irish Taxi & Limousine Course",
    description: "Comprehensive SPSV training modules covering industry knowledge, area knowledge for all 26 Irish counties, customer service, and practical taxi operation skills.",
    keywords: "SPSV training modules, taxi training course, limousine training, hackney training, area knowledge Ireland",
    canonical: "https://www.spsvprotraining.ie/training"
  },
  "/practice-tests": {
    title: "SPSV Practice Tests - Irish Taxi Licence Exam Preparation",
    description: "Practice SPSV exam questions and mock tests to prepare for your Irish taxi, limousine or hackney licence. Realistic exam simulation with instant feedback.",
    keywords: "SPSV practice test, taxi exam questions, PSV mock exam, Irish taxi licence test preparation",
    canonical: "https://www.spsvprotraining.ie/practice-tests"
  },
  "/vehicle-search": {
    title: "SPSV Vehicle Search - Find Approved Irish Taxi & Limousine Vehicles",
    description: "Search approved SPSV vehicles for taxi, hackney, limousine and wheelchair accessible services in Ireland. Official NTA approved vehicle database.",
    keywords: "SPSV approved vehicles, taxi vehicles Ireland, limousine vehicles, wheelchair accessible taxi, NTA approved cars",
    canonical: "https://www.spsvprotraining.ie/vehicle-search"
  }
};

export function SEOMonitor() {
  const [location] = useLocation();

  useEffect(() => {
    const seoData = routeSEOData[location];
    
    if (seoData) {
      // Update document title
      document.title = seoData.title;

      // Update meta description
      updateMetaTag("description", seoData.description);
      
      // Update keywords if provided
      if (seoData.keywords) {
        updateMetaTag("keywords", seoData.keywords);
      }

      // Update canonical URL
      if (seoData.canonical) {
        updateLinkTag("canonical", seoData.canonical);
      }

      // Update Open Graph tags
      if (seoData.ogTitle) {
        updateMetaProperty("og:title", seoData.ogTitle);
      }
      if (seoData.ogDescription) {
        updateMetaProperty("og:description", seoData.ogDescription);
      }

      // Update og:url with current page
      updateMetaProperty("og:url", `https://www.spsvprotraining.ie${location}`);

      // Add structured data for current page
      addStructuredData(location, seoData);
    }

    // Track page view for analytics
    trackPageView(location);
  }, [location]);

  return null; // This component doesn't render anything
}

function updateMetaTag(name: string, content: string) {
  let metaTag = document.querySelector(`meta[name="${name}"]`);
  if (!metaTag) {
    metaTag = document.createElement("meta");
    metaTag.setAttribute("name", name);
    document.head.appendChild(metaTag);
  }
  metaTag.setAttribute("content", content);
}

function updateMetaProperty(property: string, content: string) {
  let metaTag = document.querySelector(`meta[property="${property}"]`);
  if (!metaTag) {
    metaTag = document.createElement("meta");
    metaTag.setAttribute("property", property);
    document.head.appendChild(metaTag);
  }
  metaTag.setAttribute("content", content);
}

function updateLinkTag(rel: string, href: string) {
  let linkTag = document.querySelector(`link[rel="${rel}"]`);
  if (!linkTag) {
    linkTag = document.createElement("link");
    linkTag.setAttribute("rel", rel);
    document.head.appendChild(linkTag);
  }
  linkTag.setAttribute("href", href);
}

function addStructuredData(path: string, seoData: SEOData) {
  // Remove existing structured data for this page
  const existingScript = document.querySelector(`script[data-page="${path}"]`);
  if (existingScript) {
    existingScript.remove();
  }

  // Add page-specific structured data
  let structuredData: any = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": seoData.title,
    "description": seoData.description,
    "url": `https://www.spsvprotraining.ie${path}`,
    "isPartOf": {
      "@type": "WebSite",
      "name": "SPSV Pro Training",
      "url": "https://www.spsvprotraining.ie"
    }
  };

  // Add specific structured data based on page
  if (path === "/pricing") {
    structuredData["@type"] = "PriceSpecification";
    structuredData.offers = [
      {
        "@type": "Offer",
        "name": "30-Day SPSV Training",
        "price": "9.99",
        "priceCurrency": "EUR"
      },
      {
        "@type": "Offer",
        "name": "60-Day SPSV Training",
        "price": "19.99",
        "priceCurrency": "EUR"
      },
      {
        "@type": "Offer",
        "name": "12-Month SPSV Training",
        "price": "49.99",
        "priceCurrency": "EUR"
      }
    ];
  }

  const script = document.createElement("script");
  script.type = "application/ld+json";
  script.setAttribute("data-page", path);
  script.textContent = JSON.stringify(structuredData);
  document.head.appendChild(script);
}

function trackPageView(path: string) {
  // Page view tracking placeholder for future analytics integration
  console.log(`Page view tracked: ${path}`);
}