import { useState } from 'react';
import { COUNTIES, COUNTY_AREA_KNOWLEDGE } from '@/data/county-area-knowledge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin } from 'lucide-react';

interface CountySelectorProps {
  selectedCounty: string;
  onCountyChange: (county: string) => void;
}

export function CountySelector({ selectedCounty, onCountyChange }: CountySelectorProps) {
  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
          <div className="flex items-center text-primary-600 font-medium mb-2 md:mb-0">
            <MapPin className="h-5 w-5 mr-1" />
            <span>Select County:</span>
          </div>
          
          <Select value={selectedCounty} onValueChange={onCountyChange}>
            <SelectTrigger className="w-full md:w-[200px]">
              <SelectValue placeholder="Select a county" />
            </SelectTrigger>
            <SelectContent>
              {COUNTIES.map((county) => (
                <SelectItem key={county} value={county}>
                  {county}
                </SelectItem>
              ))}
              <SelectItem value="Other Counties">Other Counties</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="text-sm text-gray-500 ml-2 flex-1">
            <span>Testing specific area knowledge for {selectedCounty}.</span>
          </div>
        </div>
        
        {selectedCounty === "Dublin" && (
          <div className="mt-4 border-t pt-4">
            <div className="text-sm">
              <span className="font-medium">Dublin Area Knowledge includes:</span>
              <ul className="list-disc ml-5 mt-1 space-y-1">
                <li>Major hospitals, hotels, and landmarks</li>
                <li>One-way street systems and traffic flow</li>
                <li>Efficient routes through the city center</li>
                <li>Key taxi ranks and transport hubs</li>
              </ul>
            </div>
            
            <div className="mt-4">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d76185.58093471087!2d-6.330999!3d53.349805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48670e80ea27ac2f%3A0xa00c7a9973171a0!2sDublin!5e0!3m2!1sen!2sie!4v1674308778048!5m2!1sen!2sie" 
                width="100%" 
                height="200" 
                style={{ border: 0, borderRadius: '0.375rem' }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Dublin Map"
              />
            </div>
          </div>
        )}
        
        {selectedCounty === "Cork" && (
          <div className="mt-4 border-t pt-4">
            <div className="text-sm">
              <span className="font-medium">Cork Area Knowledge includes:</span>
              <ul className="list-disc ml-5 mt-1 space-y-1">
                <li>Cork City centre navigation and one-way systems</li>
                <li>Major hospitals, hotels, and landmarks</li>
                <li>Key routes and motorways around Cork</li>
                <li>Suburban areas and key locations</li>
              </ul>
            </div>
            
            <div className="mt-4">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d79045.92809237659!2d-8.5311403!3d51.8972078!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4844900891beb961%3A0xa00c7a99731c5d0!2sCork!5e0!3m2!1sen!2sie!4v1674308944261!5m2!1sen!2sie" 
                width="100%" 
                height="200" 
                style={{ border: 0, borderRadius: '0.375rem' }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Cork Map"
              />
            </div>
          </div>
        )}
        
        {selectedCounty === "Galway" && (
          <div className="mt-4 border-t pt-4">
            <div className="text-sm">
              <span className="font-medium">Galway Area Knowledge includes:</span>
              <ul className="list-disc ml-5 mt-1 space-y-1">
                <li>Galway City centre navigation and pedestrianised areas</li>
                <li>Key landmarks, hotels, and hospitals</li>
                <li>Major routes connecting Galway to other cities</li>
                <li>Popular tourist destinations and transport hubs</li>
              </ul>
            </div>
            
            <div className="mt-4">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d76052.37408327782!2d-9.105164!3d53.274141!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x485b93955a2d5bff%3A0x32b1b440a495281!2sGalway!5e0!3m2!1sen!2sie!4v1674309065112!5m2!1sen!2sie" 
                width="100%" 
                height="200" 
                style={{ border: 0, borderRadius: '0.375rem' }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Galway Map"
              />
            </div>
          </div>
        )}
        
        {selectedCounty === "Limerick" && (
          <div className="mt-4 border-t pt-4">
            <div className="text-sm">
              <span className="font-medium">Limerick Area Knowledge includes:</span>
              <ul className="list-disc ml-5 mt-1 space-y-1">
                <li>Limerick City centre streets and one-way systems</li>
                <li>Major bridges crossing the Shannon</li>
                <li>Hospitals, universities, and hotels</li>
                <li>Key retail areas and major transport hubs</li>
              </ul>
            </div>
            
            <div className="mt-4">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d38425.69486388641!2d-8.655015!3d52.661279!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x485b5c611f545113%3A0xa00c7a997317330!2sLimerick!5e0!3m2!1sen!2sie!4v1674309227417!5m2!1sen!2sie" 
                width="100%" 
                height="200" 
                style={{ border: 0, borderRadius: '0.375rem' }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Limerick Map"
              />
            </div>
          </div>
        )}
        
        {selectedCounty === "Waterford" && (
          <div className="mt-4 border-t pt-4">
            <div className="text-sm">
              <span className="font-medium">Waterford Area Knowledge includes:</span>
              <ul className="list-disc ml-5 mt-1 space-y-1">
                <li>Waterford City centre streets and key landmarks</li>
                <li>Major bridges and entry points to the city</li>
                <li>Hospital, college, and shopping locations</li>
                <li>Transport hubs and taxi ranks</li>
              </ul>
            </div>
            
            <div className="mt-4">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d77946.54350243406!2d-7.110898!3d52.259434!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4842c3fd837a08f7%3A0xa00c7a997317380!2sWaterford!5e0!3m2!1sen!2sie!4v1674309323184!5m2!1sen!2sie" 
                width="100%" 
                height="200" 
                style={{ border: 0, borderRadius: '0.375rem' }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Waterford Map"
              />
            </div>
          </div>
        )}
        
        {selectedCounty !== "Dublin" && selectedCounty !== "Cork" && selectedCounty !== "Galway" && selectedCounty !== "Limerick" && selectedCounty !== "Waterford" && selectedCounty !== "Other Counties" && (
          <div className="mt-4 border-t pt-4">
            <div className="text-sm">
              <span className="font-medium text-orange-600">County-Specific Questions Not Available</span>
              <p className="mt-1">Detailed area knowledge test for {selectedCounty} is currently under development in accordance with NTA SPSV driver testing standards.</p>
              <div className="mt-2 p-3 bg-orange-50 border border-orange-200 rounded-md">
                <p className="font-medium">Notice:</p>
                <p>The general area knowledge test will be used as a substitute. This includes questions about major routes, landmarks, and navigation principles that apply across Ireland, but may not include {selectedCounty}-specific content that could appear on the actual SPSV driver test.</p>
                <p className="mt-2">We recommend that drivers seeking to operate in {selectedCounty} supplement this training with local area study resources.</p>
              </div>
            </div>
            
            <div className="mt-4">
              <iframe 
                src={`https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d618251.7940521802!2d-8.0641152558594!3d53.44693!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x485e619e5d73698f%3A0xca9b39444d6ac68d!2sIreland!5e0!3m2!1sen!2sie!4v1674309498729!5m2!1sen!2sie`}
                width="100%" 
                height="200" 
                style={{ border: 0, borderRadius: '0.375rem' }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Ireland Map"
              />
            </div>
          </div>
        )}
        
        {selectedCounty === "Other Counties" && (
          <div className="mt-4 border-t pt-4">
            <div className="text-sm">
              <span className="font-medium">General Area Knowledge Test</span>
              <p className="mt-1">This test covers national knowledge applicable to all SPSV drivers across Ireland, regardless of their primary operating county.</p>
              
              <div className="mt-2 bg-blue-50 border border-blue-200 rounded-md p-3">
                <p className="font-medium">Test Content:</p>
                <ul className="list-disc ml-5 mt-1 space-y-1">
                  <li>Major motorways and national routes connecting Irish counties</li>
                  <li>Geographic orientation of counties and their relative locations</li>
                  <li>Major cities, towns, and transport hubs across Ireland</li>
                  <li>Key geographic features, tourist destinations, and national landmarks</li>
                  <li>General rules for navigating Irish road networks</li>
                </ul>
                <p className="mt-2 italic">Note: Mirrors the national knowledge portion of the official SPSV driver test. Contains {COUNTY_AREA_KNOWLEDGE["Other Counties"].questions.length} questions as per actual exam specifications.</p>
              </div>
            </div>
            
            <div className="mt-4">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2446120.7902521584!2d-9.74306670000001!3d53.1423672!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4859bae45c4027fb%3A0xcf7c1234cedbf408!2sIreland!5e0!3m2!1sen!2sus!4v1674309585249!5m2!1sen!2sus" 
                width="100%" 
                height="200" 
                style={{ border: 0, borderRadius: '0.375rem' }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Ireland Map"
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}