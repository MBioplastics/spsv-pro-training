import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { CheckCircle, Clock, XCircle, ArrowLeft, ArrowRight, Check, X } from "lucide-react";
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

export type Question = {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
};

export type TestData = {
  id: number;
  title: string;
  description: string;
  timeLimit: number;
  questions: Question[];
};

type TestInterfaceProps = {
  testData: TestData;
  vehicleType: string;
  onClose: () => void;
  onComplete: (score: number, total: number) => void;
};

export function TestInterface({ testData, vehicleType, onClose, onComplete }: TestInterfaceProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedOption, setSelectedOption] = useState<number>(-1);
  const [timeRemaining, setTimeRemaining] = useState(testData.timeLimit * 60);
  const [testCompleted, setTestCompleted] = useState(false);
  const [score, setScore] = useState(0);
  const [randomizedQuestions, setRandomizedQuestions] = useState<Question[]>([]);
  const { toast } = useToast();

  // Helper function to get random subset of questions
  const getRandomSubset = (array: Question[], size: number): Question[] => {
    // Make a copy of the array to avoid modifying the original
    const arrayCopy = [...array];
    // Shuffle the array using Fisher-Yates algorithm
    for (let i = arrayCopy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arrayCopy[i], arrayCopy[j]] = [arrayCopy[j], arrayCopy[i]];
    }
    // Return the first 'size' elements
    return arrayCopy.slice(0, size);
  };
  
  // Randomize questions on test start
  useEffect(() => {
    let questionCount = testData.questions.length;
    
    // Set question count based on test type to match the actual exam
    switch (testData.id) {
      case 1: // Industry Knowledge Test
        questionCount = Math.min(40, testData.questions.length);
        break;
      case 2: // Area Knowledge Test
        questionCount = Math.min(30, testData.questions.length);
        break;
      case 3: // Customer Service Test
        questionCount = Math.min(25, testData.questions.length);
        break;
      case 4: // Mock Exam
        questionCount = Math.min(80, testData.questions.length);
        break;
      // For county-specific tests (IDs 200+)
      default:
        if (testData.id >= 200) {
          // County area knowledge tests
          questionCount = Math.min(30, testData.questions.length);
        } else {
          questionCount = testData.questions.length;
        }
        break;
    }
    
    // Create a randomized subset of questions
    const shuffledQuestions = getRandomSubset(testData.questions, questionCount);
    setRandomizedQuestions(shuffledQuestions);
    
    // Initialize answers array to match the question count
    setAnswers(Array(questionCount).fill(-1));
  }, [testData]);

  // Timer effect
  useEffect(() => {
    if (testCompleted) return;
    
    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleTestCompletion();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [testCompleted]);

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Calculate progress percentage
  const progressPercentage = randomizedQuestions.length ? ((currentQuestion + 1) / randomizedQuestions.length) * 100 : 0;

  // Handle option selection
  const handleOptionSelect = (optionIndex: number) => {
    setSelectedOption(optionIndex);
  };

  // Move to next question
  const handleNext = () => {
    if (selectedOption === -1) {
      toast({
        title: "No option selected",
        description: "Please select an answer before continuing.",
        variant: "destructive",
      });
      return;
    }
    
    // Save answer
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = selectedOption;
    setAnswers(newAnswers);
    
    // Move to next question or complete test
    if (currentQuestion < randomizedQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedOption(newAnswers[currentQuestion + 1]);
    } else {
      handleTestCompletion();
    }
  };

  // Move to previous question
  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setSelectedOption(answers[currentQuestion - 1]);
    }
  };

  // Generate explanations for answers
  const getExplanation = (questionId: number, correctAnswer: number): string => {
    // Industry knowledge explanations
    const explanations: Record<number, string> = {
      // Industry Knowledge explanations
      1: "The National Transport Authority (NTA) is the regulatory body responsible for the SPSV industry in Ireland.",
      2: "There are six types of SPSV licences in Ireland: Standard Taxi, Wheelchair Accessible Taxi (WAT), Hackney, Wheelchair Accessible Hackney (WAH), Local Area Hackney, and Limousine.",
      3: "Only taxis can pick up passengers on the street without pre-booking. Hackneys, limousines, and local area hackneys must be pre-booked.",
      4: "The maximum age of a vehicle for a new SPSV licence is 10 years from the date of first registration.",
      5: "The SPSV vehicle licence disc must be displayed on the windscreen at all times when the vehicle is in operation as an SPSV.",
      6: "All SPSVs, regardless of age, must undergo an NCT annually.",
      7: "Since 2019, all taxis in Ireland are required to accept card payments.",
      8: "SPSV driver licences are valid for 5 years.",
      9: "A university degree is not required for obtaining an SPSV driver licence. The requirements include holding a full driving licence, passing the SPSV Entry Test, and passing Garda vetting.",
      10: "Wheelchair Accessible Taxis (WAT) must give priority to wheelchair users when operating at a taxi rank.",
      
      // Area Knowledge explanations
      101: "Drivers should know the exact location of main entrances, emergency departments, and outpatient clinics at major hospitals for efficient service.",
      102: "A professional driver should know both the location and the best approach routes to well-known hotels, as well as appropriate drop-off points.",
      103: "Knowledge of public buildings, government offices, and cultural venues is essential for both tourists and locals.",
      
      // Customer Service explanations
      201: "Clear communication is essential for a positive customer experience and to avoid misunderstandings.",
      202: "Professionalism in appearance demonstrates respect for customers and the service profession.",
      203: "Assisting with luggage is a basic expectation for all SPSV drivers.",
      204: "Assisting passengers with mobility challenges is a legal and ethical requirement for SPSV drivers.",
      205: "Providing a clean and well-maintained vehicle is essential for customer comfort and satisfaction.",
      
      // Default explanation
      0: "This question tests your knowledge of SPSV regulations and best practices in Ireland."
    };
    
    return explanations[questionId] || explanations[0];
  };

  // Complete the test
  const handleTestCompletion = () => {
    // Calculate score
    let correctCount = 0;
    answers.forEach((answer, index) => {
      if (index < randomizedQuestions.length && answer === randomizedQuestions[index].correctAnswer) {
        correctCount++;
      }
    });
    
    setScore(correctCount);
    setTestCompleted(true);
    
    // Save test results
    saveTestResults(correctCount);
  };

  // Save test results to backend
  const saveTestResults = async (correctCount: number) => {
    try {
      await apiRequest("POST", "/api/practice-tests", {
        testType: testData.title,
        vehicleType: vehicleType,
        score: correctCount,
        totalQuestions: randomizedQuestions.length,
        dateTaken: new Date().toISOString()
      });
      
      onComplete(correctCount, randomizedQuestions.length);
    } catch (error) {
      console.error("Failed to save test results:", error);
      toast({
        title: "Error",
        description: "Failed to save test results.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      {!testCompleted ? (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>{testData.title}</CardTitle>
                <CardDescription>
                  Question {currentQuestion + 1} of {randomizedQuestions.length}
                </CardDescription>
              </div>
              <div className="flex items-center bg-red-50 text-red-700 px-3 py-1 rounded-full">
                <Clock className="h-4 w-4 mr-1" />
                <span className="font-mono">{formatTime(timeRemaining)}</span>
              </div>
            </div>
            <Progress value={progressPercentage} className="mt-2" />
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              {randomizedQuestions.length > 0 && (
                <>
                  <h3 className="text-lg font-medium mb-4">
                    {randomizedQuestions[currentQuestion]?.text || ''}
                  </h3>
                  <RadioGroup value={selectedOption.toString()} onValueChange={(value) => handleOptionSelect(parseInt(value))}>
                    {randomizedQuestions[currentQuestion]?.options.map((option, index) => (
                      <div key={index} className="flex items-center space-x-2 mb-3 p-3 border rounded-md hover:bg-gray-50">
                        <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                        <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                          {option}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={handlePrevious}
              disabled={currentQuestion === 0}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>
            <Button 
              onClick={handleNext}
              className="bg-primary-500 hover:bg-primary-600"
            >
              {currentQuestion < randomizedQuestions.length - 1 ? (
                <>
                  Next
                  <ArrowRight className="ml-2 h-4 w-4" />
                </>
              ) : (
                "Complete Test"
              )}
            </Button>
          </CardFooter>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Test Results: {testData.title}</CardTitle>
            <CardDescription>
              You scored {score} out of {randomizedQuestions.length} ({Math.round((score / randomizedQuestions.length) * 100)}%)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-10">
              <div className="flex justify-center mb-3">
                {score / randomizedQuestions.length >= 0.8 ? (
                  <div className="bg-green-50 text-green-700 rounded-full px-6 py-3 flex items-center">
                    <CheckCircle className="h-6 w-6 mr-2" />
                    <span className="text-lg font-medium">Passed!</span>
                  </div>
                ) : (
                  <div className="bg-orange-50 text-orange-700 rounded-full px-6 py-3 flex items-center">
                    <XCircle className="h-6 w-6 mr-2" />
                    <span className="text-lg font-medium">Try Again</span>
                  </div>
                )}
              </div>
              
              {/* Power bar showing score visually */}
              <div className="max-w-md mx-auto">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Your Score</span>
                  <span className="text-sm font-medium">
                    {Math.round((score / randomizedQuestions.length) * 100)}%
                  </span>
                </div>
                <div className="w-full h-6 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      score / randomizedQuestions.length >= 0.8 
                        ? "bg-green-500" 
                        : score / randomizedQuestions.length >= 0.6 
                          ? "bg-yellow-500" 
                          : "bg-orange-500"
                    }`}
                    style={{ width: `${(score / randomizedQuestions.length) * 100}%` }}
                  />
                </div>
                <div className="flex justify-between mt-1 text-xs text-gray-500">
                  <span>0%</span>
                  <span className="bg-gray-100 px-1 rounded">80% to Pass</span>
                  <span>100%</span>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="font-medium">Test Summary:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Correct answers: {score}</li>
                <li>Incorrect answers: {randomizedQuestions.length - score}</li>
                <li>Accuracy: {Math.round((score / randomizedQuestions.length) * 100)}%</li>
                <li>Time spent: {formatTime((testData.timeLimit * 60) - timeRemaining)}</li>
              </ul>
              
              <h3 className="font-medium mt-6 pt-4 border-t">Question Analysis:</h3>
              <div className="space-y-4 mt-4">
                {randomizedQuestions.map((question, index) => {
                  const isCorrect = answers[index] === question.correctAnswer;
                  return (
                    <div key={index} className={`p-4 border rounded-md ${isCorrect ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                      <div className="flex items-start">
                        <div className={`flex-shrink-0 rounded-full p-1 mt-1 ${isCorrect ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                          {isCorrect ? <Check className="h-4 w-4" /> : <X className="h-4 w-4" />}
                        </div>
                        <div className="ml-3">
                          <h4 className="font-medium text-sm">{question.text}</h4>
                          <div className="mt-2 text-sm">
                            <p className={isCorrect ? 'text-green-700' : 'text-red-700'}>
                              <span className="font-medium">Your answer:</span> {question.options[answers[index]]}
                            </p>
                            {!isCorrect && (
                              <p className="text-green-700 mt-1">
                                <span className="font-medium">Correct answer:</span> {question.options[question.correctAnswer]}
                              </p>
                            )}
                            <p className="mt-2 text-gray-700 italic">
                              <span className="font-medium not-italic">Explanation:</span> {getExplanation(question.id, question.correctAnswer)}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={onClose}>
              Return to Test List
            </Button>
            <Button 
              onClick={() => {
                setCurrentQuestion(0);
                setSelectedOption(-1);
                setTestCompleted(false);
                setTimeRemaining(testData.timeLimit * 60);
                setAnswers(Array(randomizedQuestions.length).fill(-1));
                // Get a new set of random questions
                const newRandomQuestions = getRandomSubset(testData.questions, randomizedQuestions.length);
                setRandomizedQuestions(newRandomQuestions);
              }}
              className="bg-primary-500 hover:bg-primary-600"
            >
              Retake Test
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}