import { LucideProps } from "lucide-react";

export function TaxiIcon(props: LucideProps) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M4 22h16a2 2 0 0 0 2-2v-1a4 4 0 0 0-2-3.5"></path>
      <path d="m5 18 .4-1.5h9.2L15 18"></path>
      <path d="M3 8.5h18L17.5 3h-11L3 8.5Z"></path>
      <path d="m5 14 1 4"></path>
      <path d="m18 14-1 4"></path>
      <path d="M7.5 18v3"></path>
      <path d="M16.5 18v3"></path>
      <path d="M3 9.5v2a4 4 0 0 0 2 3.5"></path>
    </svg>
  );
}

export function HackneyIcon(props: LucideProps) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M10 2h4"></path>
      <path d="M12 14v-4"></path>
      <path d="M4 14h16"></path>
      <path d="M6 22 3.5 17.5 2 16"></path>
      <path d="m18 22 2.5-4.5 1.5-1.5"></path>
      <circle cx="7" cy="18" r="2"></circle>
      <circle cx="17" cy="18" r="2"></circle>
      <path d="M5 10h14"></path>
      <path d="m5 14-1-4 1-6h10l1 6-1 4"></path>
    </svg>
  );
}

export function LimousineIcon(props: LucideProps) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M3 9h12c0-1.2.5-2 2-2h3a1 1 0 0 1 1 1v2H3"></path>
      <path d="M5 9v8"></path>
      <path d="M21 9v8"></path>
      <path d="M3 17h18"></path>
      <circle cx="8" cy="19" r="2"></circle>
      <circle cx="18" cy="19" r="2"></circle>
    </svg>
  );
}

export function WheelchairIcon(props: LucideProps) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="8" cy="8" r="6"></circle>
      <path d="m10 16 1.9 1.9c.6.6 1.5.9 2.4.8H22" />
      <path d="M12 8h8v6" />
      <path d="m16 20-3-4" />
      <path d="M9 18h7" />
    </svg>
  );
}
