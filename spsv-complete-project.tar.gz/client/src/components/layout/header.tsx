import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { CarTaxiFront, Menu } from "lucide-react";
import { useState } from "react";
import { useSmoothScroll } from "@/hooks/use-smooth-scroll";

export function Header() {
  const [location, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { scrollToSection } = useSmoothScroll();

  const isActive = (path: string) => location === path;
  
  const handleSectionClick = (e: React.MouseEvent<HTMLAnchorElement>, sectionId: string) => {
    e.preventDefault();
    
    // If we're on a page other than home, go to home first with the section as hash
    if (location !== '/') {
      window.location.href = `/#${sectionId}`;
    } else {
      // If already on home page, use smooth scrolling
      scrollToSection(sectionId);
    }
  };

  return (
    <header className="bg-primary-500 text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link href="/">
          <div className="flex items-center space-x-3 cursor-pointer bg-primary-600 py-2 px-3 rounded-md hover:bg-primary-700 transition-colors">
            <div className="bg-white p-1.5 rounded-full">
              <CarTaxiFront className="h-8 w-8 text-primary-600" />
            </div>
            <div>
              <h1 className="text-xl font-bold">SPSV Pro Training</h1>
              <p className="text-xs text-primary-100">Comprehensive SPSV Licence Preparation</p>
            </div>
          </div>
        </Link>

        <div className="hidden md:flex items-center space-x-6">
          <a href="#features" onClick={(e) => handleSectionClick(e, 'features')}>
            <Button variant="ghost" className="text-white hover:text-primary-100 hover:bg-primary-600">
              Features
            </Button>
          </a>
          <a href="#training" onClick={(e) => handleSectionClick(e, 'training')}>
            <Button variant="ghost" className="text-white hover:text-primary-100 hover:bg-primary-600">
              Training
            </Button>
          </a>
          <a href="#pricing" onClick={(e) => handleSectionClick(e, 'pricing')}>
            <Button variant="ghost" className="text-white hover:text-primary-100 hover:bg-primary-600">
              Pricing
            </Button>
          </a>
          <a href="#about" onClick={(e) => handleSectionClick(e, 'about')}>
            <Button variant="ghost" className="text-white hover:text-primary-100 hover:bg-primary-600">
              About
            </Button>
          </a>
          <a href="#contact" onClick={(e) => handleSectionClick(e, 'contact')}>
            <Button variant="ghost" className="text-white hover:text-primary-100 hover:bg-primary-600">
              Contact
            </Button>
          </a>
          <Link href="/register">
            <Button variant="ghost" className="text-white hover:text-primary-100 hover:bg-primary-600 font-semibold">
              Purchase
            </Button>
          </Link>
        </div>

        <div className="flex items-center space-x-3">
          <Link href="/login">
            <Button variant="outline" className="bg-white text-primary-500 hover:bg-primary-50 font-semibold border-2 border-white px-5">
              Login
            </Button>
          </Link>
          <Link href="/register">
            <Button className="bg-secondary-500 hover:bg-secondary-600 text-white font-semibold px-5">
              Sign Up
            </Button>
          </Link>
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className="h-6 w-6" />
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-primary-600 py-4">
          <div className="container mx-auto px-4 flex flex-col space-y-3">
            <a 
              href="#features" 
              onClick={(e) => {
                e.preventDefault();
                handleSectionClick(e, 'features');
                setMobileMenuOpen(false);
              }}
            >
              <Button 
                variant="ghost" 
                className="text-white hover:text-primary-100 hover:bg-primary-600 w-full justify-start"
              >
                Features
              </Button>
            </a>
            <a 
              href="#training"
              onClick={(e) => {
                e.preventDefault();
                handleSectionClick(e, 'training');
                setMobileMenuOpen(false);
              }}
            >
              <Button 
                variant="ghost" 
                className="text-white hover:text-primary-100 hover:bg-primary-600 w-full justify-start"
              >
                Training
              </Button>
            </a>
            <a 
              href="#pricing"
              onClick={(e) => {
                e.preventDefault();
                handleSectionClick(e, 'pricing');
                setMobileMenuOpen(false);
              }}
            >
              <Button 
                variant="ghost" 
                className="text-white hover:text-primary-100 hover:bg-primary-600 w-full justify-start"
              >
                Pricing
              </Button>
            </a>
            <a 
              href="#about"
              onClick={(e) => {
                e.preventDefault();
                handleSectionClick(e, 'about');
                setMobileMenuOpen(false);
              }}
            >
              <Button 
                variant="ghost" 
                className="text-white hover:text-primary-100 hover:bg-primary-600 w-full justify-start"
              >
                About
              </Button>
            </a>
            <a 
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                handleSectionClick(e, 'contact');
                setMobileMenuOpen(false);
              }}
            >
              <Button 
                variant="ghost" 
                className="text-white hover:text-primary-100 hover:bg-primary-600 w-full justify-start"
              >
                Contact
              </Button>
            </a>
            <Link href="/register">
              <Button 
                variant="ghost" 
                className="text-white hover:text-primary-100 hover:bg-primary-600 w-full justify-start font-semibold"
                onClick={() => setMobileMenuOpen(false)}
              >
                Purchase
              </Button>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
