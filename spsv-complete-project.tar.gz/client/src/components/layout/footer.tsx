import { Link } from "wouter";
import { CarTaxiFront } from "lucide-react";
import { NTA_WEBSITE } from "@/lib/constants";
import { useSmoothScroll } from "@/hooks/use-smooth-scroll";

export function Footer() {
  const { scrollToSection } = useSmoothScroll();
  return (
    <footer className="bg-neutral-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <CarTaxiFront className="h-6 w-6" />
              <h3 className="text-xl font-bold">SPSV Pro Training</h3>
            </div>
            <p className="text-neutral-300 text-sm">
              Your complete solution for SPSV licensing in Ireland.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2 text-neutral-300">
              <li>
                <a 
                  href="#" 
                  className="hover:text-white"
                  onClick={(e) => {
                    e.preventDefault();
                    window.scrollTo({top: 0, behavior: 'smooth'});
                  }}
                >
                  Home
                </a>
              </li>
              <li>
                <a href="#features" className="hover:text-white" onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('features');
                }}>Features</a>
              </li>
              <li>
                <a href="#training" className="hover:text-white" onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('training');
                }}>Training</a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-white" onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('pricing');
                }}>Pricing</a>
              </li>
              <li>
                <a href="#about" className="hover:text-white" onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('about');
                }}>About Us</a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4">Resources</h4>
            <ul className="space-y-2 text-neutral-300">
              <li>
                <a
                  href={NTA_WEBSITE}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white"
                >
                  National Transport Authority
                </a>
              </li>
              <li>
                <a
                  href="/attached_assets/SPSV-official-manual-rev-7.8.pdf"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white"
                >
                  SPSV Official Manual
                </a>
              </li>
              <li>
                <a
                  href="https://www.ncts.ie"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white"
                >
                  NCT Website
                </a>
              </li>
              <li>
                <a
                  href="https://www.revenue.ie"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white"
                >
                  Revenue
                </a>
              </li>
              <li>
                <a
                  href="https://vetting.garda.ie/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white"
                >
                  Garda Vetting
                </a>
              </li>
            </ul>
          </div>


        </div>

        <div className="mt-8 pt-8 border-t border-neutral-700 text-center text-neutral-400 text-sm">
          <p>© {new Date().getFullYear()} SPSV Pro Training. All rights reserved.</p>
          <div className="mt-2 space-x-4">
            <Link href="/privacy" className="hover:text-white">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-white">Terms of Service</Link>
            <Link href="/cookies" className="hover:text-white">Cookie Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
