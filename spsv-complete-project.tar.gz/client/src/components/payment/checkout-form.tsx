import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PRICING_PLANS } from "@/lib/constants";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

type CheckoutFormProps = {
  selectedPlan: keyof typeof PRICING_PLANS;
};

const CheckoutForm = ({ selectedPlan }: CheckoutFormProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!stripe || !elements) {
      setIsLoading(false);
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/checkout`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Thank you for your purchase!",
      });
    }
    
    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="space-y-6">
        <div className="text-neutral-700">
          <p className="mb-2 font-medium">SPSV Training - {PRICING_PLANS[selectedPlan].name} Plan</p>
          <div className="flex items-center justify-between pb-4 border-b border-gray-200">
            <span>{PRICING_PLANS[selectedPlan].duration} days access</span>
            <span className="font-semibold">€{PRICING_PLANS[selectedPlan].price.toFixed(2)}</span>
          </div>
        </div>
        
        <PaymentElement />
        
        <Button 
          type="submit" 
          className="w-full bg-primary-500 hover:bg-primary-600"
          disabled={!stripe || isLoading}
        >
          {isLoading ? "Processing..." : `Pay €${PRICING_PLANS[selectedPlan].price.toFixed(2)}`}
        </Button>
        
        <div className="text-xs text-neutral-500 text-center">
          Your payment is secured by Stripe. We do not store your payment details.
        </div>
      </div>
    </form>
  );
};

type CheckoutContainerProps = {
  selectedPlan: keyof typeof PRICING_PLANS;
};

export function CheckoutContainer({ selectedPlan }: CheckoutContainerProps) {
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    let isMounted = true;
    
    // Create PaymentIntent as soon as the page loads
    const fetchPaymentIntent = async () => {
      try {
        const response = await apiRequest("POST", "/api/create-payment-intent", {
          planType: selectedPlan,
          amount: PRICING_PLANS[selectedPlan].price
        });
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Payment intent response:', data);
        
        if (isMounted && data.clientSecret) {
          setClientSecret(data.clientSecret);
        } else if (isMounted) {
          throw new Error('No client secret received');
        }
      } catch (error) {
        console.error("Payment intent error:", error);
        if (isMounted) {
          toast({
            title: "Error",
            description: "There was a problem setting up the payment. Please try again.",
            variant: "destructive",
          });
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    fetchPaymentIntent();
    
    return () => {
      isMounted = false;
    };
  }, [selectedPlan, toast]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }

  if (!clientSecret) {
    console.log("No client secret yet, isLoading:", isLoading);
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-neutral-700">
            <p>Loading payment form...</p>
            <div className="animate-spin w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full mx-auto mt-2" aria-label="Loading"/>
          </div>
        </CardContent>
      </Card>
    );
  }

  console.log("Rendering Stripe Elements with clientSecret:", clientSecret);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Complete Your Purchase</CardTitle>
        <CardDescription>
          Access all SPSV training materials and features
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Elements stripe={stripePromise} options={{ clientSecret, appearance: { theme: 'stripe' } }}>
          <CheckoutForm selectedPlan={selectedPlan} />
        </Elements>
      </CardContent>
    </Card>
  );
}
