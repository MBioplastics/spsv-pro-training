import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PRICING_PLANS } from "@/lib/constants";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY!);

type SimpleCheckoutProps = {
  selectedPlan: keyof typeof PRICING_PLANS;
};

const PaymentForm = ({ selectedPlan }: SimpleCheckoutProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!stripe || !elements) {
      setIsLoading(false);
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/checkout`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    }
    
    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="text-neutral-700">
        <p className="mb-2 font-medium">SPSV Training - {PRICING_PLANS[selectedPlan].name} Plan</p>
        <div className="flex items-center justify-between pb-4 border-b border-gray-200">
          <span>{PRICING_PLANS[selectedPlan].duration} days access</span>
          <span className="font-semibold">€{PRICING_PLANS[selectedPlan].price.toFixed(2)}</span>
        </div>
      </div>
      
      <PaymentElement />
      
      <Button 
        type="submit" 
        className="w-full bg-primary-500 hover:bg-primary-600"
        disabled={!stripe || isLoading}
      >
        {isLoading ? "Processing..." : `Pay €${PRICING_PLANS[selectedPlan].price.toFixed(2)}`}
      </Button>
      
      <div className="text-xs text-neutral-500 text-center">
        Your payment is secured by Stripe. We do not store your payment details.
      </div>
    </form>
  );
};

export function SimpleCheckout({ selectedPlan }: SimpleCheckoutProps) {
  const [clientSecret, setClientSecret] = useState("");
  const [error, setError] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    const createPaymentIntent = async () => {
      try {
        console.log("Creating payment intent for plan:", selectedPlan, "with price:", PRICING_PLANS[selectedPlan].price);
        const response = await apiRequest("POST", "/api/create-payment-intent", {
          planType: selectedPlan,
          amount: PRICING_PLANS[selectedPlan].price
        });
        
        const data = await response.json();
        
        if (data.clientSecret) {
          setClientSecret(data.clientSecret);
        } else {
          setError("Payment setup failed");
        }
      } catch (err) {
        console.error("Payment setup error:", err);
        setError("Payment setup failed");
      }
    };

    createPaymentIntent();
  }, [selectedPlan]);

  if (error) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-red-600">
            <p>Unable to initialise payment. Please try again later.</p>
            <Button 
              onClick={() => window.location.reload()} 
              className="mt-4"
              variant="outline"
            >
              Retry
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!clientSecret) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full mx-auto mb-4" />
            <p>Setting up payment...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Complete Your Purchase</CardTitle>
        <CardDescription>
          Access all SPSV training materials and features
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Elements stripe={stripePromise} options={{ clientSecret }}>
          <PaymentForm selectedPlan={selectedPlan} />
        </Elements>
      </CardContent>
    </Card>
  );
}