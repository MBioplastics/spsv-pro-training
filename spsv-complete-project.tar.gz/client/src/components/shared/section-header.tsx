type SectionHeaderProps = {
  title: string;
  description?: string;
  align?: 'left' | 'center' | 'right';
};

export function SectionHeader({ 
  title, 
  description, 
  align = 'left' 
}: SectionHeaderProps) {
  const textAlign = {
    left: 'text-left',
    center: 'text-center',
    right: 'text-right',
  };

  return (
    <div className={`mb-6 ${textAlign[align]}`}>
      <h2 className="text-2xl font-bold text-primary-500 mb-2">{title}</h2>
      {description && (
        <p className="text-lg text-neutral-600 max-w-3xl mx-auto">{description}</p>
      )}
    </div>
  );
}
