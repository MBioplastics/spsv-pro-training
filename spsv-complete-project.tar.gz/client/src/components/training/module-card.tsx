import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Check } from "lucide-react";

type ModuleCardProps = {
  id: number;
  title: string;
  description: string;
  progress: number;
  isCompleted: boolean;
  onClick: (id: number) => void;
};

export function ModuleCard({ 
  id, 
  title, 
  description, 
  progress, 
  isCompleted, 
  onClick 
}: ModuleCardProps) {
  return (
    <Card 
      className={`border-l-4 ${isCompleted ? 'border-l-secondary-500' : 'border-l-primary-500'} hover:shadow-md transition-shadow`}
    >
      <CardContent className="p-6">
        <div className="flex items-start">
          <div className="flex-1">
            <div className="flex items-center mb-2">
              <h3 className="text-lg font-semibold mr-2">{title}</h3>
              {isCompleted && (
                <div className="bg-secondary-100 text-secondary-500 rounded-full p-1">
                  <Check className="h-4 w-4" />
                </div>
              )}
            </div>
            <p className="text-neutral-600 text-sm mb-4">{description}</p>
            
            {!isCompleted && (
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-neutral-500">Progress</span>
                  <span className="font-medium">{progress}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            )}
            
            <Button 
              onClick={() => onClick(id)}
              variant={isCompleted ? "outline" : "default"}
              className={isCompleted ? "border-secondary-500 text-secondary-500 hover:bg-secondary-50" : "bg-primary-500 hover:bg-primary-600"}
              size="sm"
            >
              {isCompleted ? "Review Module" : "Continue Learning"}
            </Button>
          </div>
          <div className="ml-4">
            <div className={`p-2 rounded-full ${isCompleted ? 'bg-secondary-100 text-secondary-500' : 'bg-primary-100 text-primary-500'}`}>
              <BookOpen className="h-6 w-6" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
