import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight, CheckCircle, Info } from "lucide-react";
import { useState, useEffect } from "react";
import { TRAINING_MODULES, MODULE_CONTENT } from "@/lib/constants";

type ModuleContentProps = {
  moduleId: number;
  vehicleType: string;
  onComplete: () => void;
  onBack: () => void;
};

export function ModuleContent({ 
  moduleId, 
  vehicleType, 
  onComplete, 
  onBack 
}: ModuleContentProps) {
  const moduleContent = MODULE_CONTENT[moduleId];
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(moduleContent?.pages?.length || 5);
  const [progress, setProgress] = useState(0);
  
  const module = TRAINING_MODULES.find(m => m.id === moduleId);
  
  useEffect(() => {
    // Set total pages based on available content
    if (moduleContent && moduleContent.pages) {
      setTotalPages(moduleContent.pages.length);
    }
  }, [moduleContent]);
  
  useEffect(() => {
    // Calculate progress based on current page
    setProgress(Math.round((currentPage / totalPages) * 100));
  }, [currentPage, totalPages]);
  
  const handleNext = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
      window.scrollTo(0, 0); // Scroll to top on page change
    } else {
      onComplete();
    }
  };
  
  const handlePrevious = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
      window.scrollTo(0, 0); // Scroll to top on page change
    }
  };
  
  // Get current page content
  const currentPageData = moduleContent?.pages?.[currentPage - 1];
  
  // Get vehicle-specific content if available
  const vehicleSpecificContent = moduleContent?.vehicleSpecificContent?.[vehicleType];
  
  // Check if we have content for this module
  const hasContent = !!moduleContent && !!currentPageData;
  
  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <Button 
        variant="ghost" 
        className="mb-4"
        onClick={onBack}
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back to Modules
      </Button>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-primary-500">
            {module ? module.title : "Module Content"}
          </h1>
          <p className="text-neutral-600">
            {vehicleType.replace(/_/g, ' ').toUpperCase()} Training - Page {currentPage} of {totalPages}
          </p>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between text-sm mb-1">
            <span>Progress</span>
            <span>{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
        
        {hasContent ? (
          <div className="prose max-w-none mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">{currentPageData.title}</h2>
            
            {/* Main content */}
            <div dangerouslySetInnerHTML={{ __html: currentPageData.content }} />
            
            {/* Key points */}
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 my-6">
              <h3 className="text-lg font-medium mb-2 flex items-center">
                <Info className="h-5 w-5 mr-2 text-primary-500" />
                Key Points to Remember
              </h3>
              <ul className="list-disc pl-5 space-y-1">
                {currentPageData.keyPoints.map((point, index) => (
                  <li key={index}>{point}</li>
                ))}
              </ul>
            </div>
            
            {/* Vehicle-specific content */}
            {vehicleSpecificContent && (
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 my-6">
                <h3 className="text-lg font-medium mb-3">
                  Special Considerations for {vehicleType.replace(/_/g, ' ').toUpperCase()}
                </h3>
                
                <div dangerouslySetInnerHTML={{ __html: vehicleSpecificContent.additionalContent || '' }} />
                
                {vehicleSpecificContent.additionalKeyPoints && (
                  <div className="mt-4">
                    <h4 className="font-medium mb-2">Additional Key Points:</h4>
                    <ul className="list-disc pl-5 space-y-1">
                      {vehicleSpecificContent.additionalKeyPoints.map((point, index) => (
                        <li key={index}>{point}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="prose max-w-none mb-8 text-center py-10">
            <p className="text-gray-500">Content for this module is being prepared.</p>
            <p className="text-gray-500">Please check back soon for complete training materials.</p>
          </div>
        )}
        
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentPage === 1}
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Previous
          </Button>
          
          <Button
            onClick={handleNext}
          >
            {currentPage < totalPages ? (
              <>
                Next
                <ArrowRight className="h-4 w-4 ml-1" />
              </>
            ) : (
              <>
                Complete Module
                <CheckCircle className="h-4 w-4 ml-1" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
