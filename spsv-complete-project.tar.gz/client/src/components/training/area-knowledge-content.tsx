import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CountySelector } from "@/components/training/county-selector";
import { Progress } from "@/components/ui/progress";
import { Map, MapPin, Navigation, AlertCircle, Clock, Check, ChevronRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type AreaKnowledgeContentProps = {
  moduleId: number;
  onComplete: () => void;
  onBack: () => void;
};

export function AreaKnowledgeContent({ moduleId, onComplete, onBack }: AreaKnowledgeContentProps) {
  const [selectedCounty, setSelectedCounty] = useState("dublin");
  const [activeTab, setActiveTab] = useState("landmarks");
  const [progress, setProgress] = useState(0);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch training progress
  const { data: trainingProgress } = useQuery({
    queryKey: ["/api/training/progress", moduleId, selectedCounty],
    enabled: !!moduleId,
  });
  
  // Save progress mutation
  const saveProgressMutation = useMutation({
    mutationFn: async (data: { moduleId: number, completionPercentage: number, vehicleType: string }) => {
      return apiRequest("POST", "/api/training/progress", data)
        .then(res => res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training/progress"] });
      toast({
        title: "Progress saved",
        description: "Your training progress has been updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save progress. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Update progress when county changes
  useEffect(() => {
    if (trainingProgress) {
      setProgress(trainingProgress.completionPercentage);
    } else {
      setProgress(0);
    }
  }, [trainingProgress, selectedCounty]);
  
  // Handle county change
  const handleCountyChange = (county: string) => {
    setSelectedCounty(county);
  };
  
  // Handle marking section as complete
  const handleCompleteSection = () => {
    const newProgress = Math.min(progress + 25, 100);
    setProgress(newProgress);
    
    saveProgressMutation.mutate({
      moduleId,
      completionPercentage: newProgress,
      vehicleType: selectedCounty
    });
    
    if (newProgress === 100) {
      onComplete();
    }
  };
  
  // County-specific content for landmarks
  const getLandmarksContent = () => {
    const countyData = {
      dublin: {
        landmarks: [
          { name: "Dublin Castle", description: "Historic castle in Dublin city center", imageUrl: "https://via.placeholder.com/400x300?text=Dublin+Castle" },
          { name: "St. Stephen's Green", description: "Public park in Dublin city center", imageUrl: "https://via.placeholder.com/400x300?text=St+Stephens+Green" },
          { name: "Trinity College", description: "Historic university in Dublin", imageUrl: "https://via.placeholder.com/400x300?text=Trinity+College" },
          { name: "The Spire", description: "Monument on O'Connell Street", imageUrl: "https://via.placeholder.com/400x300?text=The+Spire" },
          { name: "Guinness Storehouse", description: "Tourist attraction in Dublin", imageUrl: "https://via.placeholder.com/400x300?text=Guinness+Storehouse" }
        ]
      },
      cork: {
        landmarks: [
          { name: "Blarney Castle", description: "Medieval castle in Cork", imageUrl: "https://via.placeholder.com/400x300?text=Blarney+Castle" },
          { name: "English Market", description: "Food market in Cork city", imageUrl: "https://via.placeholder.com/400x300?text=English+Market" },
          { name: "Cork City Gaol", description: "Former prison in Cork", imageUrl: "https://via.placeholder.com/400x300?text=Cork+City+Gaol" },
          { name: "St. Fin Barre's Cathedral", description: "Gothic cathedral in Cork", imageUrl: "https://via.placeholder.com/400x300?text=St+Fin+Barres+Cathedral" },
          { name: "Shandon Bells", description: "Bell tower in Cork city", imageUrl: "https://via.placeholder.com/400x300?text=Shandon+Bells" }
        ]
      },
      galway: {
        landmarks: [
          { name: "Spanish Arch", description: "Historic arch in Galway city", imageUrl: "https://via.placeholder.com/400x300?text=Spanish+Arch" },
          { name: "Eyre Square", description: "Public park in Galway city center", imageUrl: "https://via.placeholder.com/400x300?text=Eyre+Square" },
          { name: "Galway Cathedral", description: "Roman Catholic cathedral in Galway", imageUrl: "https://via.placeholder.com/400x300?text=Galway+Cathedral" },
          { name: "Lynch's Castle", description: "Medieval building in Galway", imageUrl: "https://via.placeholder.com/400x300?text=Lynchs+Castle" },
          { name: "Galway City Museum", description: "Museum in Galway city", imageUrl: "https://via.placeholder.com/400x300?text=Galway+City+Museum" }
        ]
      },
      // Default to Dublin for other counties, but in a full implementation, each county would have its own data
      default: {
        landmarks: [
          { name: "Main landmarks for selected county", description: "This county's key landmarks will be listed here", imageUrl: "https://via.placeholder.com/400x300?text=County+Landmarks" },
          { name: "Popular destinations", description: "Popular tourist and local destinations", imageUrl: "https://via.placeholder.com/400x300?text=Popular+Destinations" },
          { name: "Important buildings", description: "Government and public service buildings", imageUrl: "https://via.placeholder.com/400x300?text=Important+Buildings" }
        ]
      }
    };
    
    // Get landmarks for selected county or use default
    const landmarks = countyData[selectedCounty as keyof typeof countyData]?.landmarks || countyData.default.landmarks;
    
    return (
      <div className="space-y-6">
        <p className="text-neutral-600 mb-4">
          Familiarize yourself with these important landmarks in {selectedCounty.charAt(0).toUpperCase() + selectedCounty.slice(1)}. 
          SPSV drivers are expected to know how to navigate to these locations efficiently.
        </p>
        
        <div className="grid md:grid-cols-2 gap-6">
          {landmarks.map((landmark, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="h-5 w-5 text-primary-500 mr-2" />
                  {landmark.name}
                </CardTitle>
                <CardDescription>{landmark.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
                  <img 
                    src={landmark.imageUrl} 
                    alt={landmark.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  };
  
  // County-specific content for routes
  const getRoutesContent = () => {
    const countyData = {
      dublin: {
        routes: [
          { from: "Dublin Airport", to: "Dublin City Centre", description: "Main route from airport to city", mapUrl: "https://via.placeholder.com/800x500?text=Dublin+Airport+to+City+Centre" },
          { from: "City Centre", to: "Dun Laoghaire", description: "South coastal route", mapUrl: "https://via.placeholder.com/800x500?text=City+Centre+to+Dun+Laoghaire" },
          { from: "City Centre", to: "Howth", description: "North coastal route", mapUrl: "https://via.placeholder.com/800x500?text=City+Centre+to+Howth" }
        ]
      },
      cork: {
        routes: [
          { from: "Cork Airport", to: "Cork City Centre", description: "Main route from airport to city", mapUrl: "https://via.placeholder.com/800x500?text=Cork+Airport+to+City+Centre" },
          { from: "City Centre", to: "Blarney Castle", description: "Popular tourist route", mapUrl: "https://via.placeholder.com/800x500?text=City+Centre+to+Blarney+Castle" },
          { from: "City Centre", to: "Cobh", description: "Historic coastal town route", mapUrl: "https://via.placeholder.com/800x500?text=City+Centre+to+Cobh" }
        ]
      },
      galway: {
        routes: [
          { from: "Galway Bus/Train Station", to: "Eyre Square", description: "Central connection route", mapUrl: "https://via.placeholder.com/800x500?text=Galway+Station+to+Eyre+Square" },
          { from: "City Centre", to: "Salthill", description: "Coastal promenade route", mapUrl: "https://via.placeholder.com/800x500?text=City+Centre+to+Salthill" },
          { from: "City Centre", to: "NUIG", description: "University route", mapUrl: "https://via.placeholder.com/800x500?text=City+Centre+to+NUIG" }
        ]
      },
      // Default for other counties
      default: {
        routes: [
          { from: "Main Transport Hub", to: "Town Center", description: "Central connection route", mapUrl: "https://via.placeholder.com/800x500?text=Transport+Hub+to+Town+Center" },
          { from: "Town Center", to: "Popular Attraction", description: "Tourist route", mapUrl: "https://via.placeholder.com/800x500?text=Town+Center+to+Attraction" }
        ]
      }
    };
    
    // Get routes for selected county or use default
    const routes = countyData[selectedCounty as keyof typeof countyData]?.routes || countyData.default.routes;
    
    return (
      <div className="space-y-6">
        <p className="text-neutral-600 mb-4">
          Learn these important routes in {selectedCounty.charAt(0).toUpperCase() + selectedCounty.slice(1)}. 
          Understanding the most efficient routes is essential for SPSV drivers.
        </p>
        
        {routes.map((route, index) => (
          <Card key={index} className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Navigation className="h-5 w-5 text-primary-500 mr-2" />
                {route.from} to {route.to}
              </CardTitle>
              <CardDescription>{route.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
                <img 
                  src={route.mapUrl} 
                  alt={`Route from ${route.from} to ${route.to}`} 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="mt-4 p-4 bg-gray-50 rounded-md">
                <p className="text-sm text-neutral-600">
                  <strong>Recommended Route:</strong> Description of the most efficient route would be shown here, including specific streets, landmarks, and potential traffic considerations.
                </p>
                <p className="text-sm text-neutral-600 mt-2">
                  <strong>Alternative Routes:</strong> Alternative routes for different times of day or traffic conditions would be listed here.
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };
  
  // County-specific content for restrictions
  const getRestrictionsContent = () => {
    const countyData = {
      dublin: {
        restrictions: [
          { title: "Bus Lanes", description: "Rules for using bus lanes in Dublin", details: "Taxis can use most bus lanes in Dublin city. However, some bus gates and specific bus-only lanes do not permit taxis." },
          { title: "One-Way Streets", description: "Major one-way street systems", details: "Central Dublin has many one-way streets, particularly around St. Stephen's Green, Trinity College, and the Grafton Street area." },
          { title: "Pedestrian Zones", description: "Pedestrianised areas", details: "Grafton Street, Henry Street, and parts of Temple Bar are pedestrianised with restricted vehicle access." },
          { title: "Bridge Restrictions", description: "Limitations on bridge crossings", details: "Some bridges over the Liffey have specific traffic flow directions or restrictions during certain hours." }
        ]
      },
      cork: {
        restrictions: [
          { title: "Bus Lanes", description: "Rules for using bus lanes in Cork", details: "Taxis can use designated bus lanes on the main routes into Cork city." },
          { title: "One-Way Streets", description: "Major one-way street systems", details: "Cork city centre has a complex one-way system, particularly around Patrick Street and the South Mall." },
          { title: "Pedestrian Zones", description: "Pedestrianised areas", details: "Oliver Plunkett Street and parts of the city centre are pedestrianised with restricted access times for vehicles." },
          { title: "Traffic Flow", description: "Traffic management systems", details: "Cork has specific traffic management systems in place during peak hours." }
        ]
      },
      galway: {
        restrictions: [
          { title: "Bus Lanes", description: "Rules for using bus lanes in Galway", details: "Taxis can use most bus lanes in Galway city." },
          { title: "One-Way Streets", description: "Major one-way street systems", details: "Galway's city centre has several one-way streets, particularly in the medieval quarter." },
          { title: "Pedestrian Zones", description: "Pedestrianised areas", details: "Shop Street and parts of the Latin Quarter are pedestrianised with limited vehicle access." },
          { title: "Traffic Management", description: "Specific traffic rules", details: "During festivals and events, additional traffic restrictions apply in Galway city centre." }
        ]
      },
      // Default for other counties
      default: {
        restrictions: [
          { title: "Traffic Restrictions", description: "Local traffic limitations", details: "Information about local traffic restrictions, one-way systems, and pedestrian zones would be shown here." },
          { title: "Specific County Rules", description: "County-specific regulations", details: "Any specific traffic regulations unique to this county would be detailed here." }
        ]
      }
    };
    
    // Get restrictions for selected county or use default
    const restrictions = countyData[selectedCounty as keyof typeof countyData]?.restrictions || countyData.default.restrictions;
    
    return (
      <div className="space-y-6">
        <p className="text-neutral-600 mb-4">
          Understand these important traffic restrictions in {selectedCounty.charAt(0).toUpperCase() + selectedCounty.slice(1)}. 
          Knowledge of local traffic regulations is crucial for SPSV operators.
        </p>
        
        {restrictions.map((restriction, index) => (
          <Card key={index} className="mb-4">
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertCircle className="h-5 w-5 text-primary-500 mr-2" />
                {restriction.title}
              </CardTitle>
              <CardDescription>{restriction.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-neutral-600">{restriction.details}</p>
            </CardContent>
          </Card>
        ))}
        
        <div className="bg-amber-50 border border-amber-200 rounded-md p-4 mt-6">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <h4 className="font-medium text-amber-800 mb-1">Important Note</h4>
              <p className="text-sm text-amber-700">
                Traffic restrictions and regulations may change. Always stay updated with the latest information from local authorities and observe posted signs while driving.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  // Practice quiz for selected county
  const getPracticeQuizContent = () => {
    const countyData = {
      dublin: {
        questions: [
          {
            question: "Which of these is NOT a pedestrianised street in Dublin city centre?",
            options: ["Grafton Street", "Henry Street", "O'Connell Street", "Duke Street"],
            answer: 2
          },
          {
            question: "What is the fastest route from Dublin Airport to the city center during peak hours?",
            options: ["M1 and Port Tunnel", "M1 and East Link", "R132 through Drumcondra", "M50 and N81"],
            answer: 0
          },
          {
            question: "Which Dublin landmark is located on Dame Street?",
            options: ["The Spire", "St. Stephen's Green", "Trinity College", "Dublin Castle"],
            answer: 3
          },
          {
            question: "Which of these bridges crosses the River Liffey?",
            options: ["Pearse Bridge", "O'Connell Bridge", "Collins Bridge", "Parnell Bridge"],
            answer: 1
          },
          {
            question: "In which Dublin area would you find the Aviva Stadium?",
            options: ["Clontarf", "Ballsbridge", "Glasnevin", "Rathgar"],
            answer: 1
          }
        ]
      },
      cork: {
        questions: [
          {
            question: "Which of these is a one-way street in Cork city center?",
            options: ["Washington Street", "Patrick Street", "South Mall", "All of these"],
            answer: 3
          },
          {
            question: "What is Cork's main shopping street?",
            options: ["Oliver Plunkett Street", "Patrick Street", "Grand Parade", "North Main Street"],
            answer: 1
          },
          {
            question: "Which landmark is located on Grand Parade?",
            options: ["English Market", "Cork Opera House", "Cork City Hall", "Crawford Art Gallery"],
            answer: 0
          },
          {
            question: "Which bridge is closest to Cork Bus Station?",
            options: ["St. Patrick's Bridge", "Brian Boru Bridge", "Michael Collins Bridge", "Parnell Bridge"],
            answer: 0
          },
          {
            question: "In which area of Cork city is CIT (now MTU Cork) located?",
            options: ["Bishopstown", "Douglas", "Ballincollig", "Blackrock"],
            answer: 0
          }
        ]
      },
      galway: {
        questions: [
          {
            question: "Which of these is a pedestrianised street in Galway?",
            options: ["Eyre Square", "High Street", "Shop Street", "Quay Street"],
            answer: 2
          },
          {
            question: "What is the fastest route from Galway city center to Salthill during summer?",
            options: ["Seapoint Road", "Coast Road via Grattan Road", "Newcastle Road and Upper Salthill Road", "Threadneedle Road"],
            answer: 1
          },
          {
            question: "Which Galway landmark is located on the east side of Eyre Square?",
            options: ["Galway Cathedral", "Spanish Arch", "Galway Railway Station", "Lynch's Castle"],
            answer: 2
          },
          {
            question: "Which bridge crosses the River Corrib in Galway city center?",
            options: ["O'Brien's Bridge", "Wolfe Tone Bridge", "Salmon Weir Bridge", "All of these"],
            answer: 3
          },
          {
            question: "In which area of Galway would you find the university (NUIG)?",
            options: ["Newcastle", "Salthill", "Renmore", "Knocknacarra"],
            answer: 0
          }
        ]
      },
      // Default questions for other counties
      default: {
        questions: [
          {
            question: "Which of these is typically found in an Irish county town center?",
            options: ["Cathedral or main church", "Courthouse", "Market square", "All of these"],
            answer: 3
          },
          {
            question: "What is the typical layout of an Irish town?",
            options: ["Grid pattern", "Main street with adjoining smaller streets", "Circular with ring roads", "No standard pattern"],
            answer: 1
          },
          {
            question: "When planning a route in an unfamiliar area, what should an SPSV driver do?",
            options: ["Always use GPS", "Have county maps available", "Ask the passenger for directions", "All of these as appropriate"],
            answer: 3
          },
          {
            question: "Which of these is NOT typically a good pick-up point in a town?",
            options: ["Outside main hotel", "Train station", "Bus stop", "Narrow one-way street"],
            answer: 3
          },
          {
            question: "In most Irish towns, where can you find taxi ranks?",
            options: ["Near shopping centers", "Train/bus stations", "Main square or street", "All of these"],
            answer: 3
          }
        ]
      }
    };
    
    // Get questions for selected county or use default
    const questions = countyData[selectedCounty as keyof typeof countyData]?.questions || countyData.default.questions;
    
    return (
      <div className="space-y-6">
        <p className="text-neutral-600 mb-4">
          Test your knowledge of {selectedCounty.charAt(0).toUpperCase() + selectedCounty.slice(1)} with these practice questions. 
          These are similar to the types of questions you may encounter in your SPSV area knowledge test.
        </p>
        
        {questions.map((q, index) => (
          <Card key={index} className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-start">
                <span className="bg-primary-100 text-primary-700 h-7 w-7 rounded-full flex items-center justify-center font-bold text-sm mr-3 flex-shrink-0">
                  {index + 1}
                </span>
                {q.question}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {q.options.map((option, optIndex) => (
                  <div key={optIndex} className="flex items-center p-3 border rounded-md hover:bg-gray-50 cursor-pointer">
                    <div className="h-5 w-5 rounded-full border-2 border-gray-300 mr-3 flex-shrink-0"></div>
                    <span>{option}</span>
                    {optIndex === q.answer && (
                      <div className="ml-auto">
                        <div className="text-xs bg-green-100 text-green-700 py-1 px-2 rounded">
                          Correct Answer
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 bg-gray-50 rounded-md">
                <p className="text-sm text-neutral-600">
                  <strong>Explanation:</strong> Explanations for each question would be provided here, giving details about why the correct answer is right and additional information about the location or route.
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">County Area Knowledge</h1>
          <p className="text-neutral-600">
            Learn specific area knowledge for each county in Ireland to pass your SPSV test.
          </p>
        </div>
        <CountySelector
          value={selectedCounty}
          onChange={handleCountyChange}
          className="w-full md:w-64"
        />
      </div>
      
      <div className="mb-6">
        <div className="flex justify-between mb-2">
          <span className="text-sm font-medium">Your progress</span>
          <span className="text-sm font-medium">{progress}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="landmarks">
            <MapPin className="h-4 w-4 mr-2" />
            Landmarks
          </TabsTrigger>
          <TabsTrigger value="routes">
            <Map className="h-4 w-4 mr-2" />
            Routes
          </TabsTrigger>
          <TabsTrigger value="restrictions">
            <AlertCircle className="h-4 w-4 mr-2" />
            Restrictions
          </TabsTrigger>
          <TabsTrigger value="practice">
            <Clock className="h-4 w-4 mr-2" />
            Practice Quiz
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="landmarks">
          {getLandmarksContent()}
        </TabsContent>
        
        <TabsContent value="routes">
          {getRoutesContent()}
        </TabsContent>
        
        <TabsContent value="restrictions">
          {getRestrictionsContent()}
        </TabsContent>
        
        <TabsContent value="practice">
          {getPracticeQuizContent()}
        </TabsContent>
      </Tabs>
      
      <div className="flex justify-between mt-10 pt-6 border-t">
        <Button variant="outline" onClick={onBack}>
          Back to Module List
        </Button>
        
        <Button 
          className="bg-primary-500 hover:bg-primary-600"
          onClick={handleCompleteSection}
        >
          {progress < 100 ? (
            <>
              Mark Section as Complete
              <ChevronRight className="ml-2 h-4 w-4" />
            </>
          ) : (
            <>
              <Check className="mr-2 h-4 w-4" />
              Complete Module
            </>
          )}
        </Button>
      </div>
    </div>
  );
}