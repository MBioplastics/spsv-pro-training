import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { IRISH_COUNTIES } from "@/lib/constants";

type CountySelectorProps = {
  value: string;
  onChange: (value: string) => void;
  className?: string;
};

export function CountySelector({ value, onChange, className }: CountySelectorProps) {
  return (
    <div className={className}>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Select County" />
        </SelectTrigger>
        <SelectContent>
          {IRISH_COUNTIES.map((county) => (
            <SelectItem key={county.id} value={county.id}>
              {county.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}