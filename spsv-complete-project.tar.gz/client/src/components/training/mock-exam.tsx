import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { VehicleSelector } from "@/components/dashboard/vehicle-selector";
import { CountySelector } from "@/components/training/county-selector";
import { Timer, AlertCircle, ChevronRight, ChevronLeft, Check, X, HelpCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { TEST_TIME_LIMITS } from "@/lib/constants";

type MockExamProps = {
  onComplete: () => void;
  onBack: () => void;
};

// Mock exam question type
type Question = {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  category: string;
  explanation: string;
  image?: string;
};

export function MockExam({ onComplete, onBack }: MockExamProps) {
  const [selectedVehicle, setSelectedVehicle] = useState("taxi");
  const [selectedCounty, setSelectedCounty] = useState("dublin");
  const [examStarted, setExamStarted] = useState(false);
  const [examCompleted, setExamCompleted] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(TEST_TIME_LIMITS.mock_exam * 60); // in seconds
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [reviewMode, setReviewMode] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // All questions for the mock exam (would typically be fetched from API)
  const allQuestions: Question[] = [
    // Industry Knowledge
    {
      id: 1,
      question: "What is the minimum age to apply for an SPSV driver licence?",
      options: ["18 years", "21 years", "20 years", "25 years"],
      correctAnswer: 1,
      category: "industry_knowledge",
      explanation: "The minimum age to apply for an SPSV driver licence is 21 years."
    },
    {
      id: 2,
      question: "How long must a person hold a driving licence in category B before applying for an SPSV driver licence?",
      options: ["1 year", "2 years", "3 years", "5 years"],
      correctAnswer: 1,
      category: "industry_knowledge",
      explanation: "A person must hold a category B driving licence for a minimum of 2 years before applying for an SPSV driver licence."
    },
    {
      id: 3,
      question: "How many penalty points can a driver accumulate before their SPSV licence is revoked?",
      options: ["5 points", "7 points", "10 points", "12 points"],
      correctAnswer: 2,
      category: "industry_knowledge",
      explanation: "An SPSV driver licence will be revoked if the holder accumulates 10 or more penalty points."
    },
    {
      id: 4,
      question: "Which authority is responsible for regulating the SPSV industry in Ireland?",
      options: ["Road Safety Authority (RSA)", "National Transport Authority (NTA)", "Department of Transport", "An Garda Síochána"],
      correctAnswer: 1,
      category: "industry_knowledge",
      explanation: "The National Transport Authority (NTA) is responsible for regulating the SPSV industry in Ireland."
    },
    {
      id: 5,
      question: "What is the purpose of the SPSV Entry Test?",
      options: ["To test driving skills", "To test knowledge of vehicle maintenance", "To test industry knowledge and area knowledge", "To test customer service skills"],
      correctAnswer: 2,
      category: "industry_knowledge",
      explanation: "The SPSV Entry Test assesses the applicant's knowledge of the SPSV industry and their area knowledge."
    },
    
    // Area Knowledge - Dublin
    {
      id: 6,
      question: "Which Dublin street connects O'Connell Street with Trinity College?",
      options: ["Dame Street", "Grafton Street", "Westmoreland Street", "Nassau Street"],
      correctAnswer: 2,
      category: "area_knowledge",
      explanation: "Westmoreland Street connects O'Connell Street with Trinity College in Dublin."
    },
    {
      id: 7,
      question: "Where is the 3Arena located in Dublin?",
      options: ["North Wall Quay", "Grand Canal Dock", "Smithfield", "Ballsbridge"],
      correctAnswer: 0,
      category: "area_knowledge",
      explanation: "The 3Arena is located on North Wall Quay in Dublin's Docklands area."
    },
    
    // Area Knowledge - Cork
    {
      id: 8,
      question: "Which street in Cork is known for its English Market?",
      options: ["Patrick Street", "Grand Parade", "Oliver Plunkett Street", "South Mall"],
      correctAnswer: 1,
      category: "area_knowledge",
      explanation: "The English Market is located on Grand Parade in Cork city."
    },
    {
      id: 9,
      question: "Where is Cork Airport located relative to Cork city centre?",
      options: ["North", "South", "East", "West"],
      correctAnswer: 1,
      category: "area_knowledge",
      explanation: "Cork Airport is located to the south of Cork city centre, approximately 8 km away."
    },
    
    // Rules & Regulations
    {
      id: 10,
      question: "What is the maximum fare that can be charged for a taxi journey?",
      options: ["Any fare agreed in advance", "The metered fare only", "The maximum fare calculated on the taximeter", "Any fare the driver wishes to charge"],
      correctAnswer: 2,
      category: "rules_regulations",
      explanation: "The maximum fare that can be charged is the maximum fare calculated on the taximeter. A driver may charge less but not more than this amount."
    },
    {
      id: 11,
      question: "When is a taxi driver permitted to refuse a fare?",
      options: ["If the journey is less than 3km", "If the passenger appears to be intoxicated", "If the journey would end outside the driver's normal area", "If the journey would exceed 30km"],
      correctAnswer: 1,
      category: "rules_regulations",
      explanation: "A taxi driver may refuse a fare if the passenger is intoxicated and likely to cause damage or disruption. However, they cannot refuse solely based on journey length or destination."
    },
    {
      id: 12,
      question: "Which of the following must be displayed in an operating taxi?",
      options: ["Driver's personal identification", "Driver's SPSV licence", "Both the driver's and vehicle's SPSV licences", "Neither licence is required to be displayed"],
      correctAnswer: 2,
      category: "rules_regulations",
      explanation: "Both the driver's SPSV licence and the vehicle's SPSV licence must be displayed in an operating taxi."
    },
    {
      id: 13,
      question: "How often must a taximeter be calibrated and verified?",
      options: ["Every year", "Every two years", "When the vehicle is changed", "All of the above"],
      correctAnswer: 3,
      category: "rules_regulations",
      explanation: "A taximeter must be calibrated and verified annually, every two years when the National Maximum Taxi Fare changes, and when the vehicle is changed."
    },
    {
      id: 14,
      question: "What is the purpose of the roof sign on a taxi?",
      options: ["To display the driver's name", "To indicate availability", "To display the vehicle licence number", "To display the fare structure"],
      correctAnswer: 1,
      category: "rules_regulations",
      explanation: "The roof sign on a taxi is used to indicate the vehicle's availability to potential customers."
    },
    
    // Vehicle Specific - Taxi
    {
      id: 15,
      question: "What is the minimum size for a vehicle to be licensed as a taxi?",
      options: ["Any size is acceptable", "Must have at least 4 passenger doors", "Must be able to accommodate at least 3 adult passengers", "Must have a boot capacity of at least 420 liters"],
      correctAnswer: 2,
      category: "vehicle_specific",
      explanation: "A vehicle must be able to accommodate at least 3 adult passengers to be licensed as a taxi."
    },
    
    // Vehicle Specific - Hackney
    {
      id: 16,
      question: "What type of service is a hackney permitted to provide?",
      options: ["Street hail services", "Rank services", "Pre-booked services only", "Any type of service"],
      correctAnswer: 2,
      category: "vehicle_specific",
      explanation: "A hackney is permitted to provide pre-booked services only. It cannot provide street hail or rank services like a taxi."
    },
    
    // Vehicle Specific - Limousine
    {
      id: 17,
      question: "Which of the following is a requirement for a limousine licence?",
      options: ["Vehicle must be less than 5 years old", "Vehicle must have a minimum of 6 passenger seats", "Vehicle must be a luxury or speciality type", "Vehicle must be painted black"],
      correctAnswer: 2,
      category: "vehicle_specific",
      explanation: "For a limousine licence, the vehicle must be a luxury or speciality type that enhances the passenger experience beyond that of a standard vehicle."
    },
    
    // Fares and Payments
    {
      id: 18,
      question: "When does 'Premium Rate' apply for taxi fares?",
      options: ["8pm to 8am every day", "6pm to 8am Monday to Saturday and all day Sunday", "8pm to 8am Monday to Saturday and all day Sunday and public holidays", "10pm to 6am every day"],
      correctAnswer: 2,
      category: "rules_regulations",
      explanation: "Premium Rate applies from 8pm to 8am Monday to Saturday and all day Sunday and public holidays."
    },
    {
      id: 19,
      question: "What should a driver do if they intend to charge a pre-agreed fare instead of using the meter?",
      options: ["This is not allowed under any circumstances", "Agree the fare before the journey begins", "Use the meter but charge a different amount", "Charge whatever seems reasonable at the end"],
      correctAnswer: 1,
      category: "rules_regulations",
      explanation: "If a driver intends to charge a pre-agreed fare instead of using the meter, they must agree on the fare with the passenger before the journey begins."
    },
    {
      id: 20,
      question: "Which payment methods must all taxis accept?",
      options: ["Cash only", "Cash and credit/debit cards", "Any method the driver chooses", "Cash, credit/debit cards, and mobile payments"],
      correctAnswer: 1,
      category: "rules_regulations",
      explanation: "All taxis must accept cash and credit/debit card payments. Other methods are optional."
    }
  ];
  
  // Filter questions based on selected vehicle type and county
  const getExamQuestions = () => {
    const filteredQuestions = allQuestions.filter(q => {
      // Include all industry knowledge and rules questions
      if (q.category === "industry_knowledge" || q.category === "rules_regulations") {
        return true;
      }
      
      // Include only area knowledge questions for selected county
      if (q.category === "area_knowledge") {
        // This is a simplified implementation - in a real app, questions would have specific county tags
        if (selectedCounty === "dublin" && (q.id === 6 || q.id === 7)) {
          return true;
        }
        if (selectedCounty === "cork" && (q.id === 8 || q.id === 9)) {
          return true;
        }
        // For other counties, include some general questions
        if (selectedCounty !== "dublin" && selectedCounty !== "cork") {
          return q.id === 6 || q.id === 8; // Use some questions as examples
        }
        return false;
      }
      
      // Include only vehicle specific questions for selected vehicle type
      if (q.category === "vehicle_specific") {
        if (selectedVehicle === "taxi" && q.id === 15) {
          return true;
        }
        if ((selectedVehicle === "hackney" || selectedVehicle === "wheelchair_accessible_hackney" || selectedVehicle === "local_area_hackney") && q.id === 16) {
          return true;
        }
        if (selectedVehicle === "limousine" && q.id === 17) {
          return true;
        }
        return false;
      }
      
      return false;
    });
    
    // Ensure we have exactly 20 questions by adding more from the general pool if needed
    if (filteredQuestions.length < 20) {
      const remainingQuestions = allQuestions.filter(q => !filteredQuestions.includes(q));
      const additionalQuestions = remainingQuestions.slice(0, 20 - filteredQuestions.length);
      return [...filteredQuestions, ...additionalQuestions];
    }
    
    return filteredQuestions.slice(0, 20); // Limit to 20 questions
  };
  
  // Get the actual questions for the exam
  const examQuestions = getExamQuestions();
  
  // Timer effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (examStarted && !examCompleted) {
      timer = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            handleExamCompletion();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => clearInterval(timer);
  }, [examStarted, examCompleted]);
  
  // Format remaining time in MM:SS format
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Handle starting the exam
  const handleStartExam = () => {
    setExamStarted(true);
    setUserAnswers(new Array(examQuestions.length).fill(-1));
    toast({
      title: "Exam Started",
      description: `You have ${TEST_TIME_LIMITS.mock_exam} minutes to complete the exam.`,
    });
  };
  
  // Handle selecting an answer
  const handleSelectAnswer = (answerIndex: number) => {
    if (reviewMode) return;
    
    const newAnswers = [...userAnswers];
    newAnswers[currentQuestionIndex] = answerIndex;
    setUserAnswers(newAnswers);
  };
  
  // Handle moving to next question
  const handleNextQuestion = () => {
    if (currentQuestionIndex < examQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else if (!examCompleted) {
      handleExamCompletion();
    }
  };
  
  // Handle moving to previous question
  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };
  
  // Handle exam completion
  const handleExamCompletion = () => {
    setExamCompleted(true);
    
    // Calculate score
    const correctAnswers = userAnswers.filter((answer, index) => 
      answer === examQuestions[index].correctAnswer
    ).length;
    
    const finalScore = Math.round((correctAnswers / examQuestions.length) * 100);
    setScore(finalScore);
    
    // Save practice test result
    const testData = {
      testType: "mock_exam",
      score: finalScore,
      totalQuestions: examQuestions.length,
      correctAnswers,
      vehicleType: selectedVehicle,
      countyArea: selectedCounty
    };
    
    // API call to save test result would go here
    
    toast({
      title: "Exam Completed",
      description: `Your score: ${finalScore}%. ${finalScore >= 85 ? "Congratulations! You passed!" : "Keep practicing to improve your score."}`,
      variant: finalScore >= 85 ? "default" : "destructive",
    });
  };
  
  // Current question
  const currentQuestion = examQuestions[currentQuestionIndex];
  
  // Render exam setup screen
  if (!examStarted) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold mb-4">SPSV Mock Examination</h1>
        <p className="text-neutral-600 mb-6">
          This mock exam simulates the official SPSV driver entry test. You will have {TEST_TIME_LIMITS.mock_exam} minutes to complete 20 questions.
          The test includes industry knowledge, area knowledge, and vehicle-specific questions.
        </p>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Exam Settings</CardTitle>
            <CardDescription>Select your vehicle type and county area for targeted questions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Vehicle Type</label>
              <VehicleSelector 
                value={selectedVehicle} 
                onChange={setSelectedVehicle} 
                className="w-full"
              />
              <p className="text-xs text-neutral-500 mt-1">
                This will determine which vehicle-specific questions are included.
              </p>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">County Area</label>
              <CountySelector 
                value={selectedCounty} 
                onChange={setSelectedCounty} 
                className="w-full"
              />
              <p className="text-xs text-neutral-500 mt-1">
                This will determine which area knowledge questions are included.
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Exam Format</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-neutral-600">
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs mr-2 mt-0.5">1</div>
                <span>20 multiple-choice questions</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs mr-2 mt-0.5">2</div>
                <span>Time limit: {TEST_TIME_LIMITS.mock_exam} minutes</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs mr-2 mt-0.5">3</div>
                <span>Passing score: 85% or higher</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs mr-2 mt-0.5">4</div>
                <span>Questions cover industry knowledge, area knowledge, and vehicle-specific topics</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs mr-2 mt-0.5">5</div>
                <span>Review your answers and explanations after completion</span>
              </li>
            </ul>
          </CardContent>
        </Card>
        
        <div className="bg-amber-50 border border-amber-200 rounded-md p-4 mb-6">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <h4 className="font-medium text-amber-800 mb-1">Important Information</h4>
              <p className="text-sm text-amber-700">
                This mock exam is designed to help you prepare for the official SPSV driver entry test. 
                Once you start the exam, the timer will begin and cannot be paused. Ensure you're ready to complete the entire exam before starting.
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between">
          <Button variant="outline" onClick={onBack}>
            Return to Training
          </Button>
          <Button
            className="bg-primary-500 hover:bg-primary-600"
            onClick={handleStartExam}
          >
            Start Mock Exam
            <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  }
  
  // Render exam results
  if (examCompleted) {
    const passThreshold = 85;
    const passed = score >= passThreshold;
    
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold mb-4">Exam Results</h1>
        
        <Card className="mb-6 border-t-4 border-t-primary-500">
          <CardHeader>
            <CardTitle className="flex justify-between items-center">
              <span>Your Score: {score}%</span>
              {passed ? (
                <div className="text-sm bg-secondary-100 text-secondary-700 py-1 px-3 rounded">
                  PASSED
                </div>
              ) : (
                <div className="text-sm bg-red-100 text-red-700 py-1 px-3 rounded">
                  FAILED
                </div>
              )}
            </CardTitle>
            <CardDescription>
              {passed 
                ? "Congratulations! You've passed the mock exam." 
                : `You need ${passThreshold}% to pass. Review the questions and try again.`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Score</span>
                <span className="text-sm font-medium">{score}%</span>
              </div>
              <Progress 
                value={score} 
                className="h-2"
                indicatorClassName={passed ? "bg-secondary-500" : "bg-red-500"}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-6 mt-6">
              <div className="text-center p-4 bg-gray-50 rounded-md">
                <div className="text-3xl font-bold text-primary-500 mb-2">
                  {userAnswers.filter((a, i) => a === examQuestions[i].correctAnswer).length}
                </div>
                <div className="text-sm text-neutral-600">Correct Answers</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-md">
                <div className="text-3xl font-bold text-neutral-500 mb-2">
                  {userAnswers.filter((a, i) => a !== examQuestions[i].correctAnswer && a !== -1).length}
                </div>
                <div className="text-sm text-neutral-600">Incorrect Answers</div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full"
              onClick={() => {
                setReviewMode(true);
                setCurrentQuestionIndex(0);
              }}
            >
              Review Questions and Answers
            </Button>
          </CardFooter>
        </Card>
        
        {!reviewMode && (
          <div className="flex justify-between">
            <Button variant="outline" onClick={onBack}>
              Return to Training
            </Button>
            <Button
              className="bg-primary-500 hover:bg-primary-600"
              onClick={() => {
                setExamStarted(false);
                setExamCompleted(false);
                setTimeRemaining(TEST_TIME_LIMITS.mock_exam * 60);
              }}
            >
              Take Exam Again
            </Button>
          </div>
        )}
        
        {reviewMode && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center">
                    <span className="bg-primary-100 text-primary-700 h-7 w-7 rounded-full flex items-center justify-center font-bold text-sm mr-3">
                      {currentQuestionIndex + 1}
                    </span>
                    {currentQuestion.question}
                  </CardTitle>
                  <div className="text-sm text-neutral-500">
                    Question {currentQuestionIndex + 1} of {examQuestions.length}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {currentQuestion.options.map((option, index) => {
                    const isUserAnswer = userAnswers[currentQuestionIndex] === index;
                    const isCorrectAnswer = currentQuestion.correctAnswer === index;
                    
                    let bgColor = "";
                    let borderColor = "border-gray-200";
                    let icon = null;
                    
                    if (isUserAnswer && isCorrectAnswer) {
                      bgColor = "bg-green-50";
                      borderColor = "border-green-300";
                      icon = <Check className="h-5 w-5 text-green-500" />;
                    } else if (isUserAnswer && !isCorrectAnswer) {
                      bgColor = "bg-red-50";
                      borderColor = "border-red-300";
                      icon = <X className="h-5 w-5 text-red-500" />;
                    } else if (isCorrectAnswer) {
                      bgColor = "bg-green-50";
                      borderColor = "border-green-300";
                      icon = <Check className="h-5 w-5 text-green-500" />;
                    }
                    
                    return (
                      <div 
                        key={index} 
                        className={`flex items-center justify-between p-3 border rounded-md ${bgColor} ${borderColor}`}
                      >
                        <div className="flex items-center">
                          <div className={`h-5 w-5 rounded-full border-2 
                            ${isUserAnswer ? 'border-primary-500 bg-primary-50' : 'border-gray-300'} 
                            mr-3 flex-shrink-0`}
                          ></div>
                          <span>{option}</span>
                        </div>
                        {icon}
                      </div>
                    );
                  })}
                </div>
                
                <div className="mt-6 p-4 bg-neutral-50 rounded-md">
                  <h4 className="font-medium mb-2 flex items-center">
                    <HelpCircle className="h-4 w-4 text-primary-500 mr-2" />
                    Explanation
                  </h4>
                  <p className="text-neutral-600">
                    {currentQuestion.explanation}
                  </p>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  variant="outline"
                  onClick={handlePrevQuestion}
                  disabled={currentQuestionIndex === 0}
                >
                  <ChevronLeft className="mr-2 h-4 w-4" />
                  Previous
                </Button>
                
                {currentQuestionIndex < examQuestions.length - 1 ? (
                  <Button onClick={handleNextQuestion}>
                    Next
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                ) : (
                  <Button 
                    className="bg-primary-500 hover:bg-primary-600"
                    onClick={() => {
                      setReviewMode(false);
                    }}
                  >
                    Finish Review
                  </Button>
                )}
              </CardFooter>
            </Card>
            
            <div className="grid grid-cols-10 gap-2">
              {examQuestions.map((_, index) => {
                const isCurrentQuestion = index === currentQuestionIndex;
                const isAnswered = userAnswers[index] !== -1;
                const isCorrect = userAnswers[index] === examQuestions[index].correctAnswer;
                
                let bgColor = "bg-gray-100";
                let textColor = "text-gray-700";
                
                if (isAnswered) {
                  if (isCorrect) {
                    bgColor = "bg-green-100";
                    textColor = "text-green-700";
                  } else {
                    bgColor = "bg-red-100";
                    textColor = "text-red-700";
                  }
                }
                
                if (isCurrentQuestion) {
                  bgColor = "bg-primary-100";
                  textColor = "text-primary-700";
                }
                
                return (
                  <button
                    key={index}
                    className={`h-8 w-8 rounded-full ${bgColor} ${textColor} flex items-center justify-center text-xs font-medium
                      ${isCurrentQuestion ? "ring-2 ring-primary-500" : ""}`}
                    onClick={() => setCurrentQuestionIndex(index)}
                  >
                    {index + 1}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    );
  }
  
  // Render exam in progress
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">SPSV Mock Examination</h1>
        <div className="flex items-center bg-neutral-100 px-3 py-1 rounded-md">
          <Timer className="h-4 w-4 text-neutral-500 mr-2" />
          <span className={`font-mono font-medium ${timeRemaining < 300 ? "text-red-500" : "text-neutral-700"}`}>
            {formatTime(timeRemaining)}
          </span>
        </div>
      </div>
      
      <div className="flex justify-between items-center mb-4">
        <div className="text-sm text-neutral-500">
          Question {currentQuestionIndex + 1} of {examQuestions.length}
        </div>
        <div className="text-sm font-medium">
          Progress: {Math.round(((currentQuestionIndex + (userAnswers[currentQuestionIndex] !== -1 ? 1 : 0)) / examQuestions.length) * 100)}%
        </div>
      </div>
      
      <Progress 
        value={((currentQuestionIndex + (userAnswers[currentQuestionIndex] !== -1 ? 1 : 0)) / examQuestions.length) * 100} 
        className="h-2 mb-6"
      />
      
      <Card>
        <CardHeader>
          <CardTitle>{currentQuestion.question}</CardTitle>
        </CardHeader>
        <CardContent>
          {currentQuestion.image && (
            <div className="mb-6 rounded-md overflow-hidden">
              <img 
                src={currentQuestion.image} 
                alt="Question illustration" 
                className="w-full h-auto"
              />
            </div>
          )}
          
          <div className="space-y-2">
            {currentQuestion.options.map((option, index) => (
              <div 
                key={index} 
                className={`flex items-center p-3 border rounded-md cursor-pointer hover:bg-gray-50
                  ${userAnswers[currentQuestionIndex] === index ? 'border-primary-500 bg-primary-50' : 'border-gray-200'}`}
                onClick={() => handleSelectAnswer(index)}
              >
                <div className={`h-5 w-5 rounded-full border-2 
                  ${userAnswers[currentQuestionIndex] === index ? 'border-primary-500 bg-primary-50' : 'border-gray-300'} 
                  mr-3 flex-shrink-0`}
                ></div>
                <span>{option}</span>
              </div>
            ))}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button 
            variant="outline"
            onClick={handlePrevQuestion}
            disabled={currentQuestionIndex === 0}
          >
            <ChevronLeft className="mr-2 h-4 w-4" />
            Previous
          </Button>
          
          <Button
            className="bg-primary-500 hover:bg-primary-600"
            onClick={handleNextQuestion}
            disabled={userAnswers[currentQuestionIndex] === -1}
          >
            {currentQuestionIndex < examQuestions.length - 1 ? (
              <>
                Next
                <ChevronRight className="ml-2 h-4 w-4" />
              </>
            ) : (
              <>
                Finish Exam
                <Check className="ml-2 h-4 w-4" />
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
      
      <div className="grid grid-cols-10 gap-2">
        {examQuestions.map((_, index) => (
          <button
            key={index}
            className={`h-8 w-8 rounded-full 
              ${userAnswers[index] !== -1 ? "bg-primary-100 text-primary-700" : "bg-gray-100 text-gray-700"} 
              ${index === currentQuestionIndex ? "ring-2 ring-primary-500" : ""}
              flex items-center justify-center text-xs font-medium`}
            onClick={() => setCurrentQuestionIndex(index)}
          >
            {index + 1}
          </button>
        ))}
      </div>
    </div>
  );
}