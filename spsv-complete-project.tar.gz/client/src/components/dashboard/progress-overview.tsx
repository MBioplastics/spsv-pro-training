import { Progress } from "@/components/ui/progress";

type ProgressItemProps = {
  label: string;
  value: number;
  color: string;
};

const ProgressItem = ({ label, value, color }: ProgressItemProps) => {
  return (
    <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-neutral-600">{label}</span>
        <span className={`text-sm font-bold text-${color}`}>{value}%</span>
      </div>
      <Progress 
        value={value} 
        className="h-2.5 bg-gray-200"
        colorClass={`bg-${color}`}
      />
    </div>
  );
};

type ProgressOverviewProps = {
  trainingProgress: number;
  practiceTestProgress: number;
  checklistProgress: number;
};

export function ProgressOverview({ 
  trainingProgress, 
  practiceTestProgress, 
  checklistProgress 
}: ProgressOverviewProps) {
  return (
    <div className="mb-8">
      <h2 className="text-lg font-semibold text-neutral-700 mb-4">Your Progress</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <ProgressItem 
          label="Training Completion" 
          value={trainingProgress} 
          color="secondary-500" 
        />
        
        <ProgressItem 
          label="Practice Tests" 
          value={practiceTestProgress} 
          color="accent-500" 
        />
        
        <ProgressItem 
          label="Checklists Completed" 
          value={checklistProgress} 
          color="primary-500" 
        />
      </div>
    </div>
  );
}
