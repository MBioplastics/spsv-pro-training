import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Home,
  School,
  ClipboardCheck,
  CalendarCheck,
  FileText,
  Settings,
  HelpCircle,
  Car,
  User,
  ChevronRight,
  LogOut,
  Menu,
  X
} from "lucide-react";
import { useState } from "react";

type SidebarItemProps = {
  icon: React.ReactNode;
  label: string;
  href: string;
  showChevron?: boolean;
  active?: boolean;
  onClick?: () => void;
};

function SidebarItem({ icon, label, href, showChevron = false, active = false, onClick }: SidebarItemProps) {
  return (
    <Link href={href}>
      <div
        className={cn(
          "flex items-center justify-between px-3 py-2 rounded-md cursor-pointer",
          active
            ? "bg-primary-500 text-white"
            : "text-neutral-300 hover:bg-neutral-700"
        )}
        onClick={onClick}
      >
        <div className="flex items-center">
          {icon}
          <span className="ml-2">{label}</span>
        </div>
        {showChevron && <ChevronRight className="h-4 w-4" />}
      </div>
    </Link>
  );
}

type SidebarProps = {
  userName: string;
  userRole: string;
};

export function Sidebar({ userName, userRole }: SidebarProps) {
  const [location] = useLocation();
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  return (
    <>
      {/* Mobile Menu Button */}
      <button 
        className="md:hidden fixed top-4 left-4 z-50 p-2 bg-neutral-800 text-white rounded-md shadow-lg"
        onClick={() => setIsMobileOpen(!isMobileOpen)}
      >
        {isMobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </button>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "bg-neutral-800 text-white h-screen flex-shrink-0 transition-transform duration-300 ease-in-out",
        "md:w-64 md:translate-x-0 md:relative md:z-auto",
        "fixed z-40 w-64",
        isMobileOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-4 border-b border-neutral-700">
        <div className="flex items-center space-x-3">
          <User className="h-5 w-5" />
          <div>
            <p className="font-medium">{userName}</p>
            <p className="text-xs text-neutral-300">{userRole}</p>
          </div>
        </div>
      </div>
      
      <nav className="p-2">
        <div className="space-y-1">
          <SidebarItem
            icon={<Home className="h-4 w-4" />}
            label="Dashboard"
            href="/dashboard"
            active={location === '/dashboard'}
          />
          
          <SidebarItem
            icon={<School className="h-4 w-4" />}
            label="Training Modules"
            href="/training"
            showChevron
            active={location === '/training'}
          />
          
          <SidebarItem
            icon={<ClipboardCheck className="h-4 w-4" />}
            label="Practice Tests"
            href="/practice-tests"
            showChevron
            active={location === '/practice-tests'}
          />
          
          <SidebarItem
            icon={<Car className="h-4 w-4" />}
            label="Vehicle Finder"
            href="/vehicle-search"
            active={location === '/vehicle-search'}
          />
          
          <SidebarItem
            icon={<FileText className="h-4 w-4" />}
            label="Checklists"
            href="/checklists"
            showChevron
            active={location === '/checklists'}
          />
          
          <SidebarItem
            icon={<CalendarCheck className="h-4 w-4" />}
            label="Bookings"
            href="/bookings"
            showChevron
            active={location === '/bookings'}
          />
        </div>
        
        <div className="mt-8 space-y-1">
          <SidebarItem
            icon={<Settings className="h-4 w-4" />}
            label="Settings"
            href="/settings"
            active={location === '/settings'}
          />
          
          <SidebarItem
            icon={<HelpCircle className="h-4 w-4" />}
            label="Help & Support"
            href="/support"
            active={location === '/support'}
          />
          
          <div className="mt-4 pt-4 border-t border-neutral-700">
            <SidebarItem
              icon={<LogOut className="h-4 w-4" />}
              label="Sign Out"
              href="/logout"
            />
          </div>
        </div>
      </nav>
      </div>
    </>
  );
}
