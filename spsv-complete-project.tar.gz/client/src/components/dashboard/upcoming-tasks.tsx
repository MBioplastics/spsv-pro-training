import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ClipboardCheck, User, CalendarCheck, Euro } from "lucide-react";

type Task = {
  id: string;
  title: string;
  dueIn: string;
  icon: string;
  iconColor: string;
  action: string;
  href: string;
};

type UpcomingTasksProps = {
  tasks: Task[];
};

export function UpcomingTasks({ tasks }: UpcomingTasksProps) {
  const getIcon = (iconName: string, color: string) => {
    switch (iconName) {
      case 'clipboard':
        return <ClipboardCheck className={`h-5 w-5 text-${color}`} />;
      case 'user':
        return <User className={`h-5 w-5 text-${color}`} />;
      case 'calendar':
        return <CalendarCheck className={`h-5 w-5 text-${color}`} />;
      case 'euro':
        return <Euro className={`h-5 w-5 text-${color}`} />;
      default:
        return <ClipboardCheck className={`h-5 w-5 text-${color}`} />;
    }
  };

  return (
    <div>
      <h2 className="text-lg font-semibold text-neutral-700 mb-4">Upcoming Tasks</h2>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <ul className="divide-y divide-gray-200">
          {tasks.map((task) => (
            <li key={task.id} className="p-4 hover:bg-gray-50 flex items-center justify-between">
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  {getIcon(task.icon, task.iconColor)}
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-neutral-800">{task.title}</p>
                  <p className="text-xs text-neutral-500">Due in {task.dueIn}</p>
                </div>
              </div>
              <Link href={task.href}>
                <Button 
                  variant="link" 
                  size="sm" 
                  className="text-primary-500 hover:text-primary-600"
                >
                  {task.action}
                </Button>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
