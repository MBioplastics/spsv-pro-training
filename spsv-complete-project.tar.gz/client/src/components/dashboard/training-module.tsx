import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, CarTaxiFront } from "lucide-react";

type TrainingModuleProps = {
  title: string;
  description: string;
  progress: number;
  onContinue: () => void;
};

export function TrainingModule({ 
  title, 
  description, 
  progress, 
  onContinue 
}: TrainingModuleProps) {
  return (
    <div className="bg-white rounded-lg shadow p-6 border-l-4 border-primary-500">
      <div className="flex items-start">
        <div className="flex-grow">
          <h3 className="text-xl font-semibold mb-2">{title}</h3>
          <p className="text-neutral-600 mb-4">{description}</p>
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-neutral-600">Progress</span>
              <span className="text-sm font-bold text-primary-500">{progress}%</span>
            </div>
            <Progress value={progress} className="h-2.5 bg-gray-200" indicatorColor="bg-primary-500" />
          </div>
          <Button
            className="bg-primary-500 hover:bg-primary-600"
            onClick={onContinue}
          >
            Continue Learning
            <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
        <div className="ml-4 flex-shrink-0">
          <CarTaxiFront className="h-12 w-12 text-neutral-400" />
        </div>
      </div>
    </div>
  );
}
