import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { SPSV_TYPES } from "@/lib/constants";

type VehicleSelectorProps = {
  value: string;
  onChange: (value: string) => void;
  className?: string;
};

export function VehicleSelector({ value, onChange, className }: VehicleSelectorProps) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className={className || "w-[180px]"}>
        <SelectValue placeholder="Select vehicle type" />
      </SelectTrigger>
      <SelectContent>
        {SPSV_TYPES.map((type) => (
          <SelectItem key={type.id} value={type.id}>
            {type.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
