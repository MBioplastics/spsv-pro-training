import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChecklistItem, type ChecklistItemData } from "./checklist-item";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Save, FileDown } from "lucide-react";

type ChecklistGroupProps = {
  title: string;
  items: ChecklistItemData[];
  onSave: (items: ChecklistItemData[]) => void;
};

export function ChecklistGroup({ title, items, onSave }: ChecklistGroupProps) {
  const [checklistItems, setChecklistItems] = useState<ChecklistItemData[]>(items);
  
  const handleToggle = (id: string, isCompleted: boolean) => {
    const updatedItems = checklistItems.map(item => 
      item.id === id ? { ...item, isCompleted } : item
    );
    setChecklistItems(updatedItems);
  };
  
  const handleSave = () => {
    onSave(checklistItems);
  };
  
  const calculateProgress = () => {
    const completedItems = checklistItems.filter(item => item.isCompleted).length;
    return Math.round((completedItems / checklistItems.length) * 100);
  };
  
  const handleDownload = () => {
    // Create a text representation of the checklist
    let checklistText = `${title}\n\n`;
    
    checklistItems.forEach(item => {
      checklistText += `[${item.isCompleted ? 'X' : ' '}] ${item.title}\n`;
      checklistText += `    ${item.description}\n\n`;
    });
    
    // Create a download link
    const element = document.createElement('a');
    const file = new Blob([checklistText], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `${title.toLowerCase().replace(/\s+/g, '-')}-checklist.txt`;
    
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-primary-500">
          {title}
          <span className="ml-2 text-sm text-neutral-500">
            ({calculateProgress()}% complete)
          </span>
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {checklistItems.map(item => (
            <ChecklistItem
              key={item.id}
              item={item}
              onToggle={handleToggle}
            />
          ))}
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button
          className="bg-primary-500 hover:bg-primary-600"
          onClick={handleSave}
        >
          <Save className="h-4 w-4 mr-1" />
          <span>Save Progress</span>
        </Button>
        <Button
          className="bg-secondary-500 hover:bg-secondary-600"
          onClick={handleDownload}
        >
          <FileDown className="h-4 w-4 mr-1" />
          <span>Download Checklist</span>
        </Button>
      </CardFooter>
    </Card>
  );
}
