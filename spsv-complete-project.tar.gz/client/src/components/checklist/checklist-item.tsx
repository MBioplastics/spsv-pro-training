import { useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export type ChecklistItemData = {
  id: string;
  title: string;
  description: string;
  tooltipText: string;
  isCompleted: boolean;
};

type ChecklistItemProps = {
  item: ChecklistItemData;
  onToggle: (id: string, isCompleted: boolean) => void;
};

export function ChecklistItem({ item, onToggle }: ChecklistItemProps) {
  const { id, title, description, tooltipText, isCompleted } = item;
  
  const handleToggle = (checked: boolean) => {
    onToggle(id, checked);
  };
  
  return (
    <div className="flex items-start p-3 border border-gray-200 rounded-lg bg-gray-50">
      <Checkbox 
        id={id} 
        className="h-5 w-5 mt-0.5" 
        checked={isCompleted}
        onCheckedChange={handleToggle}
      />
      <label htmlFor={id} className="ml-3 flex-1">
        <span className="block text-sm font-medium text-gray-700">{title}</span>
        <span className="block text-sm text-gray-500">{description}</span>
      </label>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Info className="h-5 w-5 text-primary-500 cursor-pointer" />
          </TooltipTrigger>
          <TooltipContent>
            <p className="w-[200px] text-sm">{tooltipText}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
}
