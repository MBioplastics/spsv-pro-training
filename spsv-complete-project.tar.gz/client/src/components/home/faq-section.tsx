import { useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

type FAQItem = {
  question: string;
  answer: string;
};

export function FAQSection() {
  const faqItems: FAQItem[] = [
    {
      question: "How up-to-date is your training content?",
      answer: "Our content is regularly updated to reflect the latest version of the SPSV Official Manual (currently Edition 7.8) and any regulatory changes from the National Transport Authority. We monitor all updates to ensure our training materials remain current."
    },
    {
      question: "Do I need to pay any additional fees beyond the subscription?",
      answer: "No, our pricing plans (€49 for 30 days, €109 for 60 days, or €399 for 12 months access) cover all our training materials, practice tests, checklists, and updates. The only additional costs would be the official fees payable to the NTA for licences, tests, and vehicle inspections."
    },
    {
      question: "Can I access the materials on my mobile phone?",
      answer: "Yes, our platform is fully responsive and works on smartphones, tablets, and computers. You can study on the go, track your progress, and even take practice tests from any device with an internet connection."
    },
    {
      question: "What if I fail my SPSV test after using your platform?",
      answer: "While our success rate is very high, our platform offers comprehensive practice tests and study materials designed to help you identify areas for improvement. The detailed feedback from our practice tests will help you focus on areas that require more attention before retaking the official test."
    },
    {
      question: "Can I make official payments through your platform?",
      answer: "Our platform provides direct links to the official NTA payment portal for licence fees and other official payments. While we don't process these payments ourselves (for security reasons), we guide you through each step of the payment process on the official website."
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary-500 mb-4">Frequently Asked Questions</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Find answers to common questions about our platform and SPSV licensing.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto space-y-4">
          <Accordion type="single" collapsible className="w-full">
            {faqItems.map((item, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="bg-white rounded-lg shadow-sm">
                <AccordionTrigger className="px-6 py-4 hover:no-underline">
                  <span className="font-medium text-neutral-800 text-left">{item.question}</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4">
                  <p className="text-neutral-600">{item.answer}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
