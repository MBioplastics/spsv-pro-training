import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ExternalLink } from "lucide-react";
import { SPSV_TYPES, LICENSE_DURATIONS, LICENSE_FEES, NTA_WEBSITE } from "@/lib/constants";

export function FeeCalculator() {
  const [selectedVehicleType, setSelectedVehicleType] = useState("taxi");
  const [applicationType, setApplicationType] = useState("new");
  const [licenseDuration, setLicenseDuration] = useState("1");
  const [additionalServices, setAdditionalServices] = useState({
    vehicleSuitability: true,
    meterVerification: false,
    driverEntryTest: true,
  });
  const [totalFees, setTotalFees] = useState(690);

  const handleCalculate = () => {
    let total = 0;
    
    // Driver licence fee
    total += applicationType === "new" 
      ? LICENSE_FEES.driver.new 
      : LICENSE_FEES.driver.renewal;
    
    // Vehicle licence fee
    total += LICENSE_FEES.vehicle[selectedVehicleType as keyof typeof LICENSE_FEES.vehicle];
    
    // Additional services
    if (additionalServices.vehicleSuitability) {
      total += LICENSE_FEES.services.vehicle_suitability;
    }
    
    if (additionalServices.meterVerification) {
      total += LICENSE_FEES.services.meter_verification;
    }
    
    if (additionalServices.driverEntryTest) {
      total += LICENSE_FEES.services.driver_entry_test;
    }
    
    setTotalFees(total);
  };

  return (
    <section id="calculator" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary-500 mb-4">SPSV Licence Fee Calculator</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Understand all the costs involved in obtaining and maintaining your SPSV licences.
          </p>
        </div>
        
        <Card className="max-w-4xl mx-auto">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-semibold mb-6 text-primary-500">Fee Estimator</h3>
                
                <div className="space-y-4">
                  <div>
                    <Label className="block text-sm font-medium text-gray-700 mb-1">SPSV Type</Label>
                    <Select 
                      value={selectedVehicleType}
                      onValueChange={setSelectedVehicleType}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select SPSV Type" />
                      </SelectTrigger>
                      <SelectContent>
                        {SPSV_TYPES.map(type => (
                          <SelectItem key={type.id} value={type.id}>
                            {type.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-gray-700 mb-1">New Application or Renewal?</Label>
                    <RadioGroup
                      value={applicationType}
                      onValueChange={setApplicationType}
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="new" id="new" />
                        <Label htmlFor="new">New Application</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="renewal" id="renewal" />
                        <Label htmlFor="renewal">Renewal</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-gray-700 mb-1">Licence Duration</Label>
                    <Select 
                      value={licenseDuration}
                      onValueChange={setLicenseDuration}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select Duration" />
                      </SelectTrigger>
                      <SelectContent>
                        {LICENSE_DURATIONS.map(duration => (
                          <SelectItem key={duration.id} value={duration.id.toString()}>
                            {duration.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-gray-700 mb-1">Include Additional Services?</Label>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <Checkbox 
                          id="service1" 
                          checked={additionalServices.vehicleSuitability}
                          onCheckedChange={(checked) => 
                            setAdditionalServices({
                              ...additionalServices,
                              vehicleSuitability: checked as boolean
                            })
                          }
                        />
                        <Label htmlFor="service1" className="ml-2 block text-sm text-gray-700">
                          Vehicle Suitability Certificate (€200)
                        </Label>
                      </div>
                      <div className="flex items-center">
                        <Checkbox 
                          id="service2" 
                          checked={additionalServices.meterVerification}
                          onCheckedChange={(checked) =>
                            setAdditionalServices({
                              ...additionalServices,
                              meterVerification: checked as boolean
                            })
                          }
                        />
                        <Label htmlFor="service2" className="ml-2 block text-sm text-gray-700">
                          Meter Verification (€55)
                        </Label>
                      </div>
                      <div className="flex items-center">
                        <Checkbox 
                          id="service3" 
                          checked={additionalServices.driverEntryTest}
                          onCheckedChange={(checked) =>
                            setAdditionalServices({
                              ...additionalServices,
                              driverEntryTest: checked as boolean
                            })
                          }
                        />
                        <Label htmlFor="service3" className="ml-2 block text-sm text-gray-700">
                          Driver Entry Test (€90)
                        </Label>
                      </div>
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full bg-primary-500 hover:bg-primary-600"
                    onClick={handleCalculate}
                  >
                    Calculate Fees
                  </Button>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold mb-6 text-primary-500">Fee Breakdown</h3>
                
                <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center pb-2 border-b border-gray-200">
                      <span className="text-sm font-medium text-gray-700">Driver Licence Fee</span>
                      <span className="text-sm text-gray-900">€250.00</span>
                    </div>
                    
                    <div className="flex justify-between items-center pb-2 border-b border-gray-200">
                      <span className="text-sm font-medium text-gray-700">Vehicle Licence Fee (Taxi)</span>
                      <span className="text-sm text-gray-900">€150.00</span>
                    </div>
                    
                    <div className="flex justify-between items-center pb-2 border-b border-gray-200">
                      <span className="text-sm font-medium text-gray-700">Vehicle Suitability Certificate</span>
                      <span className="text-sm text-gray-900">€200.00</span>
                    </div>
                    
                    <div className="flex justify-between items-center pb-2 border-b border-gray-200">
                      <span className="text-sm font-medium text-gray-700">Driver Entry Test</span>
                      <span className="text-sm text-gray-900">€90.00</span>
                    </div>
                    
                    <div className="flex justify-between items-center text-lg font-bold text-primary-500 pt-2">
                      <span>Total Estimated Cost</span>
                      <span>€{totalFees.toFixed(2)}</span>
                    </div>
                    
                    <div className="mt-6 text-sm text-gray-500">
                      <p>* Prices are indicative and based on current NTA fee schedules.</p>
                      <p>* Additional costs may apply based on your specific circumstances.</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <a 
                    href={NTA_WEBSITE}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary-500 hover:text-primary-600 font-medium text-sm flex items-center"
                  >
                    <ExternalLink className="h-4 w-4 mr-1" />
                    <span>View official NTA fee schedule</span>
                  </a>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
