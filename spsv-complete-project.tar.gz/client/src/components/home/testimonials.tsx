import { Star, StarHalf } from "lucide-react";

type TestimonialProps = {
  rating: number;
  quote: string;
  initials: string;
  name: string;
  role: string;
};

const Testimonial = ({ rating, quote, initials, name, role }: TestimonialProps) => {
  const renderStars = () => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

    // Filled gold stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="h-5 w-5 fill-yellow-500 text-yellow-500" />);
    }

    // Half star if needed
    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="h-5 w-5 fill-yellow-500 text-yellow-500" />);
    }

    // Empty stars to complete 5 stars
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-star-${i}`} className="h-5 w-5 text-yellow-500" />);
    }

    return stars;
  };

  return (
    <div className="bg-gray-50 rounded-lg p-6 shadow-sm">
      <div className="flex items-center mb-4">
        <div className="text-yellow-500 flex">
          {renderStars()}
        </div>
      </div>
      <p className="text-neutral-700 mb-6">{quote}</p>
      <div className="flex items-center">
        <div className="h-10 w-10 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">
          {initials}
        </div>
        <div className="ml-3">
          <div className="font-medium text-neutral-800">{name}</div>
          <div className="text-sm text-neutral-500">{role}</div>
        </div>
      </div>
    </div>
  );
};

export function Testimonials() {
  const testimonials = [
    {
      rating: 5,
      quote: "The practice tests were spot on! I passed my SPSV test on the first attempt thanks to this platform. The checklists made sure I had all my documents ready.",
      initials: "MM",
      name: "Michael Murphy",
      role: "Taxi Driver, Dublin"
    },
    {
      rating: 5,
      quote: "As someone not great with technology, I found this system very easy to use. The training videos and step-by-step guides were brilliant. Well worth the money!",
      initials: "SO",
      name: "Sarah O'Brien",
      role: "Hackney Driver, Cork"
    },
    {
      rating: 4.5,
      quote: "The WAV-specific training was exactly what I needed. It covered everything from accessibility requirements to helping passengers safely. Highly recommended!",
      initials: "JK",
      name: "James Kelly",
      role: "WAT Driver, Galway"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary-500 mb-4">What Our Users Say</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Hear from drivers who successfully obtained their SPSV licences with our help.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <Testimonial
              key={index}
              rating={testimonial.rating}
              quote={testimonial.quote}
              initials={testimonial.initials}
              name={testimonial.name}
              role={testimonial.role}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
