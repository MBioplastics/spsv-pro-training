import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

export function HeroSection() {
  const [loaded, setLoaded] = useState(false);
  
  useEffect(() => {
    // Simulate loading process
    setLoaded(true);
  }, []);
  
  // Create different car shapes for animation
  const createCarElements = () => {
    const elements = [];
    const carTypes = ['🚕', '🚖', '🚘', '🚗']; // Taxi, Hackney, Limo, Car
    
    for (let i = 0; i < 10; i++) {
      const delay = Math.random() * 20;
      const duration = 15 + Math.random() * 30;
      const size = 30 + Math.random() * 40;
      const verticalPos = 10 + Math.random() * 80;
      const randomCar = carTypes[Math.floor(Math.random() * carTypes.length)];
      
      elements.push(
        <div 
          key={i}
          className="absolute animate-car-move"
          style={{
            fontSize: `${size}px`,
            top: `${verticalPos}%`,
            right: `-${size}px`,
            animationDuration: `${duration}s`,
            animationDelay: `${delay}s`,
            opacity: 0.15
          }}
        >
          {randomCar}
        </div>
      );
    }
    
    return elements;
  };

  return (
    <section className="bg-gradient-to-r from-primary-800 to-primary-600 text-white py-16 relative overflow-hidden">
      {/* Dark overlay to ensure text readability */}
      <div className="absolute inset-0 bg-black opacity-50 z-0"></div>
      
      {/* Animated cars background */}
      <div className={`absolute inset-0 transition-opacity duration-1000 ${loaded ? 'opacity-100' : 'opacity-0'}`}>
        {createCarElements()}
      </div>
      
      {/* Road lanes */}
      <div className="absolute bottom-0 w-full h-6 bg-gray-700 z-10"></div>
      <div className="absolute bottom-0 w-full h-2 bg-yellow-400 z-10 
        animate-lane-dash" style={{ opacity: 0.6 }}></div>
      
      {/* Content */}
      <div className="container mx-auto px-4 relative z-20">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 drop-shadow-md">
            Ireland's Leading SPSV Training Platform - Taxi, Hackney & Limousine Certification
          </h1>
          <p className="text-xl mb-8 drop-shadow-sm">
            Pass your Small Public Service Vehicle exam first time with comprehensive training modules, practice tests, and specialised area knowledge for select Irish counties. NTA-approved content for taxi drivers, hackney operators, and limousine chauffeurs.
          </p>
          <div className="mt-4">
            {/* Button removed as requested */}
          </div>
        </div>
      </div>
    </section>
  );
}
