import { 
  Home, 
  School, 
  ClipboardCheck, 
  CalendarCheck, 
  FileText, 
  Settings, 
  HelpCircle,
  User,
  ChevronRight,
  CarTaxiFront,
  ArrowRight,
  CircleDollarSign
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SPSV_TYPES } from "@/lib/constants";

export function ApplicationPreview() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary-500 mb-4">Explore the Platform</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Take a look at our intuitive, user-friendly interface designed for drivers of all ages.
          </p>
        </div>
        
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="flex flex-col lg:flex-row">
            {/* Sidebar */}
            <div className="lg:w-64 bg-neutral-800 text-white lg:h-[600px] flex-shrink-0">
              <div className="p-4 border-b border-neutral-700">
                <div className="flex items-center space-x-3">
                  <User className="h-5 w-5" />
                  <div>
                    <p className="font-medium">John Murphy</p>
                    <p className="text-xs text-neutral-300">SPSV Pro Training Driver Trainee</p>
                  </div>
                </div>
              </div>
              
              <nav className="p-2">
                <div className="mb-4">
                  <div className="flex items-center justify-between px-3 py-2 rounded-md bg-primary-500">
                    <div className="flex items-center">
                      <Home className="h-4 w-4 mr-2" />
                      <span>Dashboard</span>
                    </div>
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between px-3 py-2 rounded-md text-neutral-300 hover:bg-neutral-700 cursor-pointer">
                    <div className="flex items-center">
                      <School className="h-4 w-4 mr-2" />
                      <span>Training Modules</span>
                    </div>
                    <ChevronRight className="h-4 w-4" />
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between px-3 py-2 rounded-md text-neutral-300 hover:bg-neutral-700 cursor-pointer">
                    <div className="flex items-center">
                      <ClipboardCheck className="h-4 w-4 mr-2" />
                      <span>Practice Tests</span>
                    </div>
                    <ChevronRight className="h-4 w-4" />
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between px-3 py-2 rounded-md text-neutral-300 hover:bg-neutral-700 cursor-pointer">
                    <div className="flex items-center">
                      <FileText className="h-4 w-4 mr-2" />
                      <span>Checklists</span>
                    </div>
                    <ChevronRight className="h-4 w-4" />
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between px-3 py-2 rounded-md text-neutral-300 hover:bg-neutral-700 cursor-pointer">
                    <div className="flex items-center">
                      <CalendarCheck className="h-4 w-4 mr-2" />
                      <span>Bookings</span>
                    </div>
                    <ChevronRight className="h-4 w-4" />
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between px-3 py-2 rounded-md text-neutral-300 hover:bg-neutral-700 cursor-pointer">
                    <div className="flex items-center">
                      <CarTaxiFront className="h-4 w-4 mr-2" />
                      <span>Vehicle Finder</span>
                    </div>
                    <ChevronRight className="h-4 w-4" />
                  </div>
                </div>
                
                <div className="mt-8">
                  <div className="flex items-center justify-between px-3 py-2 rounded-md text-neutral-300 hover:bg-neutral-700 cursor-pointer">
                    <div className="flex items-center">
                      <Settings className="h-4 w-4 mr-2" />
                      <span>Settings</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between px-3 py-2 rounded-md text-neutral-300 hover:bg-neutral-700 cursor-pointer">
                    <div className="flex items-center">
                      <HelpCircle className="h-4 w-4 mr-2" />
                      <span>Help & Support</span>
                    </div>
                  </div>
                </div>
              </nav>
            </div>
            
            {/* Main Content */}
            <div className="flex-1 overflow-auto">
              <div className="p-6">
                <h1 className="text-2xl font-bold text-neutral-800 mb-6">Dashboard</h1>
                
                {/* Progress Overview */}
                <div className="mb-8">
                  <h2 className="text-lg font-semibold text-neutral-700 mb-4">Your Progress</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-neutral-600">Training Completion</span>
                        <span className="text-sm font-bold text-secondary-500">65%</span>
                      </div>
                      <Progress value={65} className="h-2.5 bg-gray-200" colorClass="bg-secondary-500" />
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-neutral-600">Practice Tests</span>
                        <span className="text-sm font-bold text-accent-500">40%</span>
                      </div>
                      <Progress value={40} className="h-2.5 bg-gray-200" colorClass="bg-accent-500" />
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-neutral-600">Checklists Completed</span>
                        <span className="text-sm font-bold text-primary-500">60%</span>
                      </div>
                      <Progress value={60} className="h-2.5 bg-gray-200" colorClass="bg-primary-500" />
                    </div>
                  </div>
                </div>
                
                {/* Current Training Module */}
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-neutral-700">Continue Your Training</h2>
                    <Select defaultValue="taxi">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Select vehicle type" />
                      </SelectTrigger>
                      <SelectContent>
                        {SPSV_TYPES.map((type) => (
                          <SelectItem key={type.id} value={type.id}>
                            {type.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow p-6 border-l-4 border-primary-500">
                    <div className="flex items-start">
                      <div className="flex-grow">
                        <h3 className="text-xl font-semibold mb-2">Module 5: Working as an SPSV Operator</h3>
                        <p className="text-neutral-600 mb-4">
                          Learn about the day-to-day responsibilities and best practices for SPSV operators.
                        </p>
                        <div className="mb-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium text-neutral-600">Progress</span>
                            <span className="text-sm font-bold text-primary-500">40%</span>
                          </div>
                          <Progress value={40} className="h-2.5 bg-gray-200" colorClass="bg-primary-500" />
                        </div>
                        <Button className="bg-primary-500 hover:bg-primary-600">
                          Continue Learning
                          <ArrowRight className="h-4 w-4 ml-1" />
                        </Button>
                      </div>
                      <div className="ml-4 flex-shrink-0">
                        <CarTaxiFront className="h-12 w-12 text-neutral-400" />
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Upcoming Tasks section removed */}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
