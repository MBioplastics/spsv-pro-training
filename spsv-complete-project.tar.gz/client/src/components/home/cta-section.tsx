import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export function CTASection() {
  return (
    <section className="py-16 bg-primary-500 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-6">Ready to Start Your SPSV Career?</h2>
        <p className="text-xl mb-8 max-w-2xl mx-auto">
          Prepare for your SPSV certification with our comprehensive training platform.
        </p>
        <div className="flex justify-center">
          <a href="#pricing" onClick={(e) => { 
            e.preventDefault(); 
            document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
          }}>
            <Button className="bg-white text-primary-500 hover:bg-gray-100 font-bold py-3 px-10 rounded-md text-center transition-colors text-lg">
              View Plans
            </Button>
          </a>
        </div>
      </div>
    </section>
  );
}
