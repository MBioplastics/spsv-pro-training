import { Award, Clock, HeartHandshake } from "lucide-react";

export function AboutSection() {
  return (
    <section id="about" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary-500 mb-4">About SPSV Pro Training</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            We help aspiring drivers navigate the complex SPSV licensing process in Ireland.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-lg shadow-md text-center">
            <div className="bg-primary-50 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Clock className="h-8 w-8 text-primary-500" />
            </div>
            <h3 className="text-xl font-bold mb-3">Established 2025</h3>
            <p className="text-neutral-600">
              Our pioneering approach to SPSV training incorporates the latest NTA requirements and regulations to help you succeed.
            </p>
          </div>
          
          <div className="bg-white p-8 rounded-lg shadow-md text-center">
            <div className="bg-primary-50 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Award className="h-8 w-8 text-primary-500" />
            </div>
            <h3 className="text-xl font-bold mb-3">Updated Materials</h3>
            <p className="text-neutral-600">
              Our training materials are perfectly aligned with the most up-to-date NTA manual and official guidance documents.
            </p>
          </div>
          
          <div className="bg-white p-8 rounded-lg shadow-md text-center">
            <div className="bg-primary-50 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <HeartHandshake className="h-8 w-8 text-primary-500" />
            </div>
            <h3 className="text-xl font-bold mb-3">Our Mission</h3>
            <p className="text-neutral-600">
              We're committed to raising the standard of SPSV service in Ireland by providing comprehensive, accessible training.
            </p>
          </div>
        </div>
        
        <div className="mt-12 bg-white p-8 rounded-lg shadow-md">
          <h3 className="text-2xl font-bold text-primary-500 mb-4">Our Story</h3>
          <p className="text-neutral-600 mb-4">
            SPSV Pro Training was founded by a team of limousine drivers who recognised the challenges facing new entrants to the Small Public Service Vehicle industry in Ireland.
          </p>
          <p className="text-neutral-600 mb-4">
            After witnessing many aspiring drivers struggle with the complex licensing process and failing tests due to inadequate preparation materials, we decided to create a comprehensive solution that addresses all aspects of SPSV training.
          </p>
          <p className="text-neutral-600">
            Today, our platform has become the go-to resource for anyone looking to start or advance their career in the SPSV industry.
          </p>
        </div>
      </div>
    </section>
  );
}