import { MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";

export function ContactSection() {
  const [formSubmitted, setFormSubmitted] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, we would submit the form data to a server
    // For now, just show a success message
    setFormSubmitted(true);
  };
  
  return (
    <section id="contact" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary-500 mb-4">Contact Us</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Have questions about SPSV licensing or our training platform? We're here to help.
          </p>
        </div>
        
        {/* Contact information removed as per requirements, showing only the message form */}
        
        <div className="mt-12 bg-gray-50 p-8 rounded-lg shadow-md">
          <h3 className="text-2xl font-bold text-primary-500 mb-6">Send Us a Message</h3>
          
          {formSubmitted ? (
            <div className="text-center p-8">
              <div className="bg-green-100 text-green-800 p-4 rounded-lg mb-4">
                Thank you for your message! We'll get back to you as soon as possible.
              </div>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setFormSubmitted(false)}
              >
                Send Another Message
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-neutral-700 mb-1">Name</label>
                  <Input id="name" placeholder="Your name" required />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-neutral-700 mb-1">Email</label>
                  <Input id="email" type="email" placeholder="your.email@example.com" required />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-neutral-700 mb-1">Phone (Optional)</label>
                  <Input id="phone" placeholder="Your phone number" />
                </div>
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-neutral-700 mb-1">Subject</label>
                  <Input id="subject" placeholder="What is this regarding?" required />
                </div>
              </div>
              <div className="mb-6">
                <label htmlFor="message" className="block text-sm font-medium text-neutral-700 mb-1">Message</label>
                <Textarea 
                  id="message" 
                  placeholder="How can we help you?"
                  rows={6}
                  required
                />
              </div>
              <div className="flex justify-end">
                <Button type="submit" className="bg-primary-500 hover:bg-primary-600 text-white font-semibold px-8 py-3">
                  Send Message
                </Button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}