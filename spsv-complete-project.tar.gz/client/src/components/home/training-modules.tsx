import { SPSV_TYPES } from "@/lib/constants";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CarTaxiFront, Car, LucideIcon } from "lucide-react";

type ModuleCardProps = {
  title: string;
  description: string;
  image: string;
  modules: number;
};

const ModuleCard = ({ title, description, image, modules }: ModuleCardProps) => {
  const getColorByTitle = (title: string): string => {
    const colorMap: Record<string, string> = {
      "Taxi Training": "#FFD700", // Gold
      "Hackney Training": "#4682B4", // Steel Blue
      "Limousine Training": "#2E8B57", // Sea Green
      "Wheelchair Accessible Vehicle Training": "#4169E1", // Royal Blue
      "Vehicle Requirements": "#B22222", // Firebrick
      "Test Preparation": "#800080", // Purple
    };
    return colorMap[title] || "#6B8E23"; // Default to olive drab
  };

  const getIconByTitle = (title: string) => {
    if (title.includes("Taxi")) return "🚕";
    if (title.includes("Hackney")) return "🚖";
    if (title.includes("Limousine")) return "🚘";
    if (title.includes("Wheelchair")) return "♿";
    if (title.includes("Vehicle")) return "🔧";
    if (title.includes("Test")) return "📝";
    return "🚗";
  };
  
  return (
    <Card className="overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow">
      <div 
        className="h-48 flex items-center justify-center text-white text-6xl"
        style={{ background: getColorByTitle(title) }}
      >
        <div className="flex flex-col items-center justify-center">
          <span className="text-7xl mb-2">{getIconByTitle(title)}</span>
          <span className="text-xl font-semibold text-center">{title}</span>
        </div>
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-neutral-600 mb-4">{description}</p>
        <div className="flex items-center">
          <span className="text-sm text-neutral-500">{modules} modules</span>
        </div>
      </CardContent>
    </Card>
  );
};

export function TrainingModules() {
  const modules = [
    {
      title: "Taxi Training",
      description: "Comprehensive training for taxi drivers, covering all regulations, area knowledge, and customer service requirements.",
      image: "https://images.rawpixel.com/image_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTA1L3B4NjQwODQyLWltYWdlLWt3dnloOWxvLmpwZw.jpg",
      modules: 12,
    },
    {
      title: "Hackney Training",
      description: "Special focus on pre-booked services, record keeping, and specific hackney regulations for Irish operators.",
      image: "https://images.rawpixel.com/image_800/czNmcy1wcml2YXRlL3Jhd3BpeGVsX2ltYWdlcy93ZWJzaXRlX2NvbnRlbnQvbHIvcHg3MjE3ODYtaW1hZ2Uta3d2eWV2cTguanBn.jpg",
      modules: 10,
    },
    {
      title: "Limousine Training",
      description: "Specialised training for luxury transport services, focusing on premium customer experience and event management.",
      image: "https://images.rawpixel.com/image_800/czNmcy1wcml2YXRlL3Jhd3BpeGVsX2ltYWdlcy93ZWJzaXRlX2NvbnRlbnQvbHIvazYyODUtbXppbmEtMTc3LWpvYjYwOC5qcGc.jpg",
      modules: 8,
    },
    {
      title: "Wheelchair Accessible Vehicle Training",
      description: "Essential training for operating WAVs, including passenger assistance techniques and equipment operation.",
      image: "https://images.rawpixel.com/image_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTA1L2pvYjY4OS0wNzQtdi5qcGc.jpg",
      modules: 14,
    },
    {
      title: "Vehicle Requirements",
      description: "Detailed guidance on vehicle standards, inspection requirements, and maintaining vehicle compliance.",
      image: "https://images.rawpixel.com/image_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIzLTAzL2pvYjk3OS1rYXlrZWUtMDA4LmpwZw.jpg",
      modules: 6,
    },
    {
      title: "Test Preparation",
      description: "Targeted practice tests and guidance specifically designed to help you pass the SPSV driver test.",
      image: "https://images.rawpixel.com/image_800/czNmcy1wcml2YXRlL3Jhd3BpeGVsX2ltYWdlcy93ZWJzaXRlX2NvbnRlbnQvbHIvcGYtczkxLXBtLTU3MDgwLTEuanBn.jpg",
      modules: 15,
    },
  ];

  return (
    <section id="training" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary-500 mb-4">Comprehensive Training Modules</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Our training materials are tailored to each SPSV category and based on the official SPSV manual.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {modules.map((module, index) => (
            <ModuleCard
              key={index}
              title={module.title}
              description={module.description}
              image={module.image}
              modules={module.modules}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
