import { 
  BookOpen, 
  ClipboardCheck, 
  Car, 
  Map, 
  Euro, 
  BrainCircuit 
} from "lucide-react";

type FeatureCardProps = {
  icon: React.ReactNode;
  title: string;
  description: string;
};

function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="bg-gray-50 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="text-primary-500 mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-neutral-600">{description}</p>
    </div>
  );
}

export function FeaturesSection() {
  return (
    <section id="features" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary-500 mb-4">Why Choose SPSV Pro Training?</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Our comprehensive platform helps you navigate the entire SPSV licensing process with ease.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            icon={<BookOpen className="h-10 w-10" />}
            title="Vehicle-Specific Training"
            description="Specialised modules for taxis, hackneys, limousines, and wheelchair accessible vehicles."
          />
          
          <FeatureCard
            icon={<BrainCircuit className="h-10 w-10" />}
            title="Practice Tests"
            description="Realistic practice tests based on the official SPSV manual to ensure you're fully prepared."
          />
          
          <FeatureCard
            icon={<ClipboardCheck className="h-10 w-10" />}
            title="Comprehensive Checklists"
            description="Step-by-step checklists for driver and vehicle licensing requirements."
          />
          
          <FeatureCard
            icon={<Car className="h-10 w-10" />}
            title="NTA Vehicle Finder"
            description="Search and filter NTA-approved vehicles by make and model for your specific SPSV license type."
          />
          
          <FeatureCard
            icon={<Map className="h-10 w-10" />}
            title="Area Knowledge Training"
            description="County-specific training materials covering local routes, landmarks and area knowledge requirements."
          />
          
          <FeatureCard
            icon={<Euro className="h-10 w-10" />}
            title="SPSV Fee Information"
            description="Clear information about licensing fees and renewal costs for all SPSV categories."
          />
        </div>
      </div>
    </section>
  );
}
