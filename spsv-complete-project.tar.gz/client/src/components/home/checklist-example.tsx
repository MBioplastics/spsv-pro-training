import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { Info, Save, FileDown } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

type ChecklistItemProps = {
  id: string;
  title: string;
  description: string;
  tooltipText: string;
};

const ChecklistItem = ({ id, title, description, tooltipText }: ChecklistItemProps) => {
  return (
    <div className="flex items-start p-3 border border-gray-200 rounded-lg bg-gray-50">
      <Checkbox id={id} className="h-5 w-5 mt-0.5" />
      <label htmlFor={id} className="ml-3 flex-1">
        <span className="block text-sm font-medium text-gray-700">{title}</span>
        <span className="block text-sm text-gray-500">{description}</span>
      </label>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Info className="h-5 w-5 text-primary-500 cursor-pointer" />
          </TooltipTrigger>
          <TooltipContent>
            <p className="w-[200px] text-sm">{tooltipText}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
};

export function ChecklistExample() {
  const checklistItems = [
    {
      id: "check1",
      title: "Valid Full Irish/EU/EEA Driving Licence",
      description: "Must be held for a minimum of 2 years",
      tooltipText: "Your driving licence must be in date and valid for the categories of vehicles you intend to drive. It must not have any disqualifications or endorsements that would prevent you from providing SPSV services."
    },
    {
      id: "check2",
      title: "Garda Vetting Application",
      description: "National Vetting Bureau application must be submitted and approved",
      tooltipText: "Garda vetting is required for all SPSV licence applications. This process checks for any criminal convictions or pending prosecutions that could affect your suitability to transport passengers."
    },
    {
      id: "check3",
      title: "Tax Clearance Certificate",
      description: "Up-to-date Revenue Tax Clearance Certificate",
      tooltipText: "You must have current tax clearance from Revenue. This confirms you are compliant with tax obligations. You can apply for tax clearance online through Revenue's ROS system."
    },
    {
      id: "check4",
      title: "SPSV Entry Test Certificate",
      description: "Pass certificate from the NTA SPSV entry test",
      tooltipText: "The SPSV Entry Test assesses your knowledge of the industry, regulations, and area knowledge. You must pass this test before being granted an SPSV driver licence."
    },
    {
      id: "check5",
      title: "Application Fee Payment",
      description: "€250 SPSV driver licence fee",
      tooltipText: "The fee must be paid in full when submitting your application. Payment can be made online through the NTA website or by bank draft/postal order."
    },
    {
      id: "check6",
      title: "Passport-sized Photographs",
      description: "Two recent passport-sized photographs",
      tooltipText: "Photos must be recent (taken within the last 6 months), in color, with a plain white background. They will be used for your driver display card and records."
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary-500 mb-4">Interactive Checklists</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Our comprehensive checklists ensure you don't miss any requirements during the licensing process.
          </p>
        </div>
        
        <Card className="max-w-4xl mx-auto">
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold mb-6 text-primary-500">Driver Licence Requirements Checklist</h3>
            
            <div className="space-y-4">
              {checklistItems.map((item) => (
                <ChecklistItem
                  key={item.id}
                  id={item.id}
                  title={item.title}
                  description={item.description}
                  tooltipText={item.tooltipText}
                />
              ))}
            </div>
            
            <div className="mt-6 flex justify-between">
              <Button className="bg-primary-500 hover:bg-primary-600">
                <Save className="h-4 w-4 mr-1" />
                <span>Save Progress</span>
              </Button>
              <Button className="bg-secondary-500 hover:bg-secondary-600">
                <FileDown className="h-4 w-4 mr-1" />
                <span>Download Checklist</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
