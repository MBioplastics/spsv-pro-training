export function SEOContent() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main SEO Content */}
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            #1 SPSV Training Ireland - Licence Training for Taxi, Hackney & Limousine Licence
          </h2>
          
          <div className="prose prose-lg max-w-none">
            <p className="text-gray-600 mb-6">
              <strong>SPSV Training</strong> excellence starts here. Our comprehensive 
              <strong>licence training</strong> platform covers all <strong>SPSV</strong> requirements 
              for taxi drivers, hackney operators, <strong>limousine licence</strong> holders, and <strong>wheelchair accessible</strong> 
              vehicle operators. Master your <strong>training</strong> with Ireland's #1 platform for Small Public Service Vehicle certification.
            </p>
            
            <h3 className="text-2xl font-semibold text-gray-900 mb-4">
              Why Choose SPSV Pro Training?
            </h3>
            
            <ul className="text-gray-600 mb-8 space-y-2">
              <li>• <strong>SPSV Training Excellence:</strong> Complete SPSV certification preparation</li>
              <li>• <strong>Licence Training Coverage:</strong> All licence training requirements for Ireland</li>
              <li>• <strong>Limousine Licence Training:</strong> Specialised limousine licence training modules</li>
              <li>• <strong>Wheelchair Accessible Training:</strong> Complete wheelchair accessible vehicle certification</li>
              <li>• <strong>County-Specific Training:</strong> Detailed area knowledge for select Irish counties</li>
              <li>• <strong>Interactive SPSV Practice Tests:</strong> Hundreds of SPSV exam questions</li>
              <li>• <strong>Complete Training Documentation:</strong> Never miss a requirement</li>
            </ul>
            
            <h3 className="text-2xl font-semibold text-gray-900 mb-4">
              SPSV Training Coverage Across Ireland
            </h3>
            
            <p className="text-gray-600 mb-6">
              Our platform provides specialized area knowledge training for drivers in Dublin, Cork, Galway, 
              Limerick, Waterford, and other select Irish counties with NTA area knowledge requirements. 
              Whether you're planning to operate in major urban centres or designated areas throughout Ireland, 
              our comprehensive training ensures you're fully prepared for local area knowledge requirements.
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="mb-4">
                  <div className="w-16 h-16 mx-auto bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-2xl">🚕</span>
                  </div>
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-3">SPSV Training</h4>
                <p className="text-gray-600">
                  Complete <strong>SPSV training</strong> certification including 
                  all <strong>licence training</strong> requirements. Master your <strong>training</strong> with 
                  Ireland's leading platform for Small Public Service Vehicle certification.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="mb-4">
                  <div className="w-16 h-16 mx-auto bg-purple-100 rounded-full flex items-center justify-center">
                    <span className="text-2xl">🚗</span>
                  </div>
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-3">Limousine Licence & Training</h4>
                <p className="text-gray-600">
                  Specialised <strong>limousine licence</strong> training for luxury vehicle operators. Complete 
                  <strong>licence training</strong> covering all limousine certification requirements, 
                  premium service standards, and <strong>training</strong> protocols.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="mb-4">
                  <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center">
                    <span className="text-2xl">♿</span>
                  </div>
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-3">Wheelchair Accessible Training</h4>
                <p className="text-gray-600">
                  Comprehensive <strong>wheelchair accessible</strong> vehicle <strong>training</strong>. 
                  Complete certification for <strong>wheelchair accessible</strong> taxi and hackney operations, 
                  including specialised equipment training and accessibility compliance.
                </p>
              </div>
            </div>
            
            <h3 className="text-2xl font-semibold text-gray-900 mb-4">
              SPSV Exam Preparation That Works
            </h3>
            
            <p className="text-gray-600 mb-6">
              Our comprehensive training methodology is designed to help candidates successfully obtain 
              their SPSV certification. With interactive modules, timed practice exams, and detailed 
              feedback on every question, you'll build the confidence and knowledge needed to excel 
              in your SPSV examination.
            </p>
            
            <div className="bg-blue-50 p-6 rounded-lg mb-8">
              <h4 className="text-xl font-semibold text-blue-900 mb-3">
                Start Your SPSV Training Journey Today
              </h4>
              <p className="text-blue-800">
                Join our comprehensive SPSV training platform and start your professional driving career. 
                Get instant access to all training materials, practice tests, and support resources. 
                Your professional driving career in Ireland starts here.
              </p>
            </div>
          </div>
        </div>
        



      </div>
    </section>
  );
}