import { TestData } from "@/components/practice-tests/test-interface";

// Define a type for county-specific area knowledge tests
export type CountyAreaKnowledge = {
  [county: string]: TestData;
};

export const COUNTY_AREA_KNOWLEDGE: CountyAreaKnowledge = {
  // Dublin
  "Dublin": {
    id: 201,
    title: "Dublin Area Knowledge",
    description: "Test your knowledge of Dublin city and county geography, landmarks, routes and traffic patterns.",
    timeLimit: 30,
    questions: [
      {
        id: 1001,
        text: "Which street connects O'Connell Street to Trinity College?",
        options: ["Westmoreland Street", "D'Olier Street", "Abbey Street", "Dame Street"],
        correctAnswer: 0
      },
      {
        id: 1002,
        text: "Which of these routes is most efficient from Dublin Airport to the Convention Centre during morning rush hour?",
        options: [
          "M1 → Port Tunnel → Custom House Quay",
          "M1 → Drumcondra → O'Connell Street → North Wall Quay",
          "M50 → N3 → Chapelizod Bypass → Quays",
          "M50 → Santry → Ballymun Road → City Centre"
        ],
        correctAnswer: 0
      },
      {
        id: 1003,
        text: "Identify the ONE-WAY street in Dublin City Centre:",
        options: ["Kildare Street", "Nassau Street", "Dawson Street", "All of these are one-way"],
        correctAnswer: 3
      },
      {
        id: 1004,
        text: "Which hospital is located on James's Street in Dublin 8?",
        options: ["Mater Hospital", "St. Vincent's Hospital", "St. James's Hospital", "Beaumont Hospital"],
        correctAnswer: 2
      },
      {
        id: 1005,
        text: "What is the name of the main shopping street that runs from St. Stephen's Green to the River Liffey?",
        options: ["O'Connell Street", "Grafton Street", "Henry Street", "Dame Street"],
        correctAnswer: 1
      },
      {
        id: 1006,
        text: "What is the speed limit in the pedestrianised zone of Dublin City Centre?",
        options: ["30 km/h", "50 km/h", "5 km/h", "Vehicles are not permitted"],
        correctAnswer: 3
      },
      {
        id: 1007,
        text: "Which major road forms part of Dublin's inner orbital route?",
        options: ["M50", "N11", "North and South Circular Roads", "East Link Bridge"],
        correctAnswer: 2
      },
      {
        id: 1008,
        text: "During busy periods, which route is recommended from Heuston Station to Dublin Airport?",
        options: [
          "Quays → O'Connell Street → Drumcondra → M1",
          "Chapelizod Bypass → M50 North → M1 South",
          "North Circular Road → Dorset Street → M1",
          "Parkgate Street → Phoenix Park → Navan Road → M50 North"
        ],
        correctAnswer: 1
      },
      {
        id: 1009,
        text: "Where is the main entrance of the Mater Hospital located?",
        options: ["Eccles Street", "North Circular Road", "Dorset Street", "Phibsborough Road"],
        correctAnswer: 0
      },
      {
        id: 1010,
        text: "What bridge connects Bachelor's Walk to Wellington Quay?",
        options: ["Ha'penny Bridge", "O'Connell Bridge", "Sean O'Casey Bridge", "Samuel Beckett Bridge"],
        correctAnswer: 0
      },
      {
        id: 1011,
        text: "Which Dublin suburb is home to Tallaght Hospital?",
        options: ["Clondalkin", "Tallaght", "Blanchardstown", "Lucan"],
        correctAnswer: 1
      },
      {
        id: 1012,
        text: "What is the name of the road that runs alongside Trinity College on its western side?",
        options: ["Pearse Street", "Nassau Street", "Dame Street", "College Green"],
        correctAnswer: 1
      },
      {
        id: 1013,
        text: "Which of these locations has taxi rank facilities?",
        options: ["Dublin Airport Terminal 1", "St. Stephen's Green North", "Outside Connolly Station", "All of these options"],
        correctAnswer: 3
      },
      {
        id: 1014,
        text: "Which road would you take to access the Dublin Port Tunnel from the city centre?",
        options: ["North Wall Quay", "Sheriff Street Upper", "East Wall Road", "Sean Moore Road"],
        correctAnswer: 2
      },
      {
        id: 1015,
        text: "Where is Croke Park stadium located?",
        options: ["North Dublin, near Drumcondra", "South Dublin, near Ranelagh", "West Dublin, near Blanchardstown", "East Dublin, near Clontarf"],
        correctAnswer: 0
      },
      {
        id: 1016,
        text: "What motorway connects Dublin to Belfast?",
        options: ["M1", "M50", "M11", "N2"],
        correctAnswer: 0
      },
      {
        id: 1017,
        text: "Which DART station serves Dun Laoghaire?",
        options: ["Blackrock", "Dun Laoghaire", "Dalkey", "Sandycove"],
        correctAnswer: 1
      },
      {
        id: 1018,
        text: "What bus route number serves Dublin Airport to City Centre?",
        options: ["747", "16", "41", "145"],
        correctAnswer: 0
      },
      {
        id: 1019,
        text: "What major roundabout is located where the N11 meets the R138?",
        options: ["Red Cow Roundabout", "Doyle's Corner", "UCD Interchange", "Stillorgan Roundabout"],
        correctAnswer: 3
      },
      {
        id: 1020,
        text: "Which Dublin shopping centre is located in Tallaght?",
        options: ["Dundrum Town Centre", "Liffey Valley", "The Square", "Blanchardstown Centre"],
        correctAnswer: 2
      },
      {
        id: 1021,
        text: "What street in Dublin is known as a one-way system with multiple nightclubs and late venues?",
        options: ["Harcourt Street", "Camden Street", "Leeson Street", "South William Street"],
        correctAnswer: 0
      },
      {
        id: 1022,
        text: "The Samuel Beckett Bridge connects which two areas of Dublin?",
        options: [
          "North Wall Quay and Sir John Rogerson's Quay",
          "Ringsend and East Wall",
          "Ballsbridge and Sandymount",
          "Docklands and IFSC"
        ],
        correctAnswer: 0
      },
      {
        id: 1023,
        text: "Where is the main entrance to St. Vincent's University Hospital?",
        options: ["Merrion Road", "Nutley Lane", "Stillorgan Road", "Mount Merrion Avenue"],
        correctAnswer: 1
      },
      {
        id: 1024,
        text: "Which road would you use to access the M50 from Dundrum?",
        options: ["Sandyford Road", "Wyckham Way", "Balally Drive", "Churchtown Road"],
        correctAnswer: 1
      }
    ]
  },
  
  // Cork
  "Cork": {
    id: 202,
    title: "Cork Area Knowledge",
    description: "Test your knowledge of Cork city and county geography, landmarks, routes and traffic patterns.",
    timeLimit: 30,
    questions: [
      {
        id: 2001,
        text: "Which bridge connects St. Patrick's Street with Merchant's Quay in Cork City?",
        options: ["St. Patrick's Bridge", "Brian Boru Bridge", "Michael Collins Bridge", "Parliament Bridge"],
        correctAnswer: 0
      },
      {
        id: 2002,
        text: "Which of these routes is most efficient to travel from Cork Airport to Cork City Centre?",
        options: [
          "N27 → South Link Road → Eglinton Street",
          "N27 → Douglas → South Douglas Road → City Centre",
          "N27 → Kinsale Road → Turners Cross → City Centre",
          "N40 → Wilton → Western Road → City Centre"
        ],
        correctAnswer: 0
      },
      {
        id: 2003,
        text: "Where is Cork University Hospital located?",
        options: ["Wilton", "Blackrock", "Douglas", "Ballincollig"],
        correctAnswer: 0
      },
      {
        id: 2004,
        text: "What is the name of Cork's main shopping street?",
        options: ["Oliver Plunkett Street", "Patrick Street", "Grand Parade", "Washington Street"],
        correctAnswer: 1
      },
      {
        id: 2005,
        text: "Which of the following is a ONE-WAY street in Cork City Centre?",
        options: ["MacCurtain Street", "South Mall", "Oliver Plunkett Street", "Western Road"],
        correctAnswer: 2
      },
      {
        id: 2006,
        text: "What landmark is located at the eastern end of St. Patrick's Street?",
        options: ["The English Market", "Cork Opera House", "Brown Thomas", "St. Patrick's Bridge"],
        correctAnswer: 3
      },
      {
        id: 2007,
        text: "Which road would you take to access the N40 South Ring Road from Cork City Centre?",
        options: ["South Link Road", "Sarsfield Road", "Douglas Road", "Ballincollig Bypass"],
        correctAnswer: 0
      },
      {
        id: 2008,
        text: "In which area of Cork is Páirc Uí Chaoimh stadium located?",
        options: ["Blackrock", "Bishopstown", "Ballintemple", "Mayfield"],
        correctAnswer: 2
      },
      {
        id: 2009,
        text: "What is the shortest route from Kent Railway Station to Cork Bus Station?",
        options: [
          "Lower Glanmire Road → Parnell Place",
          "Alfred Street → MacCurtain Street → St. Patrick's Quay → Merchants Quay",
          "Horgan's Quay → Brian Boru Bridge → Merchants Quay",
          "Railway Street → MacCurtain Street → St. Patrick's Quay"
        ],
        correctAnswer: 2
      },
      {
        id: 2010,
        text: "Which of these Cork suburban areas is located north of the River Lee?",
        options: ["Douglas", "Ballincollig", "Blackrock", "Blackpool"],
        correctAnswer: 3
      },
      {
        id: 2011,
        text: "Which major shopping centre is located in Ballincollig?",
        options: ["Mahon Point Shopping Centre", "Douglas Village Shopping Centre", "Ballincollig Shopping Centre", "Wilton Shopping Centre"],
        correctAnswer: 2
      },
      {
        id: 2012,
        text: "Where is the main entrance of the Mercy University Hospital located?",
        options: ["Grenville Place", "Henry Street", "Washington Street", "Grand Parade"],
        correctAnswer: 0
      },
      {
        id: 2013,
        text: "Which road connects Cork to Limerick?",
        options: ["N20", "N25", "N22", "N28"],
        correctAnswer: 0
      },
      {
        id: 2014,
        text: "What is the name of the shopping centre located in Mahon?",
        options: ["Mahon Point", "Douglas Court", "Merchant's Quay", "City Gate"],
        correctAnswer: 0
      },
      {
        id: 2015,
        text: "Where is University College Cork (UCC) located?",
        options: ["Western Road", "College Road", "Gillabbey Street", "All of these options"],
        correctAnswer: 3
      },
      {
        id: 2016,
        text: "Which bridge in Cork is known for its distinctive 'Shakey' nickname?",
        options: ["Brian Boru Bridge", "Michael Collins Bridge", "Christy Ring Bridge", "Daly's Bridge"],
        correctAnswer: 3
      },
      {
        id: 2017,
        text: "What is the name of the tunnel that runs under the River Lee in Cork?",
        options: ["Jack Lynch Tunnel", "Blackrock Tunnel", "Lee Tunnel", "Patrick's Tunnel"],
        correctAnswer: 0
      },
      {
        id: 2018,
        text: "Where is the English Market located in Cork City?",
        options: ["Between Grand Parade and Princes Street", "On Patrick Street", "On Oliver Plunkett Street", "On North Main Street"],
        correctAnswer: 0
      },
      {
        id: 2019,
        text: "Which Cork suburb is home to Cork Airport?",
        options: ["Douglas", "Rochestown", "Frankfield", "Ballygarvan"],
        correctAnswer: 3
      },
      {
        id: 2020,
        text: "Where in Cork would you find Neptune Stadium?",
        options: ["Blackpool", "Gurranabraher", "Ballintemple", "Blackrock"],
        correctAnswer: 0
      }
    ]
  },
  
  // Galway
  "Galway": {
    id: 203,
    title: "Galway Area Knowledge",
    description: "Test your knowledge of Galway city and county geography, landmarks, routes and traffic patterns.",
    timeLimit: 30,
    questions: [
      {
        id: 3001,
        text: "What is the name of the main pedestrianised shopping street in Galway City?",
        options: ["Shop Street", "High Street", "Quay Street", "Eyre Square"],
        correctAnswer: 0
      },
      {
        id: 3002,
        text: "Which bridge connects the Claddagh area to the Spanish Arch?",
        options: ["O'Brien's Bridge", "Wolfe Tone Bridge", "Salmon Weir Bridge", "William O'Brien Bridge"],
        correctAnswer: 1
      },
      {
        id: 3003,
        text: "Where is Galway University Hospital located?",
        options: ["Newcastle", "Salthill", "Renmore", "Knocknacarra"],
        correctAnswer: 0
      },
      {
        id: 3004,
        text: "Which road connects Galway to Dublin?",
        options: ["N6", "N17", "M6", "N59"],
        correctAnswer: 2
      },
      {
        id: 3005,
        text: "What is the name of the square at the heart of Galway City?",
        options: ["Eyre Square", "Kennedy Square", "Spanish Parade", "St. Nicholas' Square"],
        correctAnswer: 0
      },
      {
        id: 3006,
        text: "Which of these Galway locations has an official taxi rank?",
        options: ["Eyre Square", "Shop Street", "Spanish Arch", "All of these options"],
        correctAnswer: 0
      },
      {
        id: 3007,
        text: "In which direction is Salthill from Galway City Centre?",
        options: ["East", "West", "North", "South"],
        correctAnswer: 1
      },
      {
        id: 3008,
        text: "Which bridge in Galway is known for its views of the Salmon Weir?",
        options: ["O'Brien's Bridge", "Wolfe Tone Bridge", "Salmon Weir Bridge", "William O'Brien Bridge"],
        correctAnswer: 2
      },
      {
        id: 3009,
        text: "Where is NUI Galway's main campus located?",
        options: ["Newcastle", "Salthill", "Renmore", "Terryland"],
        correctAnswer: 0
      },
      {
        id: 3010,
        text: "What is the name of the main road through Salthill?",
        options: ["Salthill Promenade", "Threadneedle Road", "Dalysfort Road", "Upper Salthill Road"],
        correctAnswer: 0
      },
      {
        id: 3011,
        text: "Which of these is a ONE-WAY street in Galway City?",
        options: ["Shop Street", "Cross Street", "High Street", "All of these options"],
        correctAnswer: 3
      },
      {
        id: 3012,
        text: "What large shopping centre is located at Headford Road?",
        options: ["Galway Shopping Centre", "Eyre Square Centre", "Galway Retail Park", "Terryland Retail Park"],
        correctAnswer: 0
      },
      {
        id: 3013,
        text: "Which road would you take from Galway City to Connemara?",
        options: ["N59", "N17", "N84", "N6"],
        correctAnswer: 0
      },
      {
        id: 3014,
        text: "Where is the main bus station in Galway located?",
        options: ["Eyre Square", "Fairgreen Road", "Merchants Road", "College Road"],
        correctAnswer: 0
      },
      {
        id: 3015,
        text: "Which suburb of Galway is located to the west of Salthill?",
        options: ["Knocknacarra", "Renmore", "Oranmore", "Menlo"],
        correctAnswer: 0
      }
    ]
  },
  
  // Limerick
  "Limerick": {
    id: 204,
    title: "Limerick Area Knowledge",
    description: "Test your knowledge of Limerick city and county geography, landmarks, routes and traffic patterns.",
    timeLimit: 30,
    questions: [
      {
        id: 4001,
        text: "What is the name of the main shopping street in Limerick City?",
        options: ["O'Connell Street", "William Street", "Henry Street", "Patrick Street"],
        correctAnswer: 0
      },
      {
        id: 4002,
        text: "Which bridge crosses the River Shannon in the city centre?",
        options: ["Sarsfield Bridge", "Thomond Bridge", "Shannon Bridge", "Abbey Bridge"],
        correctAnswer: 0
      },
      {
        id: 4003,
        text: "Where is University Hospital Limerick located?",
        options: ["Dooradoyle", "Castletroy", "Raheen", "City Centre"],
        correctAnswer: 0
      },
      {
        id: 4004,
        text: "Which road connects Limerick to Dublin?",
        options: ["M7", "N18", "N20", "N69"],
        correctAnswer: 0
      },
      {
        id: 4005,
        text: "Where is the University of Limerick located?",
        options: ["Castletroy", "Dooradoyle", "Raheen", "Caherdavin"],
        correctAnswer: 0
      },
      {
        id: 4006,
        text: "What is the name of the shopping centre located in Dooradoyle?",
        options: ["Crescent Shopping Centre", "Parkway Shopping Centre", "Arthur's Quay", "Jetland Shopping Centre"],
        correctAnswer: 0
      },
      {
        id: 4007,
        text: "Which is the main taxi rank location in Limerick City?",
        options: ["O'Connell Street", "William Street", "Henry Street", "Cruises Street"],
        correctAnswer: 0
      },
      {
        id: 4008,
        text: "Where is Thomond Park stadium located?",
        options: ["Ballynanty", "Dooradoyle", "Castletroy", "Rhebogue"],
        correctAnswer: 0
      },
      {
        id: 4009,
        text: "What major road forms the southern ring road around Limerick?",
        options: ["N18", "M7", "N20", "N69"],
        correctAnswer: 0
      },
      {
        id: 4010,
        text: "Which bridge connects Clare Street to Corbally?",
        options: ["Athlunkard Bridge", "Thomond Bridge", "Sarsfield Bridge", "Shannon Bridge"],
        correctAnswer: 0
      },
      {
        id: 4011,
        text: "Where is Colbert Station (Limerick's main train and bus station) located?",
        options: ["Parnell Street", "Henry Street", "O'Connell Street", "Mallow Street"],
        correctAnswer: 0
      },
      {
        id: 4012,
        text: "Which of these is a ONE-WAY street in Limerick City Centre?",
        options: ["O'Connell Street", "Henry Street", "William Street", "All of these options"],
        correctAnswer: 2
      },
      {
        id: 4013,
        text: "Where is St. John's Hospital located?",
        options: ["John's Square", "Dooradoyle", "Ennis Road", "Henry Street"],
        correctAnswer: 0
      },
      {
        id: 4014,
        text: "What is the fastest route from Shannon Airport to Limerick City Centre?",
        options: ["N18 → Limerick Tunnel → City Centre", "N18 → Ennis Road → City Centre", "N18 → Coonagh Roundabout → Condell Road", "N18 → M7 → Dublin Road"],
        correctAnswer: 0
      },
      {
        id: 4015,
        text: "Where is the Gaelic Grounds stadium located?",
        options: ["Ennis Road", "Childers Road", "South Circular Road", "North Circular Road"],
        correctAnswer: 0
      }
    ]
  },

  // Waterford
  "Waterford": {
    id: 205,
    title: "Waterford Area Knowledge",
    description: "Test your knowledge of Waterford city and county geography, landmarks, routes and traffic patterns.",
    timeLimit: 30,
    questions: [
      {
        id: 5001,
        text: "What is the name of the main shopping street in Waterford City?",
        options: ["Barronstrand Street", "Michael Street", "The Quay", "John Street"],
        correctAnswer: 0
      },
      {
        id: 5002,
        text: "Which bridge connects Waterford City to Ferrybank?",
        options: ["Rice Bridge", "Thomas Francis Meagher Bridge", "Edmund Rice Bridge", "Redmond Bridge"],
        correctAnswer: 0
      },
      {
        id: 5003,
        text: "Where is University Hospital Waterford located?",
        options: ["Dunmore Road", "Cork Road", "The Quay", "Newtown Road"],
        correctAnswer: 1
      },
      {
        id: 5004,
        text: "Which road connects Waterford to Dublin?",
        options: ["M9", "N24", "N25", "N29"],
        correctAnswer: 0
      },
      {
        id: 5005,
        text: "Where is Waterford Institute of Technology located?",
        options: ["Cork Road", "Dunmore Road", "Parnell Street", "The Quay"],
        correctAnswer: 0
      },
      {
        id: 5006,
        text: "What is the name of the shopping centre on Patrick Street?",
        options: ["City Square Shopping Centre", "Waterford Shopping Centre", "Lisduggan Shopping Centre", "Ardkeen Shopping Centre"],
        correctAnswer: 0
      },
      {
        id: 5007,
        text: "Which of these is a ONE-WAY street in Waterford City Centre?",
        options: ["The Quay", "Barronstrand Street", "Michael Street", "All of these options"],
        correctAnswer: 1
      },
      {
        id: 5008,
        text: "Where is the main taxi rank in Waterford City Centre?",
        options: ["John Roberts Square", "The Quay", "Barronstrand Street", "All of these options"],
        correctAnswer: 0
      },
      {
        id: 5009,
        text: "Where is the main bus station in Waterford located?",
        options: ["The Quay", "Parnell Street", "Merchant's Quay", "Railway Square"],
        correctAnswer: 0
      },
      {
        id: 5010,
        text: "What is the name of the bypass road around Waterford City?",
        options: ["Waterford Outer Ring Road", "Waterford City Bypass", "N25 Bypass", "Waterford Ring Road"],
        correctAnswer: 0
      }
    ]
  },
  
  // Default entry for other counties
  "Other Counties": {
    id: 299,
    title: "General Area Knowledge",
    description: "Test your knowledge of general Irish geography and navigation skills.",
    timeLimit: 30,
    questions: [
      {
        id: 9001,
        text: "Which motorway connects Dublin to Belfast?",
        options: ["M1", "M2", "M50", "N2"],
        correctAnswer: 0
      },
      {
        id: 9002,
        text: "What is the primary road number that connects Dublin to Cork?",
        options: ["N7/M7 and M8", "N11/M11", "N3/M3", "N81"],
        correctAnswer: 0
      },
      {
        id: 9003,
        text: "Which Irish county is known as 'The Kingdom'?",
        options: ["Cork", "Kerry", "Galway", "Mayo"],
        correctAnswer: 1
      },
      {
        id: 9004,
        text: "Which county is NOT part of the province of Leinster?",
        options: ["Meath", "Westmeath", "Clare", "Kilkenny"],
        correctAnswer: 2
      },
      {
        id: 9005,
        text: "Which road would you take from Dublin to Galway?",
        options: ["M4/M6", "M7/M8", "N81", "M1"],
        correctAnswer: 0
      },
      {
        id: 9006,
        text: "What is the longest river in Ireland?",
        options: ["River Liffey", "River Shannon", "River Lee", "River Boyne"],
        correctAnswer: 1
      },
      {
        id: 9007,
        text: "Which county is located on the northern-most tip of the Republic of Ireland?",
        options: ["Donegal", "Mayo", "Sligo", "Leitrim"],
        correctAnswer: 0
      },
      {
        id: 9008,
        text: "In which county is Knock Airport located?",
        options: ["Sligo", "Galway", "Mayo", "Roscommon"],
        correctAnswer: 2
      },
      {
        id: 9009,
        text: "Which of these is NOT a county in the Republic of Ireland?",
        options: ["Fermanagh", "Kildare", "Wexford", "Carlow"],
        correctAnswer: 0
      },
      {
        id: 9010,
        text: "Which Irish city is known as the 'Marble City'?",
        options: ["Waterford", "Kilkenny", "Galway", "Cork"],
        correctAnswer: 1
      }
    ]
  }
};

// County list in Ireland
export const COUNTIES = [
  "Carlow",
  "Cavan",
  "Clare",
  "Cork",
  "Donegal",
  "Dublin",
  "Galway",
  "Kerry",
  "Kildare",
  "Kilkenny",
  "Laois",
  "Leitrim",
  "Limerick",
  "Longford",
  "Louth",
  "Mayo",
  "Meath",
  "Monaghan",
  "Offaly",
  "Roscommon",
  "Sligo",
  "Tipperary",
  "Waterford",
  "Westmeath",
  "Wexford",
  "Wicklow"
];