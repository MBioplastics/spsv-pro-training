import { TestData } from "@/components/practice-tests/test-interface";

export const INDUSTRY_KNOWLEDGE_TEST: TestData = {
  id: 1,
  title: "Industry Knowledge Test",
  description: "Test your knowledge about the SPSV industry regulations and standards - reflects the actual exam with 40 questions",
  timeLimit: 45,
  questions: [
    {
      id: 1,
      text: "What organisation is responsible for regulating the SPSV industry in Ireland?",
      options: [
        "Road Safety Authority (RSA)",
        "National Transport Authority (NTA)",
        "Department of Transport, Tourism and Sport",
        "An Garda Síochána"
      ],
      correctAnswer: 1
    },
    {
      id: 2,
      text: "How many types of SPSV licences are available in Ireland?",
      options: [
        "Three",
        "Four",
        "Six",
        "Eight"
      ],
      correctAnswer: 2
    },
    {
      id: 3,
      text: "Which of the following SPSV types can pick up passengers on the street without pre-booking?",
      options: [
        "Hackney",
        "Limousine",
        "Taxi",
        "Local Area Hackney"
      ],
      correctAnswer: 2
    },
    {
      id: 4,
      text: "What is the maximum age of a vehicle for it to be eligible for a new SPSV licence?",
      options: [
        "5 years",
        "7 years",
        "9 years",
        "10 years"
      ],
      correctAnswer: 3
    },
    {
      id: 5,
      text: "Which document must be displayed on the windscreen of an SPSV at all times when operating?",
      options: [
        "Vehicle registration certificate",
        "SPSV vehicle licence disc",
        "Insurance certificate",
        "Driver's identification card"
      ],
      correctAnswer: 1
    },
    {
      id: 6,
      text: "How often must an SPSV undergo a National Car Test (NCT)?",
      options: [
        "Every 6 months",
        "Annually",
        "Every 2 years",
        "Every 3 years"
      ],
      correctAnswer: 1
    },
    {
      id: 7,
      text: "What is required for all taxi operators since 2019 regarding payment methods?",
      options: [
        "They must offer contactless payment only",
        "They must accept card payments",
        "They must use a digital receipt system",
        "They must provide a QR code for payment"
      ],
      correctAnswer: 1
    },
    {
      id: 8,
      text: "What is the validity period of an SPSV driver licence?",
      options: [
        "1 year",
        "3 years",
        "5 years",
        "10 years"
      ],
      correctAnswer: 2
    },
    {
      id: 9,
      text: "Which of the following is NOT a requirement for obtaining an SPSV driver licence?",
      options: [
        "Holding a full driving licence",
        "Passing the SPSV Entry Test",
        "Having a university degree",
        "Passing Garda vetting"
      ],
      correctAnswer: 2
    },
    {
      id: 10,
      text: "Which type of SPSV must give priority to wheelchair users when operating at a taxi rank?",
      options: [
        "Standard Taxi",
        "Wheelchair Accessible Taxi (WAT)",
        "Wheelchair Accessible Hackney (WAH)",
        "Limousine"
      ],
      correctAnswer: 1
    },
    {
      id: 11,
      text: "What is the main difference between a hackney and a taxi?",
      options: [
        "The color of the vehicle",
        "The number of passengers it can carry",
        "A hackney cannot ply for hire on the street or use taxi ranks",
        "A hackney does not require a driver licence"
      ],
      correctAnswer: 2
    },
    {
      id: 12,
      text: "How often must a taximeter be verified by the Legal Metrology Service?",
      options: [
        "Every 3 months",
        "Every 6 months",
        "Annually",
        "Every 2 years"
      ],
      correctAnswer: 2
    },
    {
      id: 13,
      text: "When must the fare for a hackney journey be agreed?",
      options: [
        "At the end of the journey",
        "Before the journey begins",
        "When the journey is half completed",
        "It's not necessary to agree on the fare"
      ],
      correctAnswer: 1
    },
    {
      id: 14,
      text: "Which document specifies the maximum rates that can be charged for taxi journeys?",
      options: [
        "SPSV Regulations 2015",
        "National Maximum Taxi Fare",
        "Taxi Fare Guidelines",
        "SPSV Driver Handbook"
      ],
      correctAnswer: 1
    },
    {
      id: 15,
      text: "What is the purpose of the SPSV Industry Information Guide?",
      options: [
        "To provide tax advice for SPSV operators",
        "To inform the public about taxi fares",
        "To help operators understand their obligations under SPSV regulations",
        "To promote tourism in Ireland"
      ],
      correctAnswer: 2
    }
  ]
};

export const AREA_KNOWLEDGE_TEST: TestData = {
  id: 2,
  title: "Area Knowledge Test",
  description: "Demonstrate your knowledge of routes, landmarks and locations - reflects the actual exam with 30 questions",
  timeLimit: 35,
  questions: [
    {
      id: 1,
      text: "What should a driver know about drop-off points at major hospitals?",
      options: [
        "Only the postal address",
        "Only the general area of the city where it's located",
        "The exact location of main entrances, emergency departments, and outpatient clinics",
        "Only the GPS coordinates"
      ],
      correctAnswer: 2
    },
    {
      id: 2,
      text: "When a passenger asks to be taken to a well-known hotel, what information should you know?",
      options: [
        "Just the general area of the hotel",
        "The location, best approach routes, and appropriate drop-off points",
        "Only the hotel star rating",
        "Just the hotel chain it belongs to"
      ],
      correctAnswer: 1
    },
    {
      id: 3,
      text: "What is the most important consideration when planning a route during rush hour?",
      options: [
        "The shortest distance route",
        "The route that passes the most landmarks",
        "Alternative routes that avoid known bottlenecks",
        "The route with the most traffic lights"
      ],
      correctAnswer: 2
    },
    {
      id: 4,
      text: "In Dublin, what type of street pattern is commonly found in older areas of the city?",
      options: [
        "Grid system",
        "Radial pattern with connecting ring roads",
        "Organic/medieval layout with irregular street patterns",
        "Linear development along a single main road"
      ],
      correctAnswer: 2
    },
    {
      id: 5,
      text: "When a passenger requests to go to Dublin Airport, what additional information should you confirm?",
      options: [
        "Their flight number only",
        "Whether they need Terminal 1 or Terminal 2",
        "If they want to see the control tower",
        "The airline's history"
      ],
      correctAnswer: 1
    },
    {
      id: 6,
      text: "What is typically the best approach when a passenger asks for the quickest route?",
      options: [
        "Always take motorways",
        "Consider current traffic conditions and time of day",
        "Follow GPS directions only",
        "Take the route with the most traffic lights"
      ],
      correctAnswer: 1
    },
    {
      id: 7,
      text: "What information should an SPSV driver know about one-way systems?",
      options: [
        "Only those in the city center",
        "Only those on main roads",
        "All major one-way systems in their operating area",
        "None, as GPS will provide that information"
      ],
      correctAnswer: 2
    },
    {
      id: 8,
      text: "When approaching a busy venue like a stadium after an event, what is the best practice?",
      options: [
        "Drop the passenger wherever they ask",
        "Know the designated pick-up and drop-off points",
        "Avoid the area completely",
        "Call the venue for instructions"
      ],
      correctAnswer: 1
    },
    {
      id: 9,
      text: "How should an SPSV driver respond when asked about the location of a lesser-known attraction?",
      options: [
        "Suggest a more popular attraction instead",
        "Admit lack of knowledge but offer to use GPS",
        "Pretend to know and then drive around",
        "Ask the passenger to provide directions"
      ],
      correctAnswer: 1
    },
    {
      id: 10,
      text: "When taking a passenger to a rural destination, what should you be particularly aware of?",
      options: [
        "That townland names may be used instead of street addresses",
        "That rural areas don't have place names",
        "That all rural areas have grid-pattern roads",
        "That rural destinations don't require specific knowledge"
      ],
      correctAnswer: 0
    }
  ]
};

export const CUSTOMER_SERVICE_TEST: TestData = {
  id: 3,
  title: "Customer Service Test",
  description: "Test your knowledge of best practices for customer satisfaction - reflects the actual exam with 25 questions",
  timeLimit: 30,
  questions: [
    {
      id: 1,
      text: "What is the best approach when a passenger with a visual impairment enters your vehicle?",
      options: [
        "Ask if they need assistance and how you can best help them",
        "Immediately grab their arm to guide them",
        "Speak very loudly so they can hear you better",
        "Avoid conversation as they need to concentrate"
      ],
      correctAnswer: 0
    },
    {
      id: 2,
      text: "How should you handle a situation where a passenger disputes the fare?",
      options: [
        "Immediately call the Gardaí",
        "Raise your voice to establish authority",
        "Remain calm, explain the fare calculation, and provide documentation",
        "Offer a discount to avoid confrontation"
      ],
      correctAnswer: 2
    },
    {
      id: 3,
      text: "What should you do if a passenger leaves an item in your vehicle?",
      options: [
        "Keep it as a tip",
        "Throw it away if it appears worthless",
        "Make reasonable attempts to return it to the owner",
        "Sell it if no one claims it within a day"
      ],
      correctAnswer: 2
    },
    {
      id: 4,
      text: "How should guide dogs be accommodated in SPSVs?",
      options: [
        "They must be refused due to hygiene concerns",
        "They must be accepted in all SPSVs",
        "They can be accepted if the driver agrees",
        "They must be muzzled before entering"
      ],
      correctAnswer: 1
    },
    {
      id: 5,
      text: "What is the most professional way to handle a passenger who is intoxicated but not aggressive?",
      options: [
        "Refuse service in all cases",
        "Mock their condition to entertain other passengers",
        "Assess whether they can be transported safely and potentially ask for fare payment in advance",
        "Drive very quickly to get them out of your vehicle"
      ],
      correctAnswer: 2
    },
    {
      id: 6,
      text: "What is the correct approach when communicating with passengers with hearing impairments?",
      options: [
        "Avoid communication entirely",
        "Speak normally but ensure they can see your face for lip reading",
        "Shout as loudly as possible",
        "Use exaggerated hand gestures only"
      ],
      correctAnswer: 1
    },
    {
      id: 7,
      text: "How should you respond when a passenger asks for your opinion on a political issue?",
      options: [
        "Give your honest opinion no matter how controversial",
        "Try to convert them to your viewpoint",
        "Remain professional and neutral or politely change the subject",
        "Pretend you don't speak English"
      ],
      correctAnswer: 2
    },
    {
      id: 8,
      text: "What is the best approach to handling a passenger who is in a hurry?",
      options: [
        "Drive as fast as possible, ignoring speed limits",
        "Tell them they should have left earlier",
        "Explain the estimated journey time and take the most efficient route",
        "Suggest they find another taxi"
      ],
      correctAnswer: 2
    },
    {
      id: 9,
      text: "What should you do if a passenger becomes aggressive?",
      options: [
        "Become aggressive in return to show dominance",
        "Continue the journey no matter what",
        "Stay calm, pull over safely if necessary, and call for assistance if needed",
        "Speed up to get to the destination faster"
      ],
      correctAnswer: 2
    },
    {
      id: 10,
      text: "How should you handle a situation where a passenger wants to eat in your vehicle?",
      options: [
        "Automatically refuse all food and drink",
        "Politely explain your policy regarding food in the vehicle",
        "Charge an additional cleaning fee up front",
        "Ignore it completely"
      ],
      correctAnswer: 1
    }
  ]
};

export const MOCK_EXAM: TestData = {
  id: 4,
  title: "Full Mock Exam",
  description: "Complete practice test simulating the actual SPSV driver entry test - includes all 80 questions (40 Industry, 30 Area, 10 Customer Service)",
  timeLimit: 105,
  questions: [
    // Industry Knowledge
    {
      id: 1,
      text: "What organisation is responsible for regulating the SPSV industry in Ireland?",
      options: [
        "Road Safety Authority (RSA)",
        "National Transport Authority (NTA)",
        "Department of Transport, Tourism and Sport",
        "An Garda Síochána"
      ],
      correctAnswer: 1
    },
    {
      id: 2,
      text: "What is the validity period of an SPSV driver licence?",
      options: [
        "1 year",
        "3 years",
        "5 years",
        "10 years"
      ],
      correctAnswer: 2
    },
    {
      id: 3,
      text: "Which SPSV type cannot stand for hire at taxi ranks?",
      options: [
        "Standard taxi",
        "Wheelchair accessible taxi",
        "Hackney",
        "None of the above"
      ],
      correctAnswer: 2
    },
    {
      id: 4,
      text: "What must all taxi drivers accept as a method of payment?",
      options: [
        "Cash only",
        "Credit and debit cards",
        "App-based payments only",
        "Bank transfers only"
      ],
      correctAnswer: 1
    },
    {
      id: 5,
      text: "When must a hackney operator agree on the fare with the passenger?",
      options: [
        "Before the journey begins",
        "During the journey",
        "After the journey",
        "Any time is acceptable"
      ],
      correctAnswer: 0
    },
    {
      id: 6,
      text: "Which document must be prominently displayed in the vehicle when operating as an SPSV?",
      options: [
        "Vehicle registration certificate",
        "SPSV driver identification",
        "Insurance certificate",
        "NCT certificate"
      ],
      correctAnswer: 1
    },
    {
      id: 7,
      text: "What is the maximum age limit for a vehicle to be eligible for a new SPSV licence?",
      options: [
        "5 years",
        "7 years",
        "9 years",
        "10 years"
      ],
      correctAnswer: 3
    },
    {
      id: 8,
      text: "What happens if an SPSV vehicle licence expires?",
      options: [
        "A fine is issued but the vehicle can still operate",
        "The vehicle can no longer legally operate as an SPSV",
        "There is a 30-day grace period",
        "The licence automatically renews"
      ],
      correctAnswer: 1
    },
    {
      id: 9,
      text: "What is a Local Area Hackney licence specifically designed for?",
      options: [
        "Urban areas with high tourism",
        "Airport transfers only",
        "Rural areas with limited or no existing SPSV service",
        "School transport only"
      ],
      correctAnswer: 2
    },
    {
      id: 10,
      text: "How often must a taximeter be verified and sealed?",
      options: [
        "Monthly",
        "Quarterly",
        "Annually",
        "Every two years"
      ],
      correctAnswer: 2
    },
    
    // Area Knowledge
    {
      id: 11,
      text: "What information should an SPSV driver know about major hospitals?",
      options: [
        "Only their general location",
        "Only their contact details",
        "Their exact location, main entrances, and approach routes",
        "Only their visiting hours"
      ],
      correctAnswer: 2
    },
    {
      id: 12,
      text: "What should an SPSV driver know about one-way street systems?",
      options: [
        "Nothing special as GPS will guide them",
        "All major one-way systems in their operating area",
        "Only those in city centers",
        "Only those on motorways"
      ],
      correctAnswer: 1
    },
    {
      id: 13,
      text: "When a passenger asks to be taken to a hotel, what information should you already know?",
      options: [
        "The hotel's star rating",
        "The hotel's room rates",
        "The hotel's location and best approach routes",
        "The hotel's history"
      ],
      correctAnswer: 2
    },
    {
      id: 14,
      text: "What should an SPSV driver know about major shopping centers?",
      options: [
        "The names of all shops within them",
        "Their location, entry points, and drop-off areas",
        "Their opening and closing times only",
        "The best bargains available"
      ],
      correctAnswer: 1
    },
    {
      id: 15,
      text: "What is most important to know about roads with seasonal variations in traffic?",
      options: [
        "Their construction material",
        "Their width",
        "Alternative routes during busy periods",
        "Their age"
      ],
      correctAnswer: 2
    },
    
    // Customer Service
    {
      id: 16,
      text: "What is the best approach when assisting a passenger who uses a wheelchair?",
      options: [
        "Assume they need help with everything",
        "Ask if and how they would like assistance",
        "Avoid offering any help unless they look like they're struggling",
        "Tell them to wait for someone else to help them"
      ],
      correctAnswer: 1
    },
    {
      id: 17,
      text: "How should you handle a situation where a passenger disputes the fare?",
      options: [
        "Immediately call the Gardaí",
        "Argue loudly to establish your authority",
        "Remain calm, explain the fare calculation, and provide documentation",
        "Refuse to let them exit the vehicle until they pay"
      ],
      correctAnswer: 2
    },
    {
      id: 18,
      text: "What should you do if your card payment terminal isn't working?",
      options: [
        "Demand cash payment only",
        "Tell the passenger it's their problem",
        "Explain the situation and suggest alternatives like finding an ATM",
        "Offer the ride for free"
      ],
      correctAnswer: 2
    },
    {
      id: 19,
      text: "How should you respond when a passenger is running late for an important appointment?",
      options: [
        "Break speed limits to get them there faster",
        "Tell them they should have left earlier",
        "Take the most efficient route and provide a realistic arrival estimate",
        "Suggest they cancel their appointment"
      ],
      correctAnswer: 2
    },
    {
      id: 20,
      text: "What is the most professional approach when a passenger is being rude?",
      options: [
        "Respond with equal rudeness",
        "Immediately terminate the journey",
        "Remain professional and focus on service delivery",
        "Record them on your phone to prove they were rude"
      ],
      correctAnswer: 2
    }
  ]
};

export const PRACTICE_TESTS = [
  INDUSTRY_KNOWLEDGE_TEST,
  AREA_KNOWLEDGE_TEST,
  CUSTOMER_SERVICE_TEST,
  MOCK_EXAM
];