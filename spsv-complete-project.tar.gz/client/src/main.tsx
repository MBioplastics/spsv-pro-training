import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Set page title
document.title = "SPSV Pro Training - Complete Preparation for SPSV Licensing in Ireland";

// Add meta description
const metaDescription = document.createElement('meta');
metaDescription.name = 'description';
metaDescription.content = 'Complete SPSV training solution for Irish taxi, hackney and limousine drivers. Pass your test first time with our comprehensive learning platform.';
document.head.appendChild(metaDescription);

createRoot(document.getElementById("root")!).render(<App />);
