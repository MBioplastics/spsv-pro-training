import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { InstallPrompt, OfflineIndicator } from "@/components/install-prompt";
import { SEOMonitor } from "@/components/seo-monitor";
import NotFound from "@/pages/not-found";
import Home from "@/pages/index";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import Training from "@/pages/training";
import Module from "@/pages/module";
import Checklists from "@/pages/checklists";
import PracticeTests from "@/pages/practice-tests";
// Document management removed
import Bookings from "@/pages/bookings";
import Checkout from "@/pages/checkout";
import Settings from "@/pages/settings";
import VehicleSearch from "@/pages/vehicle-search";
import Logout from "@/pages/logout";
import PaymentTest from "@/pages/payment-test";
import Pricing from "@/pages/pricing";
import ForgotPassword from "@/pages/forgot-password";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/forgot-password" component={ForgotPassword} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/training" component={Training} />
      <Route path="/module/:id" component={Module} />
      <Route path="/checklists" component={Checklists} />
      <Route path="/practice-tests" component={PracticeTests} />
      <Route path="/vehicle-search" component={VehicleSearch} />
      {/* Removed documents route */}
      <Route path="/bookings" component={Bookings} />
      <Route path="/checkout" component={Checkout} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/payment-test" component={PaymentTest} />
      <Route path="/settings" component={Settings} />
      <Route path="/logout" component={Logout} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SEOMonitor />
        <OfflineIndicator />
        <Router />
        <InstallPrompt />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
