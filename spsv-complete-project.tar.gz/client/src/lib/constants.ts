// Vehicle Types
export const SPSV_TYPES = [
  { id: 'taxi', name: 'Taxi' },
  { id: 'wheelchair_accessible_taxi', name: 'Wheelchair Accessible Taxi' },
  { id: 'hackney', name: 'Hackney' },
  { id: 'wheelchair_accessible_hackney', name: 'Wheelchair Accessible Hackney' },
  { id: 'local_area_hackney', name: 'Local Area Hackney' },
  { id: 'limousine', name: 'Limousine' },
];

// Irish Counties
export const IRISH_COUNTIES = [
  { id: 'carlow', name: 'Carlow' },
  { id: 'cavan', name: 'Cavan' },
  { id: 'clare', name: 'Clare' },
  { id: 'cork', name: 'Cork' },
  { id: 'donegal', name: 'Donegal' },
  { id: 'dublin', name: 'Dublin' },
  { id: 'galway', name: 'Galway' },
  { id: 'kerry', name: 'Kerry' },
  { id: 'kildare', name: 'Kildare' },
  { id: 'kilkenny', name: 'Kilkenny' },
  { id: 'laois', name: 'Laois' },
  { id: 'leitrim', name: 'Leitrim' },
  { id: 'limerick', name: 'Limerick' },
  { id: 'longford', name: 'Longford' },
  { id: 'louth', name: 'Louth' },
  { id: 'mayo', name: 'Mayo' },
  { id: 'meath', name: 'Meath' },
  { id: 'monaghan', name: 'Monaghan' },
  { id: 'offaly', name: 'Offaly' },
  { id: 'roscommon', name: 'Roscommon' },
  { id: 'sligo', name: 'Sligo' },
  { id: 'tipperary', name: 'Tipperary' },
  { id: 'waterford', name: 'Waterford' },
  { id: 'westmeath', name: 'Westmeath' },
  { id: 'wexford', name: 'Wexford' },
  { id: 'wicklow', name: 'Wicklow' },
];

// Website URLs
export const NTA_WEBSITE = 'https://www.nationaltransport.ie';
export const NCT_BOOKING_URL = 'https://www.ncts.ie/booking';

// Training Modules
export const TRAINING_MODULES = [
  { id: 1, title: 'The SPSV Industry', chapter: 1 },
  { id: 2, title: 'SPSV Driver Licensing', chapter: 2 },
  { id: 3, title: 'Choosing a Vehicle to Use as an SPSV', chapter: 3 },
  { id: 4, title: 'SPSV Vehicle Licensing', chapter: 4 },
  { id: 5, title: 'Working as an SPSV Operator', chapter: 5 },
  { id: 6, title: 'Finding Your Way Around', chapter: 6 },
  { id: 7, title: 'Fares', chapter: 7 },
  { id: 8, title: 'Delivering Customer Satisfaction', chapter: 8 },
  { id: 9, title: 'Your SPSV Business', chapter: 9 },
  { id: 10, title: 'Staying Safe', chapter: 10 },
  { id: 11, title: 'Preparing for Your Test', chapter: 11 },
  { id: 12, title: 'County Area Knowledge', chapter: 12 },
];

// Module Content - Real training content based on the SPSV official manual
type ModulePage = {
  title: string;
  content: string;
  keyPoints: string[];
  imageUrl?: string; // Optional image for the page
};

type ModuleContent = {
  [moduleId: number]: {
    pages: ModulePage[];
    vehicleSpecificContent?: {
      [vehicleType: string]: {
        additionalContent?: string;
        additionalKeyPoints?: string[];
      };
    };
  };
};

export const MODULE_CONTENT: ModuleContent = {
  // Module 1: The SPSV Industry
  1: {
    pages: [
      {
        title: "Introduction to the SPSV Industry",
        content: `
          <p>The small public service vehicle (SPSV) industry is an important part of Ireland's public transport system, carrying millions of passengers every year. SPSVs complement the scheduled services provided by bus and rail.</p>
          
          <p>The National Transport Authority (NTA) is responsible for regulating the SPSV industry in Ireland. It develops and maintains the regulatory framework for licensing and operating SPSVs, drivers and dispatch operators.</p>
          
          <p>In addition to its regulatory role, the NTA provides information to the public about SPSVs as well as services for SPSV operators, such as the Driver Check app which allows customers to verify the details of licensed drivers.</p>
        `,
        keyPoints: [
          "SPSVs are an integral part of Ireland's public transport system",
          "The National Transport Authority (NTA) regulates the SPSV industry",
          "The SPSV industry complements scheduled bus and rail services"
        ],
        imageUrl: "/assets/irish_taxi.png"
      },
      {
        title: "Types of SPSVs",
        content: `
          <p>There are six types of SPSVs licensed to operate in Ireland:</p>
          
          <h3>Taxi</h3>
          <p>A taxi may pick up passengers at taxi ranks, in response to a street hail, via a dispatch operator, or through pre-booking. Taxis must have a roof sign, a taximeter, and a printer. They must accept card payments. Taxis must use the National Maximum Taxi Fare for calculating fares.</p>
          
          <h3>Hackney</h3>
          <p>A hackney may only pick up passengers through pre-booking. They may not ply for hire on the street, stand for hire at ranks, or use a taximeter. Hackneys cannot display the word 'taxi' or 'cab' and must operate on a pre-agreed fare basis.</p>
          
          <h3>Local Area Hackney</h3>
          <p>A local area hackney operates in a designated area that has no other SPSV service. These vehicles may only pick up passengers through pre-booking and are restricted to operating within a 5–7 kilometre radius of their specified base.</p>
          
          <h3>Wheelchair Accessible Taxi (WAT)</h3>
          <p>A WAT has the same rights and restrictions as a taxi but is also specially modified to accommodate at least one person seated in their wheelchair with additional space for luggage.</p>
          
          <h3>Wheelchair Accessible Hackney (WAH)</h3>
          <p>A WAH has the same rights and restrictions as a hackney but is also specially modified to accommodate at least one person seated in their wheelchair with additional space for luggage.</p>
          
          <h3>Limousine</h3>
          <p>A limousine may only pick up passengers through pre-booking and must be suited by style and size to be used for ceremonial occasions, corporate events, or for transporting passengers to or from airports or ports.</p>
        `,
        keyPoints: [
          "There are six types of SPSVs in Ireland: Taxi, Hackney, Local Area Hackney, WAT, WAH, and Limousine",
          "Only taxis can ply for hire on streets or use taxi ranks",
          "All pre-booked services must quote a fare in advance",
          "Wheelchair accessible vehicles have special requirements and privileges"
        ]
      },
      {
        title: "SPSV Regulation and Licensing",
        content: `
          <p>The SPSV industry is regulated by the NTA under the provisions of the Taxi Regulation Act 2013 and the Taxi Regulation (Small Public Service Vehicle) Regulations 2015.</p>
          
          <p>There are three types of licences in the SPSV industry:</p>
          <ul>
            <li><strong>SPSV driver licence</strong> - required by all SPSV drivers</li>
            <li><strong>SPSV vehicle licence</strong> - required for each vehicle</li>
            <li><strong>Dispatch operator licence</strong> - required by businesses that take bookings and dispatch SPSVs</li>
          </ul>
          
          <p>All licences are issued by the NTA. SPSV driver licences are only available to persons who have passed the SPSV Entry Test, hold a full driving licence, have tax clearance, and pass Garda vetting.</p>
          
          <p>SPSV vehicle licences are subject to specific requirements for each type of SPSV. The vehicle must meet suitability, roadworthiness, and age requirements.</p>
          
          <p>All licence holders must comply with the SPSV Regulations. Non-compliance may result in sanctions, including fixed payment notices, penalty points, or court prosecution.</p>
        `,
        keyPoints: [
          "Three types of licences: driver, vehicle, and dispatch operator",
          "All licences are issued by the National Transport Authority",
          "SPSV regulations specify requirements for each licence type",
          "Non-compliance can result in penalties including fines and prosecution"
        ]
      },
      {
        title: "SPSV Industry Statistics",
        content: `
          <p>As of December 2024, there are approximately 20,000 SPSV vehicles operating in Ireland, with over 25,000 licensed SPSV drivers. The industry consists predominantly of self-employed individual operators, but also includes fleet owners and dispatch operators.</p>
          
          <p>Dublin has the highest concentration of SPSVs, accounting for approximately 45% of the total fleet. Cork, Galway, and Limerick follow with significant numbers of licensed vehicles.</p>
          
          <p>The SPSV industry serves millions of passengers each year. A typical taxi completes between 5,000 and 7,000 journeys annually, while the average SPSV driver works approximately 40 hours per week.</p>
          
          <p>In recent years, there has been a steady increase in the number of wheelchair accessible vehicles in the fleet, partly due to NTA grants to encourage their adoption. Technology has also transformed the industry, with app-based booking becoming increasingly popular alongside traditional street hails and telephone bookings.</p>
          
          <p>The SPSV industry is a significant contributor to the Irish economy, generating an estimated €800 million in revenue annually and providing essential mobility services to tourists, business travellers, and local communities.</p>
        `,
        keyPoints: [
          "Approximately 20,000 SPSV vehicles and 25,000 licensed drivers in Ireland",
          "Dublin accounts for 45% of the total SPSV fleet",
          "The average SPSV driver works 40 hours per week",
          "The industry is worth approximately €800 million annually"
        ]
      },
      {
        title: "Future Trends in the SPSV Industry",
        content: `
          <p>The SPSV industry in Ireland is evolving rapidly in response to technological innovation, changing consumer preferences, and environmental concerns. Several key trends are shaping the future of the industry:</p>
          
          <h3>Vehicle Electrification</h3>
          <p>There is a growing transition toward electric vehicles in the SPSV fleet, supported by government incentives and grants. The NTA has set targets for reducing the carbon footprint of the SPSV industry, with aims to have a significant portion of the fleet operating as zero-emission vehicles by 2030.</p>
          
          <h3>Digital Transformation</h3>
          <p>Digital platforms and apps are becoming increasingly important for booking, payment, and fleet management. Integration with public transport apps and mobility-as-a-service platforms is creating new opportunities for SPSVs to become part of broader transport solutions.</p>
          
          <h3>Customer Experience</h3>
          <p>Enhanced customer service and personalized experiences are becoming key differentiators in a competitive market. Passengers increasingly expect features such as real-time tracking, digital receipts, and the ability to set preferences for their journeys.</p>
          
          <h3>Accessibility</h3>
          <p>The push for greater accessibility continues, with incentives to increase the number of wheelchair accessible vehicles in the fleet. This includes not just physical accessibility but also features such as hearing loops and facilities for assistance dogs.</p>
          
          <p>As an SPSV operator, staying informed about these trends and adapting your business accordingly will be crucial for long-term success in the industry.</p>
        `,
        keyPoints: [
          "Electrification is a major trend in the SPSV industry",
          "Digital platforms are transforming booking and payment processes",
          "Customer experience is becoming a key competitive factor",
          "Accessibility remains a priority for the future of the industry"
        ]
      }
    ],
    vehicleSpecificContent: {
      "taxi": {
        additionalContent: `
          <p>As a standard taxi operator, you have the most flexibility in how you can obtain fares. You can ply for hire on the street, use taxi ranks, accept street hails, and take pre-bookings.</p>
          
          <p>Taxis must be equipped with specific equipment including a taximeter, printer, and roof sign. You must accept card payments as well as cash, and use the National Maximum Taxi Fare for calculating fares.</p>
          
          <p>The standard taxi market is competitive, particularly in urban areas, so providing excellent customer service and maintaining a clean, comfortable vehicle is essential for success.</p>
        `,
        additionalKeyPoints: [
          "Only taxis can ply for hire on streets and use taxi ranks",
          "Taxis must be equipped with taximeters, printers, and roof signs",
          "Card payment acceptance is mandatory for all taxis",
          "The National Maximum Taxi Fare structure must be used"
        ]
      },
      "hackney": {
        additionalContent: `
          <p>As a hackney operator, you can only accept pre-booked fares. You cannot ply for hire on the street or use taxi ranks, which means developing relationships with dispatch operators and regular customers is particularly important.</p>
          
          <p>Hackneys do not use taximeters; instead, fares must be agreed with the customer before the journey begins. This gives you flexibility in pricing but also requires clear communication about costs.</p>
          
          <p>Your vehicle cannot display the words 'taxi' or 'cab' and must not have a roof sign. Building a reputation for reliability and value is key to success in the hackney market.</p>
        `,
        additionalKeyPoints: [
          "Hackneys can only accept pre-booked fares",
          "Fares must be agreed before the journey begins",
          "No taximeter, roof sign, or 'taxi'/'cab' signage is permitted",
          "Building relationships with dispatch operators is important"
        ]
      },
      "limousine": {
        additionalContent: `
          <p>For limousine operators, the industry demands a higher level of service and presentation. Limousines are specifically licensed for prestigious or ceremonial events, airport transfers, and corporate services.</p>
          
          <p>Limousines must be of a type, design, and construction suitable by reason of style and size for ceremonial occasions, corporate events, annual school proms etc. This generally means luxury or vintage vehicles that would not typically be considered ordinary private cars.</p>
          
          <p>As a limousine operator, you should be aware that your customers will have different expectations compared to those using standard taxis or hackneys. Services should be presented and delivered with an emphasis on quality, punctuality, and attention to detail.</p>
        `,
        additionalKeyPoints: [
          "Limousines must be suitable for ceremonial occasions by style and size",
          "Limousine services require a higher standard of customer service",
          "Limousines typically serve corporate clients and special events"
        ]
      },
      "wheelchair_accessible_taxi": {
        additionalContent: `
          <p>As a wheelchair accessible taxi (WAT) operator, you provide an essential service for passengers with mobility impairments. The NTA places special emphasis on increasing the number of WATs in the national fleet.</p>
          
          <p>WAT operators must have specific knowledge about safely securing wheelchairs, operating ramps or lifts, and assisting passengers with various disabilities. This includes an understanding of how to properly secure different types of wheelchairs and mobility aids.</p>
          
          <p>When operating a WAT, you must give priority to passengers in wheelchairs when plying for hire or standing at ranks. You must also ensure that all accessibility equipment in your vehicle is properly maintained and operational at all times.</p>
        `,
        additionalKeyPoints: [
          "WAT operators must prioritize passengers in wheelchairs",
          "Special training is required for securing various wheelchair types",
          "WATs provide an essential service for passengers with mobility impairments"
        ]
      },
      "wheelchair_accessible_hackney": {
        additionalContent: `
          <p>As a wheelchair accessible hackney (WAH) operator, you provide an essential pre-booked service for passengers with mobility impairments. Like standard hackneys, you can only accept pre-booked fares, not street hails or use taxi ranks.</p>
          
          <p>Your vehicle must be specially adapted to accommodate at least one passenger seated in their wheelchair with sufficient luggage space. This includes having appropriate ramps or lifts, wheelchair restraint systems, and adequate interior dimensions.</p>
          
          <p>WAH services often develop relationships with healthcare facilities, disability organisations, and social services to provide regular transportation services. The licence fee is reduced (€75 vs €150) to encourage more WAH services.</p>
        `,
        additionalKeyPoints: [
          "WAH vehicles can only accept pre-booked fares",
          "Special modifications include ramps/lifts and restraint systems",
          "Reduced licence fees apply to encourage accessible services",
          "Relationships with healthcare facilities can provide regular work"
        ]
      },
      "local_area_hackney": {
        additionalContent: `
          <p>As a local area hackney operator, you provide an essential service in rural areas that would otherwise have limited or no SPSV coverage. Your licence restricts you to operating within a specific designated area, typically within a 5-7 kilometer radius of your base.</p>
          
          <p>Local area hackney licences are only granted in areas where there is no existing SPSV service, and the need for such a service has been identified by the local authority or rural transport coordinator. The licence fee is reduced to €50 to encourage services in underserved areas.</p>
          
          <p>Like standard hackneys, you can only accept pre-booked fares, not street hails, and you must agree on the fare before beginning the journey. Building strong community relationships is particularly important for this type of service.</p>
        `,
        additionalKeyPoints: [
          "Local area hackneys operate in specific rural areas with no other SPSV service",
          "Operations are restricted to a 5-7 kilometer radius from base",
          "Reduced licence fee of €50 applies",
          "Community relationships are key to business success"
        ]
      }
    }
  },
  
  // Module 2: SPSV Driver Licensing
  2: {
    pages: [
      {
        title: "SPSV Driver Licence Requirements",
        content: `
          <p>To operate as an SPSV driver in Ireland, you must hold a valid SPSV driver licence issued by the National Transport Authority (NTA). This is in addition to your standard driving licence.</p>
          
          <p>The key requirements for obtaining an SPSV driver licence are:</p>
          <ul>
            <li>Hold a full Irish driving licence or a foreign driving licence recognized in Ireland</li>
            <li>Pass the SPSV Entry Test, which consists of an Industry Knowledge Test and an Area Knowledge Test</li>
            <li>Be tax compliant with a valid Tax Clearance Certificate</li>
            <li>Pass Garda (Irish Police) vetting</li>
            <li>Be legally entitled to work in Ireland</li>
            <li>Pay the licence fee (currently €250 for a new licence)</li>
          </ul>
          
          <p>SPSV driver licences are valid for a period of 5 years from the date of issue. After this period, you must renew your licence to continue operating as an SPSV driver.</p>
        `,
        keyPoints: [
          "You must hold a full driving licence recognised in Ireland",
          "You must pass both Industry Knowledge and Area Knowledge tests",
          "Garda vetting is mandatory for all SPSV driver applicants",
          "SPSV driver licences are valid for 5 years"
        ]
      },
      {
        title: "The SPSV Entry Test",
        content: `
          <p>The SPSV Entry Test is a key requirement for obtaining an SPSV driver licence. The test consists of two parts:</p>
          
          <h3>Industry Knowledge Test</h3>
          <p>This test assesses your knowledge of the SPSV industry regulations, driver obligations, and best practices. The test consists of 54 questions in multiple-choice format, and you must answer at least 43 correctly to pass. The test covers topics such as:</p>
          <ul>
            <li>SPSV regulations and licensing requirements</li>
            <li>Driver responsibilities and customer service</li>
            <li>Vehicle standards and maintenance</li>
            <li>Fares and payment processing</li>
            <li>Health and safety requirements</li>
          </ul>
          
          <h3>Area Knowledge Test</h3>
          <p>This test assesses your knowledge of the geographical area in which you intend to operate. You will be tested on your ability to:</p>
          <ul>
            <li>Identify major landmarks, tourist attractions, and transport hubs</li>
            <li>Plan efficient routes between various locations</li>
            <li>Understand local traffic regulations and restrictions</li>
            <li>Recognize key streets, districts, and suburbs</li>
          </ul>
          
          <p>The Area Knowledge Test is specific to the county in which you plan to operate. If you wish to operate in multiple counties, you may need to take additional Area Knowledge Tests.</p>
          
          <p>Both tests are conducted at NTA test centres throughout Ireland. You must book your test in advance and pay the test fee (currently €90).</p>
        `,
        keyPoints: [
          "The Industry Knowledge Test has 54 questions with a pass mark of 43",
          "The Area Knowledge Test is specific to your operating county",
          "Both tests must be passed to obtain an SPSV driver licence",
          "Tests are conducted at NTA test centres throughout Ireland"
        ]
      },
      {
        title: "Garda Vetting Process",
        content: `
          <p>Garda vetting is a mandatory part of the SPSV driver licence application process. This process is designed to ensure that SPSV drivers are of good character and suitable to transport members of the public.</p>
          
          <p>The Garda vetting process involves:</p>
          <ul>
            <li>Completing a Garda vetting application form</li>
            <li>Providing proof of identity and address</li>
            <li>Disclosing any previous convictions in Ireland or abroad</li>
            <li>Verification of your identity at an SPSV Industry Information Centre</li>
          </ul>
          
          <p>The National Vetting Bureau will check your background for any criminal convictions or pending prosecutions. The results of this check will be sent to the NTA, which will assess your suitability to hold an SPSV driver licence.</p>
          
          <p>Certain offences may disqualify you from obtaining an SPSV driver licence, particularly those related to:</p>
          <ul>
            <li>Sexual offences</li>
            <li>Violent offences</li>
            <li>Drug-related offences</li>
            <li>Serious road traffic offences</li>
            <li>Fraud or dishonesty</li>
          </ul>
          
          <p>It's important to be honest in your vetting application. Failure to disclose relevant information may result in your application being rejected or your licence being revoked if discovered later.</p>
        `,
        keyPoints: [
          "Garda vetting checks for criminal convictions and pending prosecutions",
          "Certain offences may disqualify you from obtaining a licence",
          "Full disclosure of any previous convictions is essential",
          "Identity verification is required as part of the vetting process"
        ]
      },
      {
        title: "Licence Renewal and Ongoing Requirements",
        content: `
          <p>SPSV driver licences are valid for 5 years and must be renewed before they expire if you wish to continue operating as an SPSV driver.</p>
          
          <p>The licence renewal process involves:</p>
          <ul>
            <li>Submitting a renewal application to the NTA</li>
            <li>Providing proof that you still hold a valid driving licence</li>
            <li>Confirming your tax compliance with a current Tax Clearance Certificate</li>
            <li>Undergoing Garda vetting again</li>
            <li>Paying the renewal fee (currently €200)</li>
          </ul>
          
          <p>It's important to note that renewal is not automatic. You should apply for renewal at least 3 months before your current licence expires to allow time for processing.</p>
          
          <p>As an SPSV driver, you also have ongoing obligations throughout the validity of your licence:</p>
          <ul>
            <li>Maintaining tax compliance at all times</li>
            <li>Notifying the NTA of any change in your circumstances (e.g., change of address, driving disqualification, criminal convictions)</li>
            <li>Ensuring your SPSV driver licence is displayed prominently in your vehicle when operating</li>
            <li>Adhering to all SPSV regulations and standards</li>
          </ul>
          
          <p>Failure to meet these ongoing requirements may result in your licence being suspended or revoked. If your licence does expire, you will need to apply for a new licence and potentially retake the Entry Test.</p>
        `,
        keyPoints: [
          "SPSV driver licences must be renewed every 5 years",
          "Apply for renewal at least 3 months before expiry",
          "Ongoing tax compliance is essential",
          "You must notify the NTA of any relevant changes in your circumstances"
        ]
      },
      {
        title: "Rights and Responsibilities of SPSV Drivers",
        content: `
          <p>As an SPSV driver, you have specific rights and responsibilities defined by law. Understanding these is essential for operating legally and professionally.</p>
          
          <h3>Your Rights as an SPSV Driver</h3>
          <p>As a licensed SPSV driver, you have the right to:</p>
          <ul>
            <li>Operate any appropriately licensed SPSV (with the owner's permission)</li>
            <li>Charge fares according to the National Maximum Taxi Fare (for taxis) or pre-agreed rates (for hackneys and limousines)</li>
            <li>Use dedicated taxi ranks (taxi drivers only)</li>
            <li>Refuse service in certain circumstances (e.g., if a passenger is threatening or disorderly, carrying dangerous items, or refusing to prepay when required)</li>
            <li>Request support from An Garda Síochána when dealing with problematic passengers</li>
          </ul>
          
          <h3>Your Responsibilities as an SPSV Driver</h3>
          <p>Your key responsibilities include:</p>
          <ul>
            <li>Displaying your SPSV driver identification prominently in your vehicle</li>
            <li>Maintaining a professional appearance and ensuring your vehicle is clean and roadworthy</li>
            <li>Taking the most economical route unless the passenger requests otherwise</li>
            <li>Providing assistance to passengers with luggage and those with disabilities</li>
            <li>Accepting guide dogs and assistance dogs</li>
            <li>Providing receipts when requested</li>
            <li>Accepting card payments (for taxi drivers)</li>
            <li>Respecting passenger privacy and confidentiality</li>
            <li>Complying with all road traffic laws and SPSV regulations</li>
          </ul>
          
          <p>Remember that as an SPSV driver, you represent the industry as a whole. Professional conduct not only meets your legal obligations but also helps maintain the reputation of the SPSV industry and ensures a positive experience for your passengers.</p>
        `,
        keyPoints: [
          "SPSV drivers must display their identification in the vehicle",
          "You must take the most economical route unless requested otherwise",
          "You must provide assistance with luggage when necessary",
          "Taxis must accept card payments by law"
        ]
      }
    ],
    vehicleSpecificContent: {
      "wheelchair_accessible_taxi": {
        additionalContent: `
          <p>As a wheelchair accessible taxi (WAT) driver, you have additional responsibilities to ensure the safety and comfort of passengers with disabilities:</p>
          
          <ul>
            <li>You must be proficient in the operation of accessibility equipment such as ramps, lifts, and wheelchair restraint systems</li>
            <li>You must prioritize passengers in wheelchairs when operating at taxi ranks or responding to street hails</li>
            <li>You should receive training in assisting passengers with various disabilities</li>
            <li>You must ensure that all accessibility equipment is functioning correctly at all times</li>
          </ul>
          
          <p>WAT drivers should be aware that the NTA offers specific grants and incentives for WAT operation, recognizing the important service these vehicles provide to the community.</p>
        `,
        additionalKeyPoints: [
          "WAT drivers must be trained in operating accessibility equipment",
          "Priority must be given to wheelchair users when plying for hire",
          "Regular checks of accessibility equipment are essential"
        ]
      }
    }
  },
  
  // Module 3: Choosing a Vehicle to Use as an SPSV
  3: {
    pages: [
      {
        title: "Vehicle Suitability Requirements",
        content: `
          <p>Choosing the right vehicle for SPSV operations is a critical decision that will affect your operating costs, passenger experience, and compliance with regulations. All vehicles used as SPSVs must meet specific suitability requirements set by the National Transport Authority (NTA).</p>
          
          <h3>General Suitability Requirements</h3>
          <p>All SPSV vehicles must:</p>
          <ul>
            <li>Be in sound mechanical condition and pass the NCT (National Car Test)</li>
            <li>Be less than 10 years old (with some exceptions for vintage limousines)</li>
            <li>Have a minimum of four passenger doors (except for certain limousines)</li>
            <li>Have a minimum interior space to accommodate passengers comfortably</li>
            <li>Have functioning interior lighting</li>
            <li>Have properly functioning seat belts for all seating positions</li>
            <li>Be clean, tidy, and free from damage inside and out</li>
            <li>Have no visible rust, damage, or missing trim</li>
          </ul>
          
          <p>The NTA publishes a list of vehicles that meet the minimum acceptable standards for SPSV licensing. This list is updated regularly and is available on the NTA website.</p>
          
          <h3>Vehicle Age Requirements</h3>
          <p>New vehicle licences are only granted to vehicles that are less than 10 years old. The age of a vehicle is calculated from the date of first registration. Once licensed, vehicles may continue to be licensed until they reach a maximum of 10 years of age, after which they must be replaced.</p>
          
          <p>There are some exceptions to the age rule for vintage or classic vehicles used as limousines, subject to specific conditions and enhanced inspection requirements.</p>
        `,
        keyPoints: [
          "Vehicles must be less than 10 years old for new SPSV licences",
          "Vehicles must pass the NCT and SPSV suitability test",
          "Minimum requirements include four doors and adequate interior space",
          "The NTA maintains a list of acceptable vehicle models"
        ],
        imageUrl: "/assets/irish_taxi.png"
      },
      {
        title: "Vehicle Categories and Specific Requirements",
        content: `
          <p>Each category of SPSV has specific vehicle requirements in addition to the general suitability standards:</p>
          
          <h3>Taxi and Hackney</h3>
          <p>Standard taxis and hackneys must:</p>
          <ul>
            <li>Have at least four passenger doors</li>
            <li>Be capable of carrying at least four passengers in addition to the driver</li>
            <li>Have a minimum interior space with defined measurements for legroom, headroom, and luggage space</li>
            <li>For taxis only: be fitted with a taximeter, printer, and roof sign</li>
          </ul>
          
          <h3>Wheelchair Accessible Vehicles (WAT/WAH)</h3>
          <p>Wheelchair accessible taxis and hackneys must:</p>
          <ul>
            <li>Be capable of accommodating at least one person seated in their wheelchair</li>
            <li>Have suitable restraints for securing the wheelchair</li>
            <li>Have appropriate ramps or lifts for wheelchair access</li>
            <li>Have sufficient door height and interior dimensions for wheelchair access</li>
            <li>Have proper floor tracking and restraint systems</li>
            <li>Meet specific dimensional requirements set out in the SPSV regulations</li>
          </ul>
          
          <h3>Limousines</h3>
          <p>Vehicles for limousine licences must:</p>
          <ul>
            <li>Be suited by style and size for ceremonial, corporate, or prestigious events</li>
            <li>Generally be either luxury high-end vehicles or vintage/classic cars</li>
            <li>Be in excellent condition both mechanically and cosmetically</li>
            <li>Vintage vehicles must undergo enhanced inspection procedures</li>
          </ul>
          
          <h3>Local Area Hackney</h3>
          <p>Local Area Hackney vehicles follow similar requirements to standard hackneys but operate in a designated local area only.</p>
          
          <p>Detailed specifications for each SPSV category can be found in the SPSV Vehicle Standards document published by the NTA.</p>
        `,
        keyPoints: [
          "Each SPSV category has specific vehicle requirements",
          "WAT/WAH vehicles must accommodate at least one wheelchair passenger",
          "Limousines must be suitable for ceremonial or corporate use",
          "Specific dimensional requirements apply to each vehicle type"
        ]
      },
      {
        title: "Selecting a Cost-Effective Vehicle",
        content: `
          <p>When choosing a vehicle for SPSV operations, cost considerations are important for the long-term profitability of your business. Key factors to consider include:</p>
          
          <h3>Purchase Cost</h3>
          <p>The initial purchase price of a vehicle is a significant upfront investment. Consider:</p>
          <ul>
            <li>New versus used vehicles (noting age restrictions)</li>
            <li>Financing options and their impact on your cash flow</li>
            <li>Resale value and depreciation rates</li>
            <li>Potential grants for wheelchair accessible vehicles</li>
          </ul>
          
          <h3>Running Costs</h3>
          <p>Ongoing expenses will significantly impact your profitability:</p>
          <ul>
            <li>Fuel economy - diesel, petrol, hybrid, or electric options</li>
            <li>Insurance costs - which vary by vehicle type and value</li>
            <li>Road tax - which is typically based on emissions</li>
            <li>Servicing and maintenance costs</li>
            <li>Replacement parts availability and cost</li>
            <li>Reliability and frequency of repairs</li>
          </ul>
          
          <h3>Operational Considerations</h3>
          <p>The vehicle's suitability for your specific business model:</p>
          <ul>
            <li>Passenger capacity for your target market</li>
            <li>Luggage space for airport or tourist services</li>
            <li>Comfort level for longer journeys</li>
            <li>Accessibility features if catering to elderly or disabled passengers</li>
            <li>Environmental considerations and potential for low-emission zones</li>
          </ul>
          
          <p>It's advisable to research the total cost of ownership over the expected lifespan of the vehicle in SPSV service (typically up to 10 years), rather than focusing solely on the purchase price.</p>
        `,
        keyPoints: [
          "Consider both purchase cost and ongoing running expenses",
          "Fuel economy significantly impacts profitability",
          "Maintenance costs vary widely between vehicle models",
          "Choose a vehicle that suits your specific business model"
        ]
      },
      {
        title: "Vehicle Inspection and Suitability Testing",
        content: `
          <p>Before a vehicle can be licensed as an SPSV, it must pass two types of inspections:</p>
          
          <h3>National Car Test (NCT)</h3>
          <p>All SPSV vehicles must have a valid NCT certificate. The NCT checks:</p>
          <ul>
            <li>Braking systems</li>
            <li>Suspension and steering components</li>
            <li>Lights and electrical systems</li>
            <li>Exhaust emissions</li>
            <li>Body condition and chassis integrity</li>
            <li>Wheels and tyres</li>
          </ul>
          <p>For vehicles under 10 years old, the NCT is required every year. Vehicles must display a valid NCT disc at all times when operating as an SPSV.</p>
          
          <h3>SPSV Suitability Test</h3>
          <p>In addition to the NCT, all vehicles must pass an SPSV suitability test, which focuses on:</p>
          <ul>
            <li>Compliance with SPSV-specific regulations</li>
            <li>Interior and exterior condition</li>
            <li>Seating configuration and accessibility</li>
            <li>Required equipment (such as taximeters for taxis)</li>
            <li>Signage and vehicle markings</li>
            <li>For WAT/WAH vehicles: wheelchair accessibility features</li>
          </ul>
          
          <p>The suitability test is conducted at authorised SPSV testing centres. Upon passing, the vehicle will be issued with a suitability certificate valid for 12 months.</p>
          
          <h3>Booking an Inspection</h3>
          <p>Both the NCT and SPSV suitability tests must be booked in advance:</p>
          <ul>
            <li>NCT tests can be booked online at www.ncts.ie or by phone</li>
            <li>SPSV suitability tests can be booked through the NTA's booking system</li>
          </ul>
          
          <p>It's advisable to have your vehicle inspected well in advance of licence application or renewal to allow time for any necessary repairs or modifications.</p>
        `,
        keyPoints: [
          "Two inspections are required: the NCT and SPSV suitability test",
          "NCT focuses on roadworthiness and safety",
          "Suitability test checks compliance with SPSV-specific regulations",
          "Both certificates must be current for a vehicle to operate legally"
        ]
      },
      {
        title: "Environmental Considerations and Future Trends",
        content: `
          <p>Environmental considerations are becoming increasingly important in the SPSV industry, with a gradual shift toward greener vehicles.</p>
          
          <h3>Electric and Hybrid Vehicles</h3>
          <p>The NTA is encouraging the adoption of electric and hybrid vehicles in the SPSV fleet:</p>
          <ul>
            <li>Electric vehicles (EVs) have lower running costs and zero tailpipe emissions</li>
            <li>Hybrid vehicles offer improved fuel economy for urban driving</li>
            <li>Government grants may be available for purchasing electric vehicles</li>
            <li>The charging infrastructure is expanding across Ireland</li>
          </ul>
          
          <h3>Emission Standards</h3>
          <p>Newer vehicles with higher Euro emission standards produce fewer pollutants:</p>
          <ul>
            <li>Current new vehicles meet Euro 6 standards, which limit NOx and particulate emissions</li>
            <li>Lower emission vehicles may benefit from reduced road tax</li>
            <li>Future regulations may include emissions-based restrictions in urban areas</li>
          </ul>
          
          <h3>Long-term Planning</h3>
          <p>When selecting a vehicle, consider future trends in the industry:</p>
          <ul>
            <li>The Government's Climate Action Plan aims to significantly reduce transport emissions by 2030</li>
            <li>Future regulations may favor or mandate low-emission vehicles</li>
            <li>Consumer preferences are shifting toward eco-friendly transport options</li>
            <li>Resale value of high-emission vehicles may decline faster</li>
          </ul>
          
          <p>While the initial cost of electric or hybrid vehicles may be higher, the total cost of ownership over the vehicle's lifespan could be lower due to reduced fuel, maintenance, and tax costs. As an SPSV operator, considering these environmental factors in your vehicle choice can future-proof your business and potentially provide a marketing advantage.</p>
        `,
        keyPoints: [
          "Electric and hybrid vehicles offer lower running costs",
          "Government incentives are available for low-emission vehicles",
          "Future regulations may restrict high-emission vehicles in urban areas",
          "Long-term planning should consider environmental trends"
        ]
      }
    ],
    vehicleSpecificContent: {
      "limousine": {
        additionalContent: `
          <p>For limousine operators, vehicle selection is particularly important as the vehicle itself is a key part of the service offering. Limousines must be of a type, design, and construction suitable for ceremonial occasions, corporate events, or prestigious transport.</p>
          
          <p>Acceptable vehicles for limousine licensing include:</p>
          <ul>
            <li>Luxury high-end vehicles (e.g., Mercedes S-Class, BMW 7 Series, Audi A8)</li>
            <li>Purpose-built stretched limousines with appropriate certification</li>
            <li>Vintage or classic cars maintained to an excellent standard</li>
            <li>Distinctive or unique vehicles suited to prestigious events</li>
          </ul>
          
          <p>When selecting a limousine, consider:</p>
          <ul>
            <li>The target market and type of events you plan to service</li>
            <li>Interior luxury features and passenger amenities</li>
            <li>Maintenance requirements, which can be substantial for vintage vehicles</li>
            <li>Special licensing considerations for stretched or modified vehicles</li>
          </ul>
          
          <p>Limousines that are over 10 years old may still be licensed if they are vintage or classic vehicles in excellent condition, but they will be subject to enhanced inspection procedures.</p>
        `,
        additionalKeyPoints: [
          "Limousines must be suitable for prestigious or ceremonial use",
          "Vintage vehicles may be licensed beyond the 10-year limit",
          "Interior luxury features are an important consideration",
          "Enhanced inspections apply to older limousines"
        ]
      },
      "wheelchair_accessible_taxi": {
        additionalContent: `
          <p>When selecting a vehicle for wheelchair accessible taxi (WAT) operations, there are specific technical requirements that must be met:</p>
          
          <ul>
            <li>The vehicle must have a hydraulic or electric lift or a suitable ramp for wheelchair access</li>
            <li>Door dimensions must allow for the entry of a standard reference wheelchair (minimum height 1400mm, width 800mm)</li>
            <li>Interior dimensions must accommodate at least one passenger seated in their wheelchair</li>
            <li>The vehicle must have ISO 10542 compliant wheelchair restraint systems</li>
            <li>A minimum of three additional passenger seats must be available when a wheelchair is being carried</li>
          </ul>
          
          <p>Common vehicle types used for WAT services include purpose-modified vans and MPVs such as:</p>
          <ul>
            <li>Volkswagen Caddy Maxi Life</li>
            <li>Peugeot Partner Tepee</li>
            <li>Ford Tourneo Connect</li>
            <li>Mercedes Vito</li>
            <li>Volkswagen Transporter</li>
          </ul>
          
          <p>The NTA offers grant schemes to assist with the purchase or conversion of WAT vehicles, which can significantly reduce the initial investment cost.</p>
        `,
        additionalKeyPoints: [
          "WAT vehicles require specific dimensional requirements for wheelchair access",
          "ISO-compliant restraint systems are mandatory",
          "NTA grants are available for WAT vehicles",
          "Purpose-modified vans or MPVs are commonly used for WAT services"
        ]
      }
    }
  },
  
  // Module 4: SPSV Vehicle Licensing
  4: {
    pages: [
      {
        title: "SPSV Vehicle Licence Overview",
        content: `
          <p>Every vehicle operating as an SPSV in Ireland must hold a valid SPSV vehicle licence issued by the National Transport Authority (NTA). This licence is specific to both the vehicle and the category of service (taxi, hackney, limousine, etc.).</p>
          
          <h3>Types of SPSV Vehicle Licences</h3>
          <p>There are six categories of SPSV vehicle licences:</p>
          <ul>
            <li><strong>Taxi Licence</strong> - Allows the vehicle to be used as a taxi, which can ply for hire on streets, use taxi ranks, and be pre-booked</li>
            <li><strong>Wheelchair Accessible Taxi (WAT) Licence</strong> - For vehicles modified to carry at least one person seated in their wheelchair</li>
            <li><strong>Hackney Licence</strong> - For vehicles that can only be pre-booked and cannot ply for hire or use taxi ranks</li>
            <li><strong>Wheelchair Accessible Hackney (WAH) Licence</strong> - For wheelchair accessible vehicles that operate on a pre-booking basis only</li>
            <li><strong>Local Area Hackney Licence</strong> - For vehicles serving specific rural areas with limited transport options</li>
            <li><strong>Limousine Licence</strong> - For vehicles suited by style and size for ceremonial or corporate use, operating on a pre-booking basis only</li>
          </ul>
          
          <h3>Licence Duration and Fees</h3>
          <p>SPSV vehicle licences are valid for 12 months and must be renewed annually. Current licence fees are:</p>
          <ul>
            <li>Standard Taxi or Hackney: €150</li>
            <li>Wheelchair Accessible Taxi or Hackney: €75</li>
            <li>Local Area Hackney: €50</li>
            <li>Limousine: €150</li>
          </ul>
          
          <p>These fees are subject to change, and the most current information should be obtained from the NTA website.</p>
        `,
        keyPoints: [
          "Six types of SPSV vehicle licences are available",
          "Each licence has specific operating rights and restrictions",
          "Licences are valid for 12 months and must be renewed annually",
          "Reduced fees apply for wheelchair accessible vehicles"
        ]
      },
      {
        title: "Applying for an SPSV Vehicle Licence",
        content: `
          <p>The process for obtaining a new SPSV vehicle licence involves several steps:</p>
          
          <h3>Preliminary Requirements</h3>
          <p>Before applying, ensure:</p>
          <ul>
            <li>The vehicle meets the age and suitability requirements for the licence category</li>
            <li>You have a valid Certificate of Roadworthiness (NCT) for the vehicle</li>
            <li>You have valid vehicle insurance specifically covering use as an SPSV</li>
            <li>The vehicle is registered in the State</li>
            <li>You have tax clearance (for the vehicle owner)</li>
          </ul>
          
          <h3>Application Process</h3>
          <ol>
            <li><strong>Book an SPSV Vehicle Suitability Test</strong> through the NTA's booking system</li>
            <li><strong>Pass the Suitability Test</strong> to verify the vehicle meets all regulatory requirements</li>
            <li><strong>Apply for the SPSV Vehicle Licence</strong> through the NTA's online portal or at an SPSV Information Centre</li>
            <li><strong>Pay the Licence Fee</strong> as applicable to your vehicle category</li>
            <li><strong>Receive Vehicle Licensing Documents</strong> including the SPSV vehicle licence certificate and vehicle licence discs</li>
          </ol>
          
          <h3>Documentation Required</h3>
          <p>You will need to provide:</p>
          <ul>
            <li>The vehicle registration certificate (log book)</li>
            <li>Proof of valid SPSV insurance</li>
            <li>NCT certificate</li>
            <li>SPSV suitability test certificate</li>
            <li>Tax clearance verification</li>
            <li>For WAT/WAH vehicles: technical certification of accessibility modifications</li>
            <li>For modified vehicles: certification of modifications</li>
          </ul>
          
          <p>Note that for certain licence types (particularly standard taxi licences), there may be limited availability due to regulatory restrictions. The NTA website provides current information on licence availability.</p>
        `,
        keyPoints: [
          "Valid insurance, NCT, and suitability test are prerequisites",
          "Applications can be submitted online or at SPSV Information Centres",
          "Documentation must be provided to verify vehicle eligibility",
          "Some licence types may have limited availability"
        ]
      },
      {
        title: "Licence Renewal and Maintenance",
        content: `
          <p>SPSV vehicle licences must be renewed annually to remain valid. The renewal process and ongoing obligations are important aspects of SPSV operation.</p>
          
          <h3>Renewal Process</h3>
          <p>To renew an SPSV vehicle licence:</p>
          <ol>
            <li><strong>Book and Pass a Suitability Test</strong> - This should be done before the licence expiry date</li>
            <li><strong>Apply for Renewal</strong> - Using the NTA's online portal or at an SPSV Information Centre</li>
            <li><strong>Pay the Renewal Fee</strong> - Same as the original licence fee</li>
            <li><strong>Receive Updated Documentation</strong> - Including new licence discs</li>
          </ol>
          
          <p>It's recommended to start the renewal process at least 4-6 weeks before the licence expiry date to allow time for any necessary vehicle repairs or adjustments.</p>
          
          <h3>Ongoing Obligations</h3>
          <p>While operating with an SPSV vehicle licence, you must:</p>
          <ul>
            <li>Display the SPSV vehicle licence disc prominently on the windscreen</li>
            <li>Display the vehicle registration plate on the front and rear of the vehicle</li>
            <li>For taxis: maintain a functioning taximeter that has been verified and sealed by the Legal Metrology Service</li>
            <li>For taxis: display the required roof sign and door signage</li>
            <li>Maintain the vehicle in a clean, roadworthy condition at all times</li>
            <li>Ensure all required equipment (including payment terminals for taxis) is functional</li>
            <li>Maintain valid SPSV insurance coverage</li>
            <li>Have the vehicle tested for roadworthiness (NCT) annually</li>
          </ul>
          
          <h3>Licence Expiry Consequences</h3>
          <p>If you allow an SPSV vehicle licence to expire:</p>
          <ul>
            <li>The vehicle can no longer legally operate as an SPSV</li>
            <li>You must remove all taxi/hackney signage from the vehicle</li>
            <li>If expired for more than 12 months, you may need to apply for a new licence rather than a renewal</li>
            <li>Operating with an expired licence can result in significant penalties, including fines and prosecution</li>
          </ul>
        `,
        keyPoints: [
          "Renewal should be initiated well before the expiry date",
          "Annual suitability tests are required for renewal",
          "Required signage and equipment must be maintained",
          "Expired licences cannot be used for SPSV operations"
        ]
      },
      {
        title: "Transferring and Changing Vehicle Licences",
        content: `
          <p>There are several situations where you might need to transfer an SPSV licence or change details associated with it.</p>
          
          <h3>Vehicle Replacement</h3>
          <p>If you wish to replace your licensed vehicle with another vehicle:</p>
          <ol>
            <li>The new vehicle must meet all suitability requirements for the licence category</li>
            <li>A Vehicle Licence Transfer application must be submitted to the NTA</li>
            <li>The new vehicle must pass an SPSV suitability test</li>
            <li>The original licence discs must be returned</li>
            <li>A transfer fee must be paid (currently €50)</li>
          </ol>
          
          <p>Vehicle replacements must be completed within 3 months of notifying the NTA of your intention to change vehicles.</p>
          
          <h3>Ownership Transfer</h3>
          <p>In certain limited circumstances, SPSV vehicle licences may be transferred to another person:</p>
          <ul>
            <li>Transfer to a nominated family member in the event of the licence holder's death</li>
            <li>Transfer to a spouse/civil partner in the event of separation or divorce</li>
            <li>Transfer to a spouse/civil partner/child where the licence holder has a serious medical incapacity</li>
          </ul>
          
          <p>These transfers require specific documentation and approval from the NTA. Standard taxi licences issued after 2010 generally cannot be transferred to another person.</p>
          
          <h3>Changing Licence Category</h3>
          <p>In some cases, you may want to change the category of your SPSV licence (e.g., from standard taxi to wheelchair accessible taxi):</p>
          <ul>
            <li>The vehicle must meet all requirements for the new licence category</li>
            <li>A new application for the desired licence category must be submitted</li>
            <li>The existing licence must be surrendered</li>
            <li>The appropriate fee for the new licence must be paid</li>
          </ul>
          
          <p>Note that changing from certain categories may not be possible due to regulatory restrictions, particularly for standard taxi licences which are limited in number.</p>
        `,
        keyPoints: [
          "Vehicle replacements must be completed within 3 months",
          "Ownership transfers are only permitted in specific circumstances",
          "Changing licence categories requires surrendering the existing licence",
          "Not all licence changes are permitted under regulations"
        ]
      },
      {
        title: "Compliance and Enforcement",
        content: `
          <p>The NTA has broad enforcement powers to ensure compliance with SPSV regulations. Understanding these enforcement mechanisms is important for all SPSV operators.</p>
          
          <h3>NTA Compliance Officers</h3>
          <p>NTA Compliance Officers conduct regular checks on SPSV vehicles and operators to ensure regulatory compliance. These officers have the authority to:</p>
          <ul>
            <li>Stop and inspect any vehicle they suspect is operating as an SPSV</li>
            <li>Request to see SPSV licences and related documentation</li>
            <li>Examine the condition and equipment of the vehicle</li>
            <li>Test taximeters for accuracy</li>
            <li>Issue fixed payment notices for certain offences</li>
          </ul>
          
          <h3>Common Compliance Issues</h3>
          <p>Areas where operators commonly face compliance problems include:</p>
          <ul>
            <li>Operating with expired licences or NCT certificates</li>
            <li>Failure to display required signage and licence discs</li>
            <li>Vehicle defects or cleanliness issues</li>
            <li>Taximeter irregularities (for taxis)</li>
            <li>Operating outside the terms of the licence (e.g., hackney plying for hire)</li>
            <li>Not accepting card payments (for taxis)</li>
            <li>Not providing receipts when requested</li>
          </ul>
          
          <h3>Penalties for Non-Compliance</h3>
          <p>Penalties for breaching SPSV regulations can include:</p>
          <ul>
            <li>Fixed payment notices (on-the-spot fines), typically ranging from €40 to €250</li>
            <li>Court prosecutions for more serious offences, with fines up to €10,000</li>
            <li>Penalty points on the SPSV driver licence</li>
            <li>Suspension or revocation of SPSV licences</li>
            <li>Vehicle impoundment in serious cases</li>
          </ul>
          
          <p>Maintaining compliance with all regulations is essential not only to avoid penalties but also to uphold the reputation of the SPSV industry and ensure passenger safety and satisfaction.</p>
        `,
        keyPoints: [
          "NTA Compliance Officers have authority to inspect SPSVs",
          "Common compliance issues include expired documentation and equipment failures",
          "Penalties range from fixed payment notices to licence revocation",
          "Regular self-checks can help ensure ongoing compliance"
        ]
      }
    ],
    vehicleSpecificContent: {
      "limousine": {
        additionalContent: `
          <p>Limousine vehicle licensing has some specific considerations:</p>
          
          <ul>
            <li>Limousines must be suited by style and size for ceremonial occasions, corporate events, or prestigious functions</li>
            <li>Vehicles that would not typically be considered ordinary private cars are generally required</li>
            <li>Vintage vehicles used as limousines may be exempt from the 10-year age limit, subject to enhanced inspections</li>
            <li>Stretched limousines require additional certification to verify structural integrity and safety</li>
            <li>The interior of a limousine must be maintained to a high standard reflecting the prestige nature of the service</li>
          </ul>
          
          <p>The annual licence fee for limousines is currently €150. Limousine operators should be aware that their vehicles may be subject to more detailed inspection of luxury features and overall presentation during suitability testing.</p>
        `,
        additionalKeyPoints: [
          "Vintage limousines may be exempt from standard age restrictions",
          "Stretched vehicles require additional safety certification",
          "Interior luxury features and presentation are important for limousines",
          "Style and size must be suitable for ceremonial or corporate use"
        ]
      },
      "wheelchair_accessible_taxi": {
        additionalContent: `
          <p>Wheelchair Accessible Taxi (WAT) licensing includes specific requirements:</p>
          
          <ul>
            <li>The vehicle must successfully pass the WAT-specific suitability test, which verifies accessibility features</li>
            <li>Operators must demonstrate proficiency in the use of accessibility equipment</li>
            <li>The licence fee is reduced to €75 per year (compared to €150 for standard taxis)</li>
            <li>The NTA offers grants for new WAT licences to encourage more accessible vehicles in the fleet</li>
            <li>WAT vehicles must maintain all accessibility equipment in full working order at all times</li>
            <li>Technical certification of accessibility modifications must be provided during licensing</li>
          </ul>
          
          <p>WAT operators should be aware that they are obligated to give priority to passengers in wheelchairs when operating at taxi ranks or responding to street hails.</p>
        `,
        additionalKeyPoints: [
          "WAT licences have a reduced annual fee of €75",
          "NTA grants are available for new WAT licences",
          "All accessibility equipment must be maintained in working order",
          "Special suitability tests verify accessibility features"
        ]
      }
    }
  },
  
  // Module 5: Working as an SPSV Operator
  5: {
    pages: [
      {
        title: "Daily Operations and Routines",
        content: `
          <p>Establishing effective daily routines is essential for successful and efficient SPSV operations. This includes vehicle preparation, documentation checks, and operational practices.</p>
          
          <h3>Start of Shift Procedures</h3>
          <p>Before beginning operations each day, you should:</p>
          <ul>
            <li>Conduct a vehicle safety check, including lights, brakes, tires, and fluid levels</li>
            <li>Clean the interior and exterior of the vehicle</li>
            <li>Ensure all required equipment is functioning (taximeter, printer, payment terminal)</li>
            <li>Verify that all required documentation is present and valid:
              <ul>
                <li>SPSV driver licence (displayed in the vehicle)</li>
                <li>SPSV vehicle licence disc (displayed on windscreen)</li>
                <li>Insurance certificate</li>
                <li>Vehicle registration document</li>
              </ul>
            </li>
            <li>Check that all required signage is properly displayed</li>
            <li>For taxi drivers: ensure the taximeter is calibrated to the correct tariff</li>
          </ul>
          
          <h3>During Shift Operations</h3>
          <p>While operating throughout your shift:</p>
          <ul>
            <li>Maintain professional appearance and vehicle cleanliness</li>
            <li>For taxi drivers: position yourself at appropriate taxi ranks or in areas with likely demand</li>
            <li>For pre-booked services: plan routes efficiently to minimize waiting time</li>
            <li>Take required breaks to prevent fatigue</li>
            <li>Maintain records of journeys and fares as required for tax purposes</li>
            <li>Follow appropriate protocols for handling passenger luggage and special requests</li>
            <li>Process payments efficiently and provide receipts when requested</li>
          </ul>
          
          <h3>End of Shift Procedures</h3>
          <p>At the end of your working day:</p>
          <ul>
            <li>Complete any required journey logs or fare records</li>
            <li>Clean the vehicle interior, removing any litter</li>
            <li>Check for any items left behind by passengers</li>
            <li>Note any vehicle maintenance issues that need attention</li>
            <li>Secure the vehicle appropriately</li>
            <li>Process and balance payments received</li>
          </ul>
        `,
        keyPoints: [
          "Regular vehicle safety checks are essential before starting work",
          "Maintain proper documentation and displays at all times",
          "Keep records of journeys and fares for tax purposes",
          "End-of-shift procedures should include checking for lost property"
        ]
      },
      {
        title: "Working with Dispatch Operators",
        content: `
          <p>Many SPSV drivers work with dispatch operators to source bookings and manage their workload efficiently.</p>
          
          <h3>Types of Dispatch Services</h3>
          <p>Dispatch operators in the SPSV industry include:</p>
          <ul>
            <li><strong>Traditional Radio Dispatch Companies</strong> - Centralized booking systems that distribute jobs via radio or computer dispatch</li>
            <li><strong>App-Based Platforms</strong> - Mobile applications that connect passengers directly with drivers</li>
            <li><strong>Telephone Booking Services</strong> - Call centers that take bookings and allocate them to affiliated drivers</li>
            <li><strong>Corporate Account Providers</strong> - Services that specialise in business clients with regular transport needs</li>
          </ul>
          
          <h3>Benefits of Working with Dispatch Operators</h3>
          <p>The advantages of affiliating with dispatch services include:</p>
          <ul>
            <li>Steady source of pre-booked fares, reducing idle time</li>
            <li>Access to corporate accounts and regular customers</li>
            <li>Reduced reliance on street hails or ranks (especially important for hackneys)</li>
            <li>Electronic payment processing and accounting support</li>
            <li>Safety benefits through journey tracking and record-keeping</li>
            <li>Marketing and brand recognition provided by the dispatch company</li>
          </ul>
          
          <h3>Considerations When Choosing a Dispatch Operator</h3>
          <p>When selecting a dispatch service to work with, consider:</p>
          <ul>
            <li>Fee structure and commission rates</li>
            <li>Volume and quality of bookings they provide</li>
            <li>Geographic coverage area</li>
            <li>Technology platform reliability</li>
            <li>Payment terms and settlement periods</li>
            <li>Requirements for vehicle standards or driver dress codes</li>
            <li>Exclusivity requirements (can you work with multiple operators?)</li>
            <li>Customer reviews and reputation</li>
          </ul>
          
          <p>Remember that all dispatch operators must be licensed by the NTA. You can verify a dispatch operator's licence status on the NTA website.</p>
        `,
        keyPoints: [
          "Dispatch operators must be licensed by the NTA",
          "Working with dispatch operators provides a steady source of fares",
          "Consider fee structures and service quality when choosing operators",
          "App-based platforms have become increasingly important in the industry"
        ]
      },
      {
        title: "Record Keeping and Financial Management",
        content: `
          <p>Proper record keeping and financial management are essential aspects of running a successful SPSV business.</p>
          
          <h3>Required Records</h3>
          <p>As an SPSV operator, you should maintain:</p>
          <ul>
            <li><strong>Journey Records</strong> - Details of each fare including date, time, pick-up/drop-off locations, and fare charged</li>
            <li><strong>Income Records</strong> - Daily, weekly, and monthly income figures</li>
            <li><strong>Expense Records</strong> - All business-related expenditures including:
              <ul>
                <li>Fuel costs</li>
                <li>Vehicle maintenance and repairs</li>
                <li>Insurance payments</li>
                <li>Licence fees</li>
                <li>Dispatch operator fees</li>
                <li>Mobile phone and technology costs</li>
              </ul>
            </li>
            <li><strong>Tax Records</strong> - Documentation required for annual tax returns</li>
            <li><strong>Vehicle Records</strong> - Maintenance history, NCT certificates, and suitability test results</li>
          </ul>
          
          <h3>Tax Obligations</h3>
          <p>SPSV operators in Ireland have specific tax obligations:</p>
          <ul>
            <li><strong>Income Tax</strong> - As a self-employed person, you must file an annual tax return</li>
            <li><strong>VAT</strong> - If your turnover exceeds the threshold (currently €37,500), you must register for and collect VAT</li>
            <li><strong>PRSI</strong> - Self-employed contributions are mandatory</li>
            <li><strong>Tax Clearance</strong> - Must be maintained at all times for SPSV licensing</li>
          </ul>
          
          <h3>Financial Management Tips</h3>
          <p>To maintain healthy finances in your SPSV business:</p>
          <ul>
            <li>Consider using accounting software or apps specifically designed for taxi operators</li>
            <li>Maintain separate business and personal bank accounts</li>
            <li>Set aside money regularly for tax payments and large annual expenses</li>
            <li>Review your income and expenses monthly to identify trends or issues</li>
            <li>Consider working with an accountant familiar with the SPSV industry</li>
            <li>Keep all receipts for business expenses for at least six years</li>
            <li>Budget for vehicle replacement and major maintenance</li>
          </ul>
          
          <p>Good financial management not only keeps you compliant with tax obligations but also helps maximize profitability and plan for future business development.</p>
        `,
        keyPoints: [
          "Maintain detailed records of journeys, income, and expenses",
          "Understand your tax obligations as a self-employed person",
          "Consider using specialised accounting software for SPSV operators",
          "Keep business and personal finances separate"
        ]
      },
      {
        title: "Working Hours and Work-Life Balance",
        content: `
          <p>Managing working hours effectively is crucial for maintaining health, safety, and a sustainable SPSV business.</p>
          
          <h3>Working Time Regulations</h3>
          <p>While self-employed SPSV operators have flexibility in setting their hours, you should be aware of:</p>
          <ul>
            <li>The Road Transport Working Time Directive, which provides guidelines on safe working hours</li>
            <li>The importance of adequate rest periods to prevent fatigue-related accidents</li>
            <li>The legal obligation to be fit to drive at all times</li>
          </ul>
          
          <h3>Planning Your Working Schedule</h3>
          <p>When establishing your working pattern, consider:</p>
          <ul>
            <li><strong>Peak Demand Periods</strong> - Typically include:
              <ul>
                <li>Weekday morning and evening commuter hours</li>
                <li>Friday and Saturday nights</li>
                <li>Major events and holidays</li>
                <li>Airport transfer times based on flight schedules</li>
              </ul>
            </li>
            <li><strong>Rest Breaks</strong> - Schedule regular breaks during shifts to remain alert</li>
            <li><strong>Weekly Pattern</strong> - Determine which days you will work and which will be rest days</li>
            <li><strong>Annual Planning</strong> - Schedule holidays and maintenance periods in advance</li>
          </ul>
          
          <h3>Preventing Driver Fatigue</h3>
          <p>Driver fatigue is a serious safety risk. To manage fatigue:</p>
          <ul>
            <li>Limit continuous driving periods to no more than 2-3 hours without a break</li>
            <li>Take at least a 15-minute break after every few hours of work</li>
            <li>Aim for at least 11 hours of rest between shifts</li>
            <li>Be aware of the warning signs of fatigue (yawning, heavy eyelids, difficulty concentrating)</li>
            <li>Never drive when excessively tired, regardless of potential fare income</li>
            <li>Maintain a healthy diet and stay hydrated during shifts</li>
          </ul>
          
          <h3>Work-Life Balance</h3>
          <p>Maintaining a healthy work-life balance is essential for long-term success:</p>
          <ul>
            <li>Set clear boundaries between work time and personal time</li>
            <li>Schedule regular days off and stick to them</li>
            <li>Communicate your working pattern to family and friends</li>
            <li>Consider the impact of night work or weekend work on family life</li>
            <li>Build in time for physical exercise and relaxation</li>
            <li>Remember that excessive hours may increase income in the short term but can lead to burnout</li>
          </ul>
        `,
        keyPoints: [
          "Plan working hours around peak demand periods for maximum efficiency",
          "Take regular breaks to prevent driver fatigue",
          "Aim for at least 11 hours of rest between shifts",
          "Set clear boundaries between work and personal time"
        ]
      },
      {
        title: "Ongoing Professional Development",
        content: `
          <p>Continuous improvement and professional development are important for long-term success in the SPSV industry.</p>
          
          <h3>Staying Updated with Regulations</h3>
          <p>The regulatory framework for SPSVs evolves over time. To stay informed:</p>
          <ul>
            <li>Regularly check the NTA website for updates to SPSV regulations</li>
            <li>Subscribe to the NTA's email newsletters or updates</li>
            <li>Join industry associations that provide regulatory updates</li>
            <li>Attend information sessions held by the NTA when available</li>
            <li>Review updated versions of the SPSV industry information guide</li>
          </ul>
          
          <h3>Skills Development</h3>
          <p>Consider developing additional skills to enhance your service:</p>
          <ul>
            <li><strong>Customer Service</strong> - Specialized training in hospitality and service excellence</li>
            <li><strong>Route Knowledge</strong> - Continuous improvement of your knowledge of local areas, attractions, and efficient routes</li>
            <li><strong>Language Skills</strong> - Basic phrases in common foreign languages can enhance service for tourists</li>
            <li><strong>First Aid</strong> - Knowledge of emergency procedures and basic first aid</li>
            <li><strong>Accessibility Training</strong> - Enhanced skills for assisting passengers with disabilities</li>
            <li><strong>Eco-Driving</strong> - Techniques to reduce fuel consumption and environmental impact</li>
          </ul>
          
          <h3>Business Development</h3>
          <p>To grow and improve your SPSV business:</p>
          <ul>
            <li>Seek feedback from passengers to identify areas for improvement</li>
            <li>Network with other SPSV operators to share best practices</li>
            <li>Consider specialised markets or services that may be underserved</li>
            <li>Investigate new technologies that can enhance efficiency</li>
            <li>Review your business model periodically to ensure it remains competitive</li>
            <li>Stay informed about emerging trends in transportation and mobility</li>
          </ul>
          
          <p>Investing in your professional development not only improves the quality of service you provide but can also open up new business opportunities and increase customer loyalty.</p>
        `,
        keyPoints: [
          "Regularly check for updates to SPSV regulations",
          "Consider formal training in customer service and accessibility",
          "Seek passenger feedback to identify areas for improvement",
          "Stay informed about industry trends and new technologies"
        ]
      }
    ],
    vehicleSpecificContent: {
      "limousine": {
        additionalContent: `
          <p>Operating a limousine service has specific considerations that differ from standard taxi or hackney operations:</p>
          
          <h3>Service Expectations</h3>
          <p>Limousine customers typically expect:</p>
          <ul>
            <li>A higher level of professionalism and formal service</li>
            <li>Drivers dressed in professional attire (often a suit or uniform)</li>
            <li>Exceptional vehicle cleanliness and presentation</li>
            <li>Additional amenities such as bottled water or refreshment options</li>
            <li>Punctuality and reliability for scheduled services</li>
            <li>Knowledge of protocol for formal events such as weddings or corporate functions</li>
          </ul>
          
          <h3>Business Model</h3>
          <p>Limousine operations typically focus on:</p>
          <ul>
            <li>Pre-booked services with advance reservations</li>
            <li>Higher-value, longer duration bookings</li>
            <li>Special occasion services (weddings, proms, corporate events)</li>
            <li>Airport transfers for business travelers or VIPs</li>
            <li>Tourism services for luxury travelers</li>
            <li>Corporate accounts with regular business clients</li>
          </ul>
          
          <p>Pricing is generally structured differently from taxis, often based on hourly rates with minimum booking durations rather than metered fares.</p>
        `,
        additionalKeyPoints: [
          "Limousine services require higher standards of professional presentation",
          "Focus on pre-booked special occasions and corporate services",
          "Pricing typically uses hourly rates rather than metered fares",
          "Customer expectations are higher for service quality and vehicle presentation"
        ]
      },
      "wheelchair_accessible_taxi": {
        additionalContent: `
          <p>Operating a wheelchair accessible taxi (WAT) involves additional considerations:</p>
          
          <h3>Passenger Assistance</h3>
          <p>WAT drivers should be proficient in:</p>
          <ul>
            <li>Operating ramps, lifts, and wheelchair restraint systems safely</li>
            <li>Assisting passengers to enter and exit the vehicle safely</li>
            <li>Securing different types of wheelchairs and mobility aids</li>
            <li>Communication techniques for passengers with various disabilities</li>
            <li>Understanding the needs of passengers with different types of mobility impairments</li>
          </ul>
          
          <h3>Business Considerations</h3>
          <p>WAT operations have specific business aspects:</p>
          <ul>
            <li>Priority must be given to wheelchair users when plying for hire</li>
            <li>Many WAT operators develop relationships with healthcare facilities, disability organisations, and transport assistance programs</li>
            <li>Journey times may be longer to accommodate loading and securing wheelchairs</li>
            <li>Regular maintenance of accessibility equipment is essential</li>
            <li>Additional training may be beneficial to provide optimal service</li>
          </ul>
          
          <p>While operating costs may be higher for WAT vehicles, there are incentives including reduced licence fees and grant support from the NTA.</p>
        `,
        additionalKeyPoints: [
          "WAT drivers need specialised skills for assisting passengers with disabilities",
          "Accessibility equipment must be regularly maintained and tested",
          "Healthcare facilities and disability organisations can provide regular bookings",
          "WAT services provide an essential transportation option for the community"
        ]
      }
    }
  },
  
  // Module 6: Finding Your Way Around
  6: {
    pages: [
      {
        title: "Navigation Skills and Resources",
        content: `
          <p>Effective navigation is a core skill for SPSV operators. Customers expect drivers to know the most efficient routes and to navigate confidently without excessive reliance on GPS systems.</p>
          
          <h3>Essential Navigation Resources</h3>
          <p>As an SPSV driver, you should be familiar with and have access to:</p>
          <ul>
            <li>Detailed street maps of your operating area</li>
            <li>GPS navigation systems (as a backup, not primary resource)</li>
            <li>Knowledge of one-way systems and traffic restrictions</li>
            <li>Alternative routes for busy periods or road closures</li>
            <li>Location of key destinations such as hotels, hospitals, and transport hubs</li>
          </ul>
          
          <p>While technology can assist with navigation, SPSV drivers are expected to have personal knowledge of their operating area. This is particularly important in areas with poor GPS reception or where recent road changes may not be reflected in navigation systems.</p>
        `,
        keyPoints: [
          "Personal knowledge of the area is more reliable than GPS",
          "Familiarize yourself with one-way systems and traffic restrictions",
          "Know the location of major landmarks and transport hubs",
          "Have alternative routes prepared for busy periods"
        ]
      },
      {
        title: "Understanding Street Layouts and Patterns",
        content: `
          <p>Developing a mental map of your operating area is crucial for efficient navigation. This involves understanding the underlying structure and patterns of the street network.</p>
          
          <h3>Urban Street Patterns</h3>
          <p>Cities and towns in Ireland typically have one of several street patterns:</p>
          <ul>
            <li><strong>Grid System</strong> - Found in some newer developments and parts of Dublin</li>
            <li><strong>Radial Pattern</strong> - Streets radiating from a central point with connecting ring roads</li>
            <li><strong>Organic/Medieval Layout</strong> - Irregular street patterns common in older town centers</li>
            <li><strong>Linear Development</strong> - Towns developed along a main road with side streets</li>
          </ul>
          
          <h3>Addressing Systems</h3>
          <p>Understanding how addresses work in your area is essential:</p>
          <ul>
            <li>In many areas, buildings are numbered sequentially along a street</li>
            <li>Odd numbers are typically on one side, even on the other</li>
            <li>In some areas, numbering is based on when buildings were constructed</li>
            <li>Rural areas often use townland names rather than street addresses</li>
          </ul>
          
          <p>Developing familiarity with local naming conventions and address formats will help you locate destinations more efficiently, especially when GPS coordinates are not precise.</p>
        `,
        keyPoints: [
          "Understand the different street patterns in your operating area",
          "Learn how building numbering works on different streets",
          "Rural addressing often uses townlands rather than street numbers",
          "Develop a mental map of your operating area's layout"
        ]
      },
      {
        title: "Key Landmarks and Points of Interest",
        content: `
          <p>A thorough knowledge of landmarks and points of interest is fundamental to working effectively as an SPSV driver. Customers often refer to well-known locations rather than specific addresses.</p>
          
          <h3>Categories of Important Locations</h3>
          <p>You should be familiar with the location of:</p>
          <ul>
            <li><strong>Transport Hubs</strong> - Airports, train stations, bus stations, ferry terminals</li>
            <li><strong>Accommodation</strong> - Major hotels, hostels, and guest houses</li>
            <li><strong>Healthcare Facilities</strong> - Hospitals, clinics, health centres</li>
            <li><strong>Entertainment Venues</strong> - Theaters, concert halls, sports stadiums, nightclubs</li>
            <li><strong>Shopping Areas</strong> - Shopping centres, markets, retail parks</li>
            <li><strong>Business Districts</strong> - Office parks, convention centres, industrial estates</li>
            <li><strong>Educational Institutions</strong> - Universities, colleges, schools</li>
            <li><strong>Tourist Attractions</strong> - Museums, historic sites, natural landmarks</li>
            <li><strong>Government Buildings</strong> - Council offices, courts, embassies</li>
          </ul>
          
          <p>For each major point of interest, you should also know the best drop-off and pick-up points, particularly for busy locations where stopping may be restricted.</p>
        `,
        keyPoints: [
          "Know the location of major transport hubs and how to access them",
          "Be familiar with popular hotels, entertainment venues, and tourist sites",
          "Learn appropriate drop-off and pick-up points for busy locations",
          "Understand where parking and stopping restrictions apply"
        ]
      },
      {
        title: "Traffic Patterns and Congestion Management",
        content: `
          <p>Understanding traffic patterns and knowing how to manage congestion efficiently is key to providing good service and maximizing your earning potential.</p>
          
          <h3>Time-Based Traffic Patterns</h3>
          <p>Traffic generally follows predictable patterns based on time:</p>
          <ul>
            <li><strong>Morning Rush Hour</strong> - Typically 7:30-9:30 AM, with traffic flowing into business districts</li>
            <li><strong>Evening Rush Hour</strong> - Typically 4:30-6:30 PM, with traffic flowing out of business districts</li>
            <li><strong>School Run Times</strong> - Around 8:30 AM and 2:30-3:30 PM near schools</li>
            <li><strong>Weekend Patterns</strong> - Shopping areas busy on Saturdays, while Sunday mornings are typically quiet</li>
            <li><strong>Event Times</strong> - Concerts, sports events, and conferences create localized congestion</li>
          </ul>
          
          <h3>Strategies for Managing Congestion</h3>
          <p>To navigate efficiently during busy periods:</p>
          <ul>
            <li>Develop alternative routes that avoid known bottlenecks</li>
            <li>Stay informed about roadworks and temporary closures</li>
            <li>Use real-time traffic information from radio updates or apps</li>
            <li>Learn the timing of traffic lights on major routes</li>
            <li>Consider using bus lanes where permitted for taxis</li>
            <li>Factor in seasonal variations (tourist season, holidays)</li>
          </ul>
          
          <p>Being able to navigate efficiently during congestion not only improves customer satisfaction but also increases the number of fares you can complete in a shift.</p>
        `,
        keyPoints: [
          "Understand predictable traffic patterns based on time of day",
          "Develop alternative routes to avoid known bottlenecks",
          "Stay informed about roadworks and temporary closures",
          "Consider using bus lanes where permitted for taxis"
        ]
      },
      {
        title: "Area Knowledge Test Preparation",
        content: `
          <p>The Area Knowledge Test is a key component of the SPSV Driver Entry Test. This test assesses your knowledge of the geographic area in which you intend to operate.</p>
          
          <h3>Test Format</h3>
          <p>The Area Knowledge Test typically includes:</p>
          <ul>
            <li>Questions about the location of key landmarks and amenities</li>
            <li>Route planning scenarios between different locations</li>
            <li>Identification of major roads and transport links</li>
            <li>Questions about one-way systems and traffic restrictions</li>
            <li>Knowledge of suburbs and districts within the test area</li>
          </ul>
          
          <h3>Preparation Strategies</h3>
          <p>To prepare effectively for the Area Knowledge Test:</p>
          <ul>
            <li>Obtain detailed maps of your chosen area and study them regularly</li>
            <li>Drive or walk around the area systematically to familiarize yourself with the street layout</li>
            <li>Create flashcards of key landmarks and their locations</li>
            <li>Practice planning routes between common destinations</li>
            <li>Learn the names and locations of suburbs, districts, and housing estates</li>
            <li>Study the location of hospitals, hotels, shopping centers, and transport hubs</li>
            <li>Join study groups with other candidates preparing for the same area test</li>
          </ul>
          
          <p>Remember that the depth of knowledge required will depend on the size and complexity of your chosen operating area. Dublin, for example, requires more extensive knowledge than smaller towns.</p>
        `,
        keyPoints: [
          "The Area Knowledge Test covers landmarks, routes, and traffic systems",
          "Systematic study of maps is essential for test preparation",
          "Physical exploration of the area helps build practical knowledge",
          "Focus on hospitals, hotels, transport hubs, and entertainment venues"
        ]
      }
    ],
    vehicleSpecificContent: {
      "taxi": {
        additionalContent: `
          <p>As a taxi driver, extensive area knowledge is especially important since you can be hailed on the street by passengers who expect you to know the way to their destination immediately. Consider these taxi-specific points:</p>
          
          <ul>
            <li>Be particularly familiar with the location of all official taxi ranks in your area</li>
            <li>Know which areas have high demand at different times of day</li>
            <li>Be aware of which bus lanes taxis are permitted to use and at what times</li>
            <li>Learn the best drop-off points at busy locations that allow for quick access while staying legal</li>
            <li>Understand rules for queueing at designated taxi ranks</li>
            <li>Be familiar with the regulations about when you can refuse a fare</li>
            <li>Know the maximum distances for which you are obliged to accept a fare</li>
          </ul>
        `,
        additionalKeyPoints: [
          "Know all official taxi ranks in your area",
          "Learn which bus lanes are available for taxi use",
          "Be familiar with high-demand areas at different times",
          "Understand legal stopping points for passenger drop-offs",
          "Know regulations about accepting and refusing fares"
        ]
      },
      "limousine": {
        additionalContent: `
          <p>As a limousine operator, your navigation skills are particularly important as you are often providing service for special occasions or to clients with high expectations:</p>
          
          <ul>
            <li>Research pickup and drop-off protocols at exclusive venues, such as five-star hotels and upscale restaurants</li>
            <li>Be familiar with VIP entrances at venues, theaters, and concert halls</li>
            <li>Know alternate scenic routes that might be appropriate for special occasions</li>
            <li>Be aware of roads that may be unsuitable for longer vehicles</li>
            <li>Research parking locations that can accommodate larger vehicles at key destinations</li>
            <li>Pre-plan routes for scenic drives or special occasion journeys</li>
            <li>Understand turning radius limitations for stretched limousines</li>
          </ul>
          
          <p>Limousine drivers should also maintain a database of client preferences for routes and venues, as repeat business is common in the luxury transport segment.</p>
        `,
        additionalKeyPoints: [
          "Be familiar with VIP entrances at key venues",
          "Know scenic routes appropriate for special occasions",
          "Be aware of roads unsuitable for longer vehicles",
          "Maintain records of client route preferences",
          "Pre-plan routes for special occasion journeys"
        ]
      },
      "hackney": {
        additionalContent: `
          <p>As a hackney operator, your navigation skills have their own specific requirements:</p>
          
          <ul>
            <li>Focus on efficiently covering your pre-booked journeys</li>
            <li>Be familiar with popular destinations requested by regular clients</li>
            <li>Know efficient waiting locations between pre-booked jobs</li>
            <li>Be aware of suburban and rural addresses that may be challenging to locate</li>
            <li>Understand how to navigate to non-standard addresses, including townlands</li>
          </ul>
          
          <p>Unlike taxis, hackneys cannot ply for hire on the street or use taxi ranks, so your navigation strategy must focus on pre-booked journeys and efficient route planning.</p>
        `,
        additionalKeyPoints: [
          "Focus on pre-booked journeys and efficient route planning",
          "Know efficient waiting locations between bookings",
          "Be familiar with challenging suburban and rural addresses",
          "Understand navigation to non-standard addresses and townlands"
        ]
      },
      "wheelchair_accessible": {
        additionalContent: `
          <p>As an operator of a wheelchair accessible vehicle, your navigation skills need to account for accessibility concerns:</p>
          
          <ul>
            <li>Know accessible entrances and exits at major buildings and facilities</li>
            <li>Be aware of which locations have adequate space for ramp or lift deployment</li>
            <li>Understand which routes may be problematic for passengers with motion sensitivity</li>
            <li>Be familiar with healthcare facilities and their specific pickup/dropoff points</li>
            <li>Know which attractions, hotels, and venues are fully accessible</li>
          </ul>
          
          <p>Your specialised knowledge of accessible routes and facilities is a key part of providing excellent service to passengers with mobility requirements.</p>
        `,
        additionalKeyPoints: [
          "Know accessible entrances at major buildings",
          "Be aware of locations with adequate space for ramp deployment",
          "Understand routes that minimize motion discomfort",
          "Be familiar with healthcare facility pickup points"
        ]
      }
    }
  },
  
  // Module 7: Fares
  7: {
    pages: [
      {
        title: "Fare Structure and Regulations",
        content: `
          <p>Understanding the fare structure and regulations is fundamental to operating legally and professionally as an SPSV driver in Ireland. Different rules apply to different types of SPSVs.</p>
          
          <h3>Taxi Fare Regulation</h3>
          <p>For taxis, fares are regulated through the National Maximum Taxi Fare, which:</p>
          <ul>
            <li>Sets the maximum rates that can be charged</li>
            <li>Must be calculated using a taximeter</li>
            <li>Varies based on time of day, distance traveled, and waiting time</li>
            <li>Is reviewed periodically by the NTA</li>
          </ul>
          
          <p>The National Maximum Taxi Fare includes:</p>
          <ul>
            <li><strong>Initial charge</strong> - Applied at the start of the journey</li>
            <li><strong>Distance rate</strong> - Charged per kilometer traveled</li>
            <li><strong>Time rate</strong> - Applied when the taxi is stationary or moving slowly</li>
            <li><strong>Premium rates</strong> - Higher rates for unsocial hours (8pm-8am) and certain days (Sundays and public holidays)</li>
            <li><strong>Extra charges</strong> - Additional passengers beyond the first, certain booking methods</li>
          </ul>
          
          <h3>Hackney and Limousine Fares</h3>
          <p>For hackneys and limousines:</p>
          <ul>
            <li>Fares are not regulated by a maximum fare structure</li>
            <li>The fare must be agreed with the customer before the journey begins</li>
            <li>No taximeter is used or permitted</li>
            <li>A written receipt must be provided if requested</li>
          </ul>
          
          <p>All SPSV operators must provide a receipt when requested, showing details of the journey, fare, and vehicle licence number.</p>
        `,
        keyPoints: [
          "Taxi fares are regulated by the National Maximum Taxi Fare",
          "Hackneys and limousines must agree fares in advance",
          "Premium rates apply during unsocial hours for taxis",
          "Receipts must be provided for all journeys when requested"
        ]
      },
      {
        title: "Taximeter Operation and Maintenance",
        content: `
          <p>For taxi operators, proper taximeter operation and maintenance is both a legal requirement and essential for accurate fare calculation.</p>
          
          <h3>Taximeter Requirements</h3>
          <p>All taximeters must:</p>
          <ul>
            <li>Be of a type approved by the Legal Metrology Service</li>
            <li>Be calibrated to the current National Maximum Taxi Fare</li>
            <li>Be verified and sealed by the Legal Metrology Service</li>
            <li>Be programmed with the correct vehicle registration</li>
            <li>Be capable of printing receipts</li>
            <li>Display the fare clearly to the passenger</li>
          </ul>
          
          <h3>Taximeter Operation</h3>
          <p>When operating a taximeter:</p>
          <ul>
            <li>Start the meter at the beginning of the journey (when the passenger enters or when you arrive at a pre-booked pickup)</li>
            <li>Ensure the correct tariff is applied based on time of day and day of week</li>
            <li>Only apply extra charges as permitted (additional passengers, pre-booking)</li>
            <li>Stop the meter when you reach the destination</li>
            <li>Allow the passenger to view the final fare before payment</li>
            <li>Provide a printed receipt when requested</li>
          </ul>
          
          <h3>Taximeter Maintenance and Verification</h3>
          <p>To maintain compliance:</p>
          <ul>
            <li>Have your taximeter verified annually by the Legal Metrology Service</li>
            <li>After verification, the meter will be sealed to prevent tampering</li>
            <li>Schedule reverification whenever fare structures change</li>
            <li>Ensure the taximeter is functioning correctly at all times</li>
            <li>If the taximeter malfunctions, do not use the vehicle as a taxi until it is repaired and verified</li>
          </ul>
          
          <p>Operating without a properly functioning and verified taximeter is a serious offence that can result in penalties and licence suspension.</p>
        `,
        keyPoints: [
          "Taximeters must be approved, verified, and sealed",
          "The meter must be started at the beginning of each journey",
          "Taximeters must be verified annually and after fare structure changes",
          "Operating without a properly functioning taximeter is an offence"
        ]
      },
      {
        title: "Payment Methods and Processing",
        content: `
          <p>Modern SPSV operators must be able to accept a variety of payment methods to meet customer expectations and regulatory requirements.</p>
          
          <h3>Card Payment Requirements</h3>
          <p>Since 2019, all taxis in Ireland are required to:</p>
          <ul>
            <li>Accept payment by credit and debit card</li>
            <li>Have a functioning payment terminal in the vehicle</li>
            <li>Not impose surcharges for card payments</li>
            <li>Still accept cash for those who prefer it</li>
          </ul>
          
          <p>While card payment is mandatory for taxis, it is also recommended for hackney and limousine operators to meet customer expectations.</p>
          
          <h3>Payment Options</h3>
          <p>Common payment methods in the SPSV industry include:</p>
          <ul>
            <li><strong>Cash</strong> - Still commonly used and must be accepted</li>
            <li><strong>Credit/Debit Cards</strong> - Physical card payments processed through a terminal</li>
            <li><strong>Contactless Payments</strong> - Including cards and mobile wallets (Apple Pay, Google Pay)</li>
            <li><strong>App-Based Payments</strong> - Through dispatch operator apps</li>
            <li><strong>Corporate Accounts</strong> - For business clients, often with monthly billing</li>
          </ul>
          
          <h3>Payment Processing Tips</h3>
          <p>To ensure smooth payment processing:</p>
          <ul>
            <li>Test your payment terminal at the start of each shift</li>
            <li>Ensure you have a mobile data connection for card processing</li>
            <li>Have a backup payment solution if your primary terminal fails</li>
            <li>Keep adequate change for cash payments</li>
            <li>Be familiar with how to process refunds if necessary</li>
            <li>Store all transaction receipts securely</li>
            <li>Reconcile payments at the end of each shift</li>
          </ul>
          
          <p>Having reliable payment processing not only ensures compliance but also enhances customer satisfaction and can lead to better tips and repeat business.</p>
        `,
        keyPoints: [
          "Taxis must accept card payments by law",
          "No surcharges can be applied for card payments",
          "Test payment terminals at the start of each shift",
          "Have a backup payment solution available"
        ]
      },
      {
        title: "Setting Fares for Hackney and Limousine Services",
        content: `
          <p>Unlike taxis, hackneys and limousines are not subject to the National Maximum Taxi Fare. This gives operators flexibility, but also requires careful consideration when setting prices.</p>
          
          <h3>Factors to Consider When Setting Fares</h3>
          <p>When determining your fare structure, consider:</p>
          <ul>
            <li><strong>Operating Costs</strong> - Fuel, vehicle maintenance, insurance, licensing</li>
            <li><strong>Time Commitment</strong> - Duration of the service including waiting time</li>
            <li><strong>Distance</strong> - Total kilometers to be covered</li>
            <li><strong>Service Level</strong> - Premium services can command higher rates</li>
            <li><strong>Market Rates</strong> - Competitive pricing in your area</li>
            <li><strong>Time of Day/Week</strong> - Peak times may warrant premium pricing</li>
            <li><strong>Client Type</strong> - Regular clients might receive preferential rates</li>
          </ul>
          
          <h3>Common Pricing Models</h3>
          <p>Hackney and limousine operators typically use one of several pricing approaches:</p>
          <ul>
            <li><strong>Fixed Point-to-Point Rates</strong> - Set prices for common journeys</li>
            <li><strong>Distance-Based Pricing</strong> - Per-kilometer rate with minimum fare</li>
            <li><strong>Hourly Rates</strong> - Common for limousines and waiting services</li>
            <li><strong>Package Rates</strong> - For special events like weddings or tours</li>
            <li><strong>Zone-Based Pricing</strong> - Fixed rates between defined zones</li>
          </ul>
          
          <h3>Communicating Your Fares</h3>
          <p>It's essential to:</p>
          <ul>
            <li>Clearly communicate the fare before the journey begins</li>
            <li>Have a written price list for common journeys</li>
            <li>Be transparent about any additional charges</li>
            <li>Provide detailed quotations for pre-bookings</li>
            <li>Confirm the price when the booking is made</li>
          </ul>
          
          <p>Remember that while you have flexibility in setting fares, they should be reasonable and transparent. Building a reputation for fair pricing will lead to repeat business and recommendations.</p>
        `,
        keyPoints: [
          "Consider operating costs, time, and distance when setting fares",
          "Choose a pricing model that suits your business type",
          "Always agree on the fare before the journey begins",
          "Be transparent about all charges"
        ]
      },
      {
        title: "Handling Fare Disputes",
        content: `
          <p>Occasionally, disputes about fares may arise with passengers. Handling these situations professionally is important for maintaining a good reputation and avoiding escalation.</p>
          
          <h3>Common Causes of Fare Disputes</h3>
          <p>Fare disputes typically arise from:</p>
          <ul>
            <li>Misunderstandings about the route taken</li>
            <li>Confusion about the initial agreement (for hackneys/limousines)</li>
            <li>Passengers unfamiliar with the fare structure</li>
            <li>Issues with payment methods</li>
            <li>Additional charges not explained in advance</li>
            <li>Taximeter operation concerns</li>
          </ul>
          
          <h3>Preventing Fare Disputes</h3>
          <p>The best approach is to prevent disputes before they occur:</p>
          <ul>
            <li>For taxis: explain how the meter works if asked</li>
            <li>For hackneys/limousines: clearly agree on the fare before starting</li>
            <li>Clarify any potential additional charges in advance</li>
            <li>Discuss route options if relevant</li>
            <li>Confirm which payment methods you accept</li>
            <li>Keep your taximeter visible to the passenger</li>
          </ul>
          
          <h3>Resolving Disputes Professionally</h3>
          <p>If a dispute does arise:</p>
          <ul>
            <li>Remain calm and professional at all times</li>
            <li>Listen to the passenger's concerns without interrupting</li>
            <li>Explain the fare calculation clearly</li>
            <li>Show relevant documentation (meter readings, pre-agreed fare)</li>
            <li>Offer a receipt with all journey details</li>
            <li>Consider a reasonable compromise if appropriate</li>
            <li>If necessary, contact a supervisor or the Gardaí</li>
            <li>Keep records of any significant disputes</li>
          </ul>
          
          <p>Remember that a small discount in a disputed situation may be worthwhile to maintain your reputation and avoid a formal complaint. Your primary goal should be to resolve the situation calmly and professionally.</p>
        `,
        keyPoints: [
          "Prevent disputes by being clear about fares in advance",
          "Remain calm and professional if disputes arise",
          "Explain fare calculations clearly and provide documentation",
          "Consider reasonable compromises to prevent escalation"
        ]
      }
    ],
    vehicleSpecificContent: {
      "taxi": {
        additionalContent: `
          <p>As a taxi operator, your fares are regulated by the National Maximum Taxi Fare. Some specific considerations for taxi drivers include:</p>
          
          <ul>
            <li>Ensure you understand the different tariff rates for day/night and weekday/weekend operation</li>
            <li>Be familiar with the rules regarding extra charges for additional passengers or pre-booking</li>
            <li>Keep up to date with any changes to the National Maximum Taxi Fare structure</li>
            <li>Be prepared to explain the fare structure to tourists or visitors unfamiliar with the system</li>
          </ul>
          
          <p>It's important to remember that while the National Maximum Taxi Fare sets the maximum you can charge, you may charge less at your discretion.</p>
        `,
        additionalKeyPoints: [
          "Understand all tariff rates and when they apply",
          "Keep up-to-date with any changes to fare regulations",
          "Be prepared to explain the fare structure to visitors",
          "You may charge less than the maximum fare at your discretion"
        ]
      },
      "limousine": {
        additionalContent: `
          <p>Limousine services typically command premium pricing due to the luxury nature of the service and the higher operating costs involved.</p>
          
          <ul>
            <li>Most limousine services operate on an hourly rate basis with a minimum booking duration (typically 2-3 hours)</li>
            <li>A non-refundable deposit is often required for bookings, especially for high-demand dates</li>
            <li>Package rates are common for special events such as weddings, proms, and corporate functions</li>
            <li>Additional services such as decorations, refreshments, or specific routes may incur extra charges</li>
            <li>Seasonal pricing may apply, with higher rates during wedding season or for New Year's Eve</li>
          </ul>
          
          <p>When pricing limousine services, it's important to factor in not just the journey time but also preparation time, waiting time, and the higher maintenance costs of luxury vehicles.</p>
        `,
        additionalKeyPoints: [
          "Limousine services typically charge hourly rates with minimums",
          "Deposits are standard practice for advance bookings",
          "Package pricing works well for special events",
          "Factor in preparation and waiting time when calculating costs"
        ]
      }
    }
  },
  
  // Module 8: Delivering Customer Satisfaction
  8: {
    pages: [
      {
        title: "Customer Service Fundamentals",
        content: `
          <p>Exceptional customer service is a key differentiator in the SPSV industry. Passengers have choices, and their experience with you will determine whether they become repeat customers or recommend your service to others.</p>
          
          <h3>Core Customer Service Principles</h3>
          <p>Excellent SPSV customer service is built on:</p>
          <ul>
            <li><strong>Professionalism</strong> - In appearance, behavior, and communication</li>
            <li><strong>Reliability</strong> - Being on time and fulfilling commitments</li>
            <li><strong>Safety</strong> - Ensuring passengers feel and are safe throughout their journey</li>
            <li><strong>Courtesy</strong> - Treating all passengers with respect and consideration</li>
            <li><strong>Attentiveness</strong> - Being responsive to passenger needs and preferences</li>
            <li><strong>Knowledge</strong> - Demonstrating expertise in routes and local information</li>
          </ul>
          
          <h3>First Impressions</h3>
          <p>The first impression you create is crucial:</p>
          <ul>
            <li>Maintain a clean, well-presented vehicle inside and out</li>
            <li>Ensure your personal appearance is professional and neat</li>
            <li>Greet passengers promptly and courteously</li>
            <li>Confirm the destination and preferred route if applicable</li>
            <li>Assist with luggage if needed</li>
            <li>Ensure the interior temperature is comfortable</li>
          </ul>
          
          <p>Remember that for many visitors, SPSV drivers are among the first locals they interact with, making you an ambassador for your community and country.</p>
        `,
        keyPoints: [
          "First impressions are crucial for customer satisfaction",
          "Maintain professional appearance and vehicle cleanliness",
          "Reliability and safety are foundational to good service",
          "You represent your community to visitors"
        ]
      },
      {
        title: "Communication Skills",
        content: `
          <p>Effective communication is essential for providing excellent customer service and avoiding misunderstandings.</p>
          
          <h3>Verbal Communication</h3>
          <p>When speaking with passengers:</p>
          <ul>
            <li>Use clear, polite language</li>
            <li>Avoid industry jargon or slang that passengers may not understand</li>
            <li>Speak at an appropriate volume and pace</li>
            <li>Confirm understanding of destinations and instructions</li>
            <li>Be mindful of tone, which can convey as much as the words themselves</li>
            <li>Listen actively to passenger requests and questions</li>
          </ul>
          
          <h3>Non-Verbal Communication</h3>
          <p>Your body language and behavior also communicate:</p>
          <ul>
            <li>Maintain appropriate eye contact when not driving</li>
            <li>Present a positive, welcoming facial expression</li>
            <li>Use professional gestures and posture</li>
            <li>Be aware of personal space and cultural differences</li>
            <li>Demonstrate attention through nodding and appropriate responses</li>
          </ul>
          
          <h3>Communication Challenges</h3>
          <p>Be prepared to handle communication challenges:</p>
          <ul>
            <li><strong>Language Barriers</strong> - Have simple phrases in common languages, use maps or visual aids</li>
            <li><strong>Hearing Impairments</strong> - Be prepared to write down information if needed</li>
            <li><strong>Conflict Situations</strong> - Stay calm, listen, and focus on solutions</li>
            <li><strong>Intoxicated Passengers</strong> - Speak clearly and simply, avoid arguments</li>
          </ul>
          
          <p>Remember that communication is two-way. Being attentive to passenger cues about whether they wish to chat or prefer a quiet journey is an important part of good service.</p>
        `,
        keyPoints: [
          "Use clear, polite language and avoid industry jargon",
          "Be aware of your tone and body language",
          "Listen actively to passengers' needs and preferences",
          "Be prepared to adapt communication for different needs"
        ]
      },
      {
        title: "Meeting Special Customer Needs",
        content: `
          <p>SPSV passengers have diverse needs, and providing inclusive service is both a professional responsibility and a legal requirement in many cases.</p>
          
          <h3>Passengers with Mobility Impairments</h3>
          <p>When assisting passengers with mobility impairments:</p>
          <ul>
            <li>Ask how you can best assist - don't assume what help is needed</li>
            <li>Be patient and allow extra time for boarding and alighting</li>
            <li>Know how to safely stow mobility aids like canes or walkers</li>
            <li>For wheelchair users (in accessible vehicles), know proper securing procedures</li>
            <li>Park in locations that allow safe and easy access to the vehicle</li>
          </ul>
          
          <h3>Passengers with Visual Impairments</h3>
          <p>For passengers with visual impairments:</p>
          <ul>
            <li>Identify yourself clearly when they approach</li>
            <li>Ask if they would like physical guidance to the vehicle</li>
            <li>Describe key information about the journey</li>
            <li>Ensure guide dogs have adequate space</li>
            <li>Provide verbal cues about arrival at destination</li>
          </ul>
          
          <h3>Passengers with Hearing Impairments</h3>
          <p>When communicating with passengers with hearing impairments:</p>
          <ul>
            <li>Face the passenger when speaking to allow lip reading</li>
            <li>Speak clearly but don't shout or exaggerate mouth movements</li>
            <li>Have a pen and paper available for written communication</li>
            <li>Use visual cues and gestures as appropriate</li>
          </ul>
          
          <h3>Other Special Requirements</h3>
          <p>Be prepared to accommodate:</p>
          <ul>
            <li>Elderly passengers who may need additional time or assistance</li>
            <li>Parents with young children who may need help with car seats</li>
            <li>Passengers with large or unusual luggage</li>
            <li>Individuals with temporary injuries or conditions</li>
          </ul>
          
          <p>Providing excellent service to passengers with special needs not only fulfills your legal obligations but also expands your potential customer base and demonstrates your professionalism.</p>
        `,
        keyPoints: [
          "Ask how you can best assist rather than assuming",
          "Be patient and allow extra time when needed",
          "Guide dogs must be accommodated in all SPSVs",
          "Written communication can help with hearing impairments"
        ]
      },
      {
        title: "Building Customer Loyalty",
        content: `
          <p>Repeat business and recommendations are key to long-term success in the SPSV industry. Building customer loyalty requires consistent excellent service and strategic approaches.</p>
          
          <h3>Exceeding Expectations</h3>
          <p>To stand out from competitors:</p>
          <ul>
            <li>Arrive slightly early for pre-bookings</li>
            <li>Offer additional services like assistance with luggage</li>
            <li>Provide amenities such as bottled water or phone charging</li>
            <li>Share local knowledge and recommendations when appropriate</li>
            <li>Remember regular customers' preferences</li>
            <li>Go the extra mile when the opportunity arises</li>
          </ul>
          
          <h3>Developing Regular Customers</h3>
          <p>To encourage repeat business:</p>
          <ul>
            <li>Provide business cards with your contact details</li>
            <li>Consider offering loyalty discounts for regular users</li>
            <li>Be reliable and consistent in your service quality</li>
            <li>Follow up on pre-booking requests promptly</li>
            <li>Be flexible to accommodate regular customers' needs</li>
            <li>Maintain a database of regular customers (in compliance with data protection laws)</li>
          </ul>
          
          <h3>Encouraging Recommendations</h3>
          <p>Word-of-mouth remains powerful in the SPSV industry:</p>
          <ul>
            <li>Encourage satisfied customers to recommend your service</li>
            <li>Consider incentives for referrals</li>
            <li>Maintain profiles on review platforms like TripAdvisor or Google</li>
            <li>Respond professionally to online reviews, both positive and negative</li>
            <li>Build relationships with local businesses for referrals</li>
            <li>Develop a professional social media presence if appropriate</li>
          </ul>
          
          <p>Remember that every journey is an opportunity to create a loyal customer. The extra effort to provide exceptional service can pay dividends through repeat business and recommendations.</p>
        `,
        keyPoints: [
          "Consistently exceed expectations to build loyalty",
          "Provide business cards and easy booking methods",
          "Maintain a database of regular customers' preferences",
          "Build networks with local businesses for referrals"
        ]
      }
    ],
    vehicleSpecificContent: {
      "taxi": {
        additionalContent: `
          <p>As a taxi operator, you have specific opportunities to build customer satisfaction:</p>
          
          <ul>
            <li>Develop expert knowledge of the local area to instill confidence in passengers</li>
            <li>Ensure your meter is clearly visible and explain charges when requested</li>
            <li>Maintain a well-functioning card payment terminal at all times</li>
            <li>Consider providing small conveniences such as chargers for different phone types</li>
            <li>Be familiar with major events in your area that may affect demand and journey times</li>
          </ul>
          
          <p>Remember that for street hails, you often have just a few seconds to make a good first impression from the appearance of your vehicle and your initial greeting.</p>
        `,
        additionalKeyPoints: [
          "Ensure your meter is clearly visible and properly functioning",
          "Maintain knowledge of local events affecting travel",
          "Have a reliable card payment system",
          "Make a good impression with a clean vehicle and professional greeting"
        ]
      },
      "limousine": {
        additionalContent: `
          <p>Limousine services are distinguished by premium customer service that goes beyond the standard expectations:</p>
          
          <ul>
            <li>Formal dress is typically expected, often including a suit or uniform</li>
            <li>Higher levels of etiquette are required, including proper forms of address</li>
            <li>Opening doors for passengers is standard practice</li>
            <li>Complementary amenities are often expected (water, tissues, etc.)</li>
            <li>Prior research about passengers' preferences for temperature, music, etc. is recommended</li>
            <li>Absolute punctuality is essential - arrive at least 15 minutes early</li>
            <li>For corporate clients, maintaining confidentiality about business discussions is crucial</li>
          </ul>
          
          <p>The limousine experience begins before the passenger enters the vehicle and continues until after they have safely reached their destination. Every detail contributes to the premium service expected.</p>
        `,
        additionalKeyPoints: [
          "Formal dress and high standards of etiquette are expected",
          "Complementary amenities should be provided",
          "Arrive at least 15 minutes early for pickups",
          "Confidentiality is essential for corporate clients"
        ]
      }
    }
  },
  
  // Module 9: Vehicle Maintenance and Operations
  9: {
    pages: [
      {
        title: "Vehicle Maintenance Essentials",
        content: `
          <p>Maintaining your vehicle in excellent condition is essential for safety, reliability, and compliance with SPSV regulations. A well-maintained vehicle also creates a positive impression with customers.</p>
          
          <h3>Daily Vehicle Checks</h3>
          <p>At the start of each working day, check:</p>
          <ul>
            <li><strong>Exterior</strong> - Body condition, cleanliness, licence plate visibility</li>
            <li><strong>Lights</strong> - Headlights, indicators, brake lights, interior lighting</li>
            <li><strong>Tyres</strong> - Pressure, tread depth, visible damage</li>
            <li><strong>Fluids</strong> - Oil, water, windscreen wash</li>
            <li><strong>Brakes</strong> - Responsiveness, unusual sounds</li>
            <li><strong>Cleanliness</strong> - Interior, seats, floor mats, boot</li>
            <li><strong>SPSV Equipment</strong> - Taximeter (if applicable), card payment terminal, signage</li>
          </ul>
          
          <h3>Regular Maintenance Schedule</h3>
          <p>Beyond daily checks, establish a regular maintenance schedule:</p>
          <ul>
            <li><strong>Weekly</strong> - Thorough clean inside and out, check wheel nuts, check spare tyre</li>
            <li><strong>Monthly</strong> - Check battery connections, inspect belts and hoses, check all lights</li>
            <li><strong>Quarterly</strong> - Professional servicing according to manufacturer schedule</li>
            <li><strong>Bi-annually</strong> - Prepare for and complete the SPSV suitability test</li>
            <li><strong>Annually</strong> - NCT certificate renewal, taximeter verification (if applicable)</li>
          </ul>
          
          <p>Keep detailed records of all maintenance work, inspections, and repairs for your vehicle. This documentation can be valuable during regulatory checks and when selling the vehicle.</p>
        `,
        keyPoints: [
          "Conduct daily vehicle checks before starting work",
          "Establish and follow a regular maintenance schedule",
          "Keep detailed records of all maintenance work",
          "Clean your vehicle thoroughly inside and out on a regular basis"
        ]
      },
      {
        title: "Compliance with Vehicle Standards",
        content: `
          <p>SPSV vehicles must meet specific standards set by the NTA. These standards ensure that vehicles are safe, suitable for their purpose, and present a professional image.</p>
          
          <h3>SPSV Suitability Test</h3>
          <p>The suitability test assesses whether your vehicle meets the required standards for an SPSV. Key aspects include:</p>
          <ul>
            <li><strong>Vehicle Age</strong> - Maximum age limits for new and renewal licences</li>
            <li><strong>Seating Capacity</strong> - Minimum requirements depending on SPSV category</li>
            <li><strong>Accessibility</strong> - Specific requirements for WAT and WAH vehicles</li>
            <li><strong>Safety Features</strong> - Essential safety equipment</li>
            <li><strong>Comfort</strong> - Interior condition and features</li>
            <li><strong>Appearance</strong> - Professional exterior appearance</li>
          </ul>
          
          <h3>NCT Requirements</h3>
          <p>All SPSV vehicles must undergo a National Car Test (NCT):</p>
          <ul>
            <li>SPSVs must be tested annually regardless of age</li>
            <li>The NCT certificate must be current at all times</li>
            <li>Schedule your NCT well in advance of expiry</li>
            <li>Address any identified issues promptly</li>
          </ul>
          
          <h3>Modifications and Equipment</h3>
          <p>Any modifications to your vehicle must comply with regulations:</p>
          <ul>
            <li>All modifications must be approved by the NTA</li>
            <li>Safety equipment must not be compromised</li>
            <li>Wheelchair accessible vehicles must maintain all accessibility features</li>
            <li>Required equipment (taximeter, roof sign, etc.) must be properly installed</li>
          </ul>
          
          <p>Failure to maintain your vehicle to the required standards can result in penalties, including licence suspension or revocation. Regular maintenance and thorough preparation for tests will help ensure compliance.</p>
        `,
        keyPoints: [
          "Understand and comply with SPSV suitability test requirements",
          "Schedule annual NCT tests well in advance",
          "Ensure any vehicle modifications meet NTA regulations",
          "Maintain all required safety and accessibility features"
        ]
      },
      {
        title: "Professional Vehicle Presentation",
        content: `
          <p>The appearance of your vehicle significantly impacts customer perceptions of your service. A clean, well-presented vehicle creates a positive first impression and enhances the overall passenger experience.</p>
          
          <h3>Exterior Presentation</h3>
          <p>Maintain a professional exterior appearance:</p>
          <ul>
            <li>Wash the exterior regularly, including wheels and windows</li>
            <li>Keep bodywork in good condition, addressing minor damage promptly</li>
            <li>Ensure licence plates and SPSV identification are clean and visible</li>
            <li>Keep taxi roof signs (if applicable) clean and functioning properly</li>
            <li>Ensure all external lights are clean and working</li>
          </ul>
          
          <h3>Interior Cleanliness</h3>
          <p>The interior of your vehicle should be immaculate:</p>
          <ul>
            <li>Vacuum seats, floor mats, and boot regularly</li>
            <li>Clean all interior surfaces, including dashboard and door panels</li>
            <li>Ensure windows are clean inside and out</li>
            <li>Address any odours with proper ventilation and appropriate air fresheners</li>
            <li>Remove all personal items from passenger areas</li>
            <li>Check for and remove any litter after each journey</li>
          </ul>
          
          <h3>Passenger Comfort</h3>
          <p>Consider additional factors that contribute to passenger comfort:</p>
          <ul>
            <li>Maintain an appropriate temperature</li>
            <li>Ensure adequate legroom by adjusting front seats appropriately</li>
            <li>Check seat belts are clean, accessible, and functioning correctly</li>
            <li>Consider providing amenities such as tissues or bottled water</li>
          </ul>
          
          <p>Remember that your vehicle is your workplace and a reflection of your professionalism. The standard of presentation can directly impact your ratings, tips, and repeat business.</p>
        `,
        keyPoints: [
          "Maintain spotless exterior and interior cleanliness",
          "Ensure SPSV identification is clearly visible",
          "Remove all litter after each journey",
          "Consider passenger comfort with appropriate temperature settings"
        ]
      },
      {
        title: "Safe and Efficient Driving",
        content: `
          <p>Safe, efficient driving is fundamental to providing quality SPSV service. It ensures passenger safety, reduces vehicle wear, saves fuel, and creates a comfortable experience.</p>
          
          <h3>Safe Driving Practices</h3>
          <p>Always prioritize safety:</p>
          <ul>
            <li>Adhere to speed limits and traffic regulations at all times</li>
            <li>Maintain a safe following distance</li>
            <li>Use indicators properly for all maneuvers</li>
            <li>Check blind spots before changing lanes</li>
            <li>Adjust driving to weather and road conditions</li>
            <li>Never use a handheld mobile phone while driving</li>
            <li>Ensure all passengers wear seatbelts</li>
            <li>Take regular breaks during long shifts to prevent fatigue</li>
          </ul>
          
          <h3>Fuel-Efficient Driving</h3>
          <p>Reduce fuel consumption with these techniques:</p>
          <ul>
            <li>Accelerate and brake smoothly</li>
            <li>Maintain a steady speed where possible</li>
            <li>Use higher gears appropriately</li>
            <li>Minimize idling time</li>
            <li>Plan routes to avoid unnecessary mileage</li>
            <li>Maintain correct tyre pressure</li>
            <li>Remove unnecessary weight from the vehicle</li>
          </ul>
          
          <h3>Passenger Comfort</h3>
          <p>Consider passenger comfort in your driving style:</p>
          <ul>
            <li>Avoid harsh acceleration and braking</li>
            <li>Take corners smoothly</li>
            <li>Anticipate and prepare for stops</li>
            <li>Avoid routes with excessive bumps or potholes where possible</li>
            <li>Ask passengers about temperature and music preferences</li>
          </ul>
          
          <p>Remember that passengers will judge your service largely based on how safe and comfortable they feel during the journey. Professional, considerate driving is essential for high customer satisfaction.</p>
        `,
        keyPoints: [
          "Adhere strictly to road safety rules and speed limits",
          "Practice smooth acceleration and braking for passenger comfort",
          "Never use handheld mobile phones while driving",
          "Adjust driving style to road and weather conditions"
        ]
      },
      {
        title: "Emergency Procedures",
        content: `
          <p>Being prepared for emergencies is a critical aspect of professional SPSV operation. Knowing how to respond to various situations ensures the safety of both you and your passengers.</p>
          
          <h3>Vehicle Breakdowns</h3>
          <p>If your vehicle breaks down:</p>
          <ul>
            <li>Move to a safe location if possible</li>
            <li>Turn on hazard warning lights</li>
            <li>Inform passengers of the situation clearly and calmly</li>
            <li>Contact your breakdown service</li>
            <li>Assist passengers in finding alternative transportation if necessary</li>
            <li>Consider keeping reflective warning triangles in your vehicle</li>
          </ul>
          
          <h3>Accidents</h3>
          <p>In the event of an accident:</p>
          <ul>
            <li>Stop immediately in a safe place</li>
            <li>Check for injuries and call emergency services if needed</li>
            <li>Exchange details with other parties involved (name, address, phone, insurance, vehicle registration)</li>
            <li>Take photos of damage and the accident scene</li>
            <li>Report the accident to your insurance company</li>
            <li>Note names and contact details of any witnesses</li>
            <li>Do not admit liability at the scene</li>
          </ul>
          
          <h3>Medical Emergencies</h3>
          <p>If a passenger has a medical emergency:</p>
          <ul>
            <li>Pull over safely as soon as possible</li>
            <li>Call emergency services (999 or 112)</li>
            <li>Follow instructions from the emergency operator</li>
            <li>Provide basic first aid if you are trained to do so</li>
            <li>Remain with the passenger until help arrives</li>
          </ul>
          
          <h3>Personal Safety Incidents</h3>
          <p>If you encounter threatening behavior:</p>
          <ul>
            <li>Stay calm and avoid escalating the situation</li>
            <li>If safe to do so, pull over and ask the passenger to leave</li>
            <li>In serious situations, use emergency code phrases with your dispatch operator if applicable</li>
            <li>Call the Gardaí if you feel threatened</li>
            <li>Consider installing a dash cam or security camera</li>
          </ul>
          
          <p>Maintain an emergency contact list and important phone numbers in your vehicle. Regularly review and update your emergency procedures to ensure you're prepared for any situation.</p>
        `,
        keyPoints: [
          "Know exactly what to do in case of breakdown or accident",
          "Keep emergency contact numbers readily available",
          "Remain calm and professional during emergency situations",
          "Consider installing safety equipment like dash cams"
        ]
      }
    ],
    vehicleSpecificContent: {
      "taxi": {
        additionalContent: `
          <p>Taxi vehicles face unique operational challenges due to their high mileage and frequent stop-start driving patterns:</p>
          
          <ul>
            <li>Consider more frequent servicing intervals than manufacturer recommendations due to higher than average mileage</li>
            <li>Pay special attention to brake wear, as city driving causes increased brake usage</li>
            <li>Regularly check your taximeter calibration and printer functionality</li>
            <li>Ensure your roof sign is securely attached and functioning properly</li>
            <li>Keep your taxi identification and licensing information clearly displayed as required by regulations</li>
          </ul>
          
          <p>Remember that taxi vehicles undergo additional scrutiny from regulatory authorities and passengers, making meticulous maintenance particularly important.</p>
        `,
        additionalKeyPoints: [
          "Service taxi vehicles more frequently than standard recommendations",
          "Regularly check taximeter calibration and printer functionality",
          "Ensure roof sign and taxi identification are properly displayed",
          "Pay special attention to brakes due to city driving patterns"
        ]
      },
      "limousine": {
        additionalContent: `
          <p>Limousine operators must maintain exceptionally high standards of vehicle presentation and maintenance:</p>
          
          <ul>
            <li>Detail the vehicle thoroughly before each client booking</li>
            <li>Pay particular attention to luxury features such as leather upholstery and specialised interior lighting</li>
            <li>Ensure all convenience features (climate control, entertainment systems, etc.) are in perfect working order</li>
            <li>For stretched limousines, be particularly attentive to chassis and suspension maintenance</li>
            <li>Consider using professional valeting services regularly to maintain the luxury appearance</li>
            <li>Stock appropriate premium amenities such as bottled water, tissues, and reading materials</li>
          </ul>
          
          <p>Limousine clients have particularly high expectations for vehicle quality and presentation, with even minor issues potentially affecting your reputation in this premium service segment.</p>
        `,
        additionalKeyPoints: [
          "Detail the vehicle before each client booking",
          "Ensure all luxury and convenience features function perfectly",
          "Use professional valeting services regularly",
          "Stock premium amenities appropriate for high-end clients"
        ]
      }
    }
  },
  
  // Module 10: Technology and Tools
  10: {
    pages: [
      {
        title: "Essential Technology for SPSV Operators",
        content: `
          <p>Modern SPSV operation relies increasingly on technology to enhance efficiency, compliance, and customer service. Familiarizing yourself with essential tools can give you a competitive edge.</p>
          
          <h3>Smartphone Applications</h3>
          <p>Key apps for SPSV operators include:</p>
          <ul>
            <li><strong>Navigation Apps</strong> - Google Maps, Waze, etc. for route planning and traffic updates</li>
            <li><strong>SPSV Industry Apps</strong> - NTA Driver Check app for licence verification</li>
            <li><strong>Booking/Dispatch Apps</strong> - FreeNow, Bolt, etc. for connecting with customers</li>
            <li><strong>Payment Processing Apps</strong> - For card payment processing</li>
            <li><strong>Expense Tracking Apps</strong> - For logging business expenses and mileage</li>
            <li><strong>Weather Apps</strong> - For planning around weather conditions</li>
          </ul>
          
          <h3>In-Vehicle Technology</h3>
          <p>Consider these technology solutions for your vehicle:</p>
          <ul>
            <li><strong>GPS Navigation Systems</strong> - Dedicated devices for reliable navigation</li>
            <li><strong>Dash Cameras</strong> - For security and incident documentation</li>
            <li><strong>Card Payment Terminals</strong> - Required for taxi operation</li>
            <li><strong>Taximeters</strong> - For taxis, must be approved and verified</li>
            <li><strong>Bluetooth Hands-Free Systems</strong> - For safe communication</li>
            <li><strong>USB Charging Ports</strong> - For passenger convenience</li>
          </ul>
          
          <p>When selecting technology, consider ease of use, reliability, and compliance with regulations. Invest in quality equipment that will withstand the demands of professional use.</p>
        `,
        keyPoints: [
          "Use navigation apps for efficient route planning",
          "Install a quality dash camera for security",
          "Provide USB charging ports for passenger convenience",
          "Use hands-free systems for safe communication"
        ]
      },
      {
        title: "Digital Booking and Dispatch Systems",
        content: `
          <p>Digital booking and dispatch systems have transformed how SPSVs connect with customers. Understanding these platforms is essential for maximizing your earning potential.</p>
          
          <h3>Types of Booking Platforms</h3>
          <p>SPSV operators can access customers through various digital channels:</p>
          <ul>
            <li><strong>App-Based Platforms</strong> - FreeNow, Bolt, etc. connecting drivers directly with customers</li>
            <li><strong>Traditional Dispatch Systems</strong> - Operated by taxi companies with digital interfaces</li>
            <li><strong>Web Booking Platforms</strong> - Allow pre-booking through websites</li>
            <li><strong>Direct Booking Tools</strong> - Personal booking systems for regular clients</li>
          </ul>
          
          <h3>Using Booking Platforms Effectively</h3>
          <p>To maximize the benefits of these systems:</p>
          <ul>
            <li>Understand the fee structure and commission rates</li>
            <li>Learn how the platform's algorithm prioritizes drivers</li>
            <li>Maintain a high rating by providing excellent service</li>
            <li>Use platform features such as heat maps to identify high-demand areas</li>
            <li>Be selective about which platforms best suit your operating style and area</li>
            <li>Keep your profile and documentation up to date</li>
          </ul>
          
          <h3>Balancing Multiple Platforms</h3>
          <p>Many drivers work with multiple booking platforms:</p>
          <ul>
            <li>Consider using a phone mount that allows monitoring of multiple apps</li>
            <li>Develop a system for managing bookings across platforms</li>
            <li>Be aware of each platform's policies regarding driver availability</li>
            <li>Track which platforms perform best in your area at different times</li>
          </ul>
          
          <p>Digital booking platforms can increase your efficiency and earning potential, but require some time investment to learn and use effectively. The right combination of platforms can significantly increase your customer base.</p>
        `,
        keyPoints: [
          "Understand commission rates and payment schedules for each platform",
          "Maintain high ratings to receive more booking opportunities",
          "Use data features like heat maps to find high-demand areas",
          "Consider multi-apping but develop an organized system"
        ]
      },
      {
        title: "Payment Technologies",
        content: `
          <p>Modern payment technologies are essential for SPSV operators. Since 2019, all taxis in Ireland are required to accept card payments, and other SPSV types benefit from offering multiple payment options.</p>
          
          <h3>Card Payment Terminals</h3>
          <p>When selecting a card payment terminal:</p>
          <ul>
            <li>Choose a terminal designed for mobile operation with good battery life</li>
            <li>Look for quick transaction processing times</li>
            <li>Ensure connectivity options work in your operating area (4G/cellular, Bluetooth)</li>
            <li>Consider transaction fees and monthly costs</li>
            <li>Check receipt printing capabilities</li>
            <li>Ensure compatibility with major card types and contactless payments</li>
            <li>Look for integration with accounting software if needed</li>
          </ul>
          
          <h3>Digital Wallets and Contactless</h3>
          <p>Modern payment options include:</p>
          <ul>
            <li><strong>Contactless Cards</strong> - Now the most common payment method</li>
            <li><strong>Mobile Wallets</strong> - Apple Pay, Google Pay, Samsung Pay</li>
            <li><strong>QR Code Payments</strong> - Increasingly popular for certain demographics</li>
            <li><strong>In-App Payments</strong> - Through booking platforms like FreeNow</li>
          </ul>
          
          <h3>Managing Digital Payments</h3>
          <p>Best practices include:</p>
          <ul>
            <li>Test your payment system at the start of each shift</li>
            <li>Have a backup payment solution if your primary system fails</li>
            <li>Understand the reconciliation process for different payment types</li>
            <li>Keep transaction records for accounting purposes</li>
            <li>Know how to process refunds if necessary</li>
            <li>Explain the payment process clearly to passengers who may be unfamiliar</li>
          </ul>
          
          <p>Offering convenient, reliable payment options enhances customer satisfaction and can lead to better tips and ratings. Ensure you're comfortable with the operation of all your payment technology.</p>
        `,
        keyPoints: [
          "Choose a reliable payment terminal designed for mobile use",
          "Offer multiple payment options including contactless and mobile wallets",
          "Test payment systems at the start of each shift",
          "Have a backup payment solution available"
        ]
      },
      {
        title: "Safety and Security Technology",
        content: `
          <p>Safety and security technology can help protect you, your passengers, and your vehicle. These tools provide peace of mind and documentation in case of incidents.</p>
          
          <h3>Dash Cameras</h3>
          <p>When selecting a dash camera system:</p>
          <ul>
            <li>Consider dual-facing cameras that record both road and interior</li>
            <li>Look for HD resolution for clear image quality</li>
            <li>Ensure adequate storage capacity or cloud backup</li>
            <li>Check for night vision capabilities for low-light recording</li>
            <li>Consider audio recording features</li>
            <li>Look for tamper-proof design and parking mode</li>
            <li>Ensure compliance with data protection regulations</li>
          </ul>
          
          <h3>GPS Tracking Systems</h3>
          <p>GPS systems offer more than navigation:</p>
          <ul>
            <li>Vehicle tracking for security in case of theft</li>
            <li>Journey recording for dispute resolution</li>
            <li>Route optimization and traffic avoidance</li>
            <li>Integration with booking platforms</li>
            <li>Data collection for business analysis</li>
          </ul>
          
          <h3>Additional Security Technology</h3>
          <p>Other security options include:</p>
          <ul>
            <li><strong>Vehicle Immobilizers</strong> - Prevent unauthorized vehicle use</li>
            <li><strong>Panic Buttons</strong> - Quick alert system for emergencies</li>
            <li><strong>Vehicle Cameras</strong> - Recording surroundings when parked</li>
            <li><strong>Security Lighting</strong> - Motion-activated lighting for entering/exiting vehicle at night</li>
          </ul>
          
          <p>When implementing security technology, inform passengers about recording devices as required by law, and ensure all systems are installed professionally so they don't interfere with vehicle operation.</p>
        `,
        keyPoints: [
          "Install dual-facing dash cameras for comprehensive coverage",
          "Use GPS tracking for security and business analysis",
          "Consider additional security features like panic buttons",
          "Ensure all security technology complies with data protection laws"
        ]
      },
      {
        title: "Digital Record Keeping",
        content: `
          <p>Effective digital record-keeping is essential for regulatory compliance, tax reporting, and efficient business management. Modern technology makes this process more streamlined than traditional paper-based systems.</p>
          
          <h3>Essential Business Records</h3>
          <p>Key records to maintain digitally include:</p>
          <ul>
            <li><strong>Income Records</strong> - Daily, weekly, and monthly earnings</li>
            <li><strong>Expense Records</strong> - Fuel, maintenance, insurance, licensing fees</li>
            <li><strong>Mileage Logs</strong> - Both revenue and non-revenue miles</li>
            <li><strong>Work Hours</strong> - Time tracking for compliance and analysis</li>
            <li><strong>Vehicle Maintenance</strong> - Service dates, repairs, inspections</li>
            <li><strong>Licence Renewals</strong> - SPSV driver and vehicle licence details</li>
            <li><strong>Insurance Documentation</strong> - Policy details and renewals</li>
            <li><strong>Tax Records</strong> - Documents required for tax filing</li>
          </ul>
          
          <h3>Digital Record-Keeping Tools</h3>
          <p>Useful applications and systems include:</p>
          <ul>
            <li><strong>Specialized SPSV Apps</strong> - Designed specifically for taxi and hackney operators</li>
            <li><strong>General Accounting Software</strong> - QuickBooks, Sage, etc.</li>
            <li><strong>Spreadsheet Applications</strong> - Excel, Google Sheets</li>
            <li><strong>Mileage Tracking Apps</strong> - Automatic GPS-based tracking</li>
            <li><strong>Receipt Scanning Apps</strong> - For digitizing paper receipts</li>
            <li><strong>Cloud Storage Services</strong> - For document backup and sharing with accountants</li>
          </ul>
          
          <h3>Best Practices for Digital Records</h3>
          <p>To maintain effective digital records:</p>
          <ul>
            <li>Update records daily to ensure accuracy</li>
            <li>Create regular backups of all digital information</li>
            <li>Use consistent categorization for income and expenses</li>
            <li>Set reminders for important renewal dates</li>
            <li>Review data regularly to identify business trends</li>
            <li>Ensure compliance with tax authority requirements</li>
            <li>Maintain records for the required retention period (typically 6 years)</li>
          </ul>
          
          <p>Effective digital record-keeping not only ensures compliance but can also provide valuable insights into your business performance and help identify opportunities for increasing profitability.</p>
        `,
        keyPoints: [
          "Use digital tools to maintain comprehensive business records",
          "Track income, expenses, mileage, and maintenance digitally",
          "Create regular backups of all business data",
          "Review business records regularly to identify trends"
        ]
      }
    ],
    vehicleSpecificContent: {
      "taxi": {
        additionalContent: `
          <p>Taxi operators have specific technology requirements and opportunities:</p>
          
          <ul>
            <li>Ensure your taximeter is approved, properly calibrated, and sealed by the Legal Metrology Service</li>
            <li>Consider taximeter systems that integrate with receipt printers and payment terminals</li>
            <li>Use taxi-specific apps that help locate ranks and high-demand areas</li>
            <li>Install clear signage showing payment options available</li>
            <li>Consider passenger-facing screens that display the running fare for transparency</li>
            <li>If operating at night, ensure all lighting for signage and meters is functioning properly</li>
          </ul>
          
          <p>As a taxi operator, your technology must comply with specific regulatory requirements while also meeting customer expectations for a modern, efficient service.</p>
        `,
        additionalKeyPoints: [
          "Ensure taximeter integration with payment systems",
          "Use taxi-specific apps for finding ranks and demand",
          "Consider passenger-facing fare displays for transparency",
          "Maintain proper lighting for all signage and meters"
        ]
      },
      "limousine": {
        additionalContent: `
          <p>Limousine services require technology that enhances the premium experience:</p>
          
          <ul>
            <li>Consider advanced booking systems that allow clients to specify requirements in detail</li>
            <li>Invest in high-quality entertainment systems with Bluetooth connectivity</li>
            <li>Offer Wi-Fi access for business clients</li>
            <li>Use discrete security cameras that don't detract from the luxury experience</li>
            <li>Consider automated climate control systems for consistent comfort</li>
            <li>Use professional invoicing software for corporate clients</li>
            <li>Implement customer relationship management (CRM) systems to track client preferences</li>
          </ul>
          
          <p>For limousine operations, technology should be simultaneously state-of-the-art and unobtrusive, enhancing the premium experience without calling attention to itself.</p>
        `,
        additionalKeyPoints: [
          "Implement advanced booking systems for detailed client requirements",
          "Provide Wi-Fi and premium entertainment options",
          "Use professional invoicing for corporate clients",
          "Track client preferences with CRM systems"
        ]
      }
    }
  },
  
  // Module 11: Business Management for SPSVs
  11: {
    pages: [
      {
        title: "Legal Structures and Registration",
        content: `
          <p>Choosing the right legal structure for your SPSV business is an important decision that affects taxation, liability, and operational flexibility. Each structure has advantages and disadvantages.</p>
          
          <h3>Common Business Structures</h3>
          <p>SPSV operators typically choose from:</p>
          <ul>
            <li><strong>Sole Trader</strong>
              <ul>
                <li>Simplest legal structure with minimal setup requirements</li>
                <li>Business and personal affairs are legally the same entity</li>
                <li>Unlimited personal liability for business debts</li>
                <li>Income taxed at personal income tax rates</li>
                <li>Simpler accounting and tax filing</li>
              </ul>
            </li>
            <li><strong>Limited Company</strong>
              <ul>
                <li>Separate legal entity from the owner</li>
                <li>Limited liability protection for personal assets</li>
                <li>Potentially more tax-efficient for higher earners</li>
                <li>More complex and costly to establish and maintain</li>
                <li>Requires annual returns and financial statements</li>
              </ul>
            </li>
            <li><strong>Partnership</strong> (less common for single-vehicle operations)
              <ul>
                <li>Shared ownership between two or more individuals</li>
                <li>Partners have unlimited liability</li>
                <li>Income distributed according to partnership agreement</li>
                <li>Requires clear agreements on roles and profit sharing</li>
              </ul>
            </li>
          </ul>
          
          <h3>Registration Requirements</h3>
          <p>Regardless of structure, you'll need to:</p>
          <ul>
            <li>Register with Revenue as self-employed or as a company</li>
            <li>Register for Value Added Tax (VAT) if your turnover exceeds the threshold</li>
            <li>Register as an employer if you hire drivers or staff</li>
            <li>Obtain necessary SPSV licences from the NTA</li>
            <li>Secure appropriate insurance coverage</li>
          </ul>
          
          <p>Consider consulting with an accountant or business advisor before deciding on your business structure. The right choice depends on your specific circumstances, income level, and future plans.</p>
        `,
        keyPoints: [
          "Consider liability, taxation, and complexity when choosing a business structure",
          "Sole trader status is simplest but offers no liability protection",
          "Limited companies provide liability protection but are more complex",
          "Consult with an accountant before making this decision"
        ]
      },
      {
        title: "Financial Management",
        content: `
          <p>Sound financial management is crucial for the long-term success of your SPSV business. Understanding and controlling your finances enables informed business decisions and ensures compliance with tax obligations.</p>
          
          <h3>Income Tracking</h3>
          <p>Maintain detailed records of all income:</p>
          <ul>
            <li>Record daily, weekly, and monthly revenue</li>
            <li>Track income by source (street hails, dispatch, apps, etc.)</li>
            <li>Keep records of cash and electronic payments separately</li>
            <li>Monitor trends to identify profitable times and areas</li>
            <li>Reconcile app-based income with platform statements</li>
          </ul>
          
          <h3>Expense Management</h3>
          <p>Track and categorize all business expenses:</p>
          <ul>
            <li><strong>Vehicle Costs</strong> - Fuel, maintenance, repairs, depreciation</li>
            <li><strong>Licensing</strong> - SPSV driver and vehicle licence fees</li>
            <li><strong>Insurance</strong> - Vehicle, public liability, income protection</li>
            <li><strong>Technology</strong> - Phone, apps, payment systems, GPS</li>
            <li><strong>Professional Services</strong> - Accounting, legal, tax advice</li>
            <li><strong>Office Expenses</strong> - Record keeping, administration</li>
            <li><strong>Marketing</strong> - Business cards, advertising, website</li>
          </ul>
          
          <h3>Budgeting and Cash Flow</h3>
          <p>Develop financial planning habits:</p>
          <ul>
            <li>Create a monthly budget for fixed and variable expenses</li>
            <li>Set aside funds for quarterly tax payments</li>
            <li>Maintain a reserve for unexpected repairs and emergencies</li>
            <li>Plan for major expenses like vehicle replacement</li>
            <li>Monitor cash flow to ensure sufficient liquidity</li>
            <li>Consider seasonal variations in income when planning</li>
          </ul>
          
          <h3>Financial Analysis</h3>
          <p>Regularly review key financial metrics:</p>
          <ul>
            <li>Revenue per hour worked</li>
            <li>Profit margin after expenses</li>
            <li>Cost per kilometer driven</li>
            <li>Percentage of paid versus unpaid mileage</li>
            <li>Commission rates on different platforms</li>
            <li>Return on investment for vehicle and equipment</li>
          </ul>
          
          <p>Consider using accounting software or working with an accountant familiar with the SPSV industry. Professional guidance can help optimize your financial strategy and ensure compliance with all regulations.</p>
        `,
        keyPoints: [
          "Track all income and expenses in detail",
          "Create budgets that account for seasonal variations",
          "Maintain financial reserves for emergencies and tax payments",
          "Regularly analyze key financial metrics to optimize profitability"
        ]
      },
      {
        title: "Taxation and Compliance",
        content: `
          <p>Understanding and fulfilling your tax obligations is essential for legal SPSV operation. Proper tax compliance avoids penalties and ensures peace of mind.</p>
          
          <h3>Key Tax Obligations</h3>
          <p>SPSV operators must typically manage:</p>
          <ul>
            <li><strong>Income Tax</strong> - On profits from your SPSV business</li>
            <li><strong>Universal Social Charge (USC)</strong> - Calculated on gross income</li>
            <li><strong>Pay Related Social Insurance (PRSI)</strong> - Class S contributions for self-employed</li>
            <li><strong>Value Added Tax (VAT)</strong> - If registered (registration is voluntary below the threshold)</li>
            <li><strong>Preliminary Tax</strong> - Advance payment based on estimated liability</li>
            <li><strong>Capital Gains Tax</strong> - When selling business assets for a profit</li>
          </ul>
          
          <h3>Tax Deductible Expenses</h3>
          <p>You can reduce your tax liability with legitimate business expenses:</p>
          <ul>
            <li>Fuel and oil for business use</li>
            <li>Vehicle repairs and maintenance</li>
            <li>Insurance premiums</li>
            <li>SPSV licence fees</li>
            <li>Dispatch service or app commission fees</li>
            <li>Mobile phone costs (business portion)</li>
            <li>Accounting and tax preparation fees</li>
            <li>Vehicle depreciation (capital allowances)</li>
          </ul>
          
          <h3>Record Keeping for Tax</h3>
          <p>Maintain these records for at least six years:</p>
          <ul>
            <li>All income receipts and records</li>
            <li>Expense receipts and invoices</li>
            <li>Bank statements for business accounts</li>
            <li>Mileage logs distinguishing business and personal use</li>
            <li>Vehicle purchase documents and financing agreements</li>
            <li>Previous tax returns and calculation documents</li>
          </ul>
          
          <h3>Tax Filing Deadlines</h3>
          <p>Key dates to remember:</p>
          <ul>
            <li>31 October - Income tax return filing and payment (Form 11)</li>
            <li>31 October - Preliminary tax payment for the current year</li>
            <li>VAT returns - Typically bi-monthly if registered</li>
          </ul>
          
          <p>Consider working with a tax professional who specialises in transport or self-employed businesses. Their expertise can help you claim all eligible deductions while ensuring full compliance with tax legislation.</p>
        `,
        keyPoints: [
          "Understand all tax obligations including Income Tax, USC, and PRSI",
          "Keep detailed records of all business income and expenses",
          "Know which expenses are tax-deductible for SPSV operations",
          "Meet all tax filing deadlines to avoid penalties"
        ]
      },
      {
        title: "Insurance and Risk Management",
        content: `
          <p>Proper insurance coverage is not only a legal requirement for SPSV operators but also essential protection against financial risks. Understanding and managing these risks is fundamental to business sustainability.</p>
          
          <h3>Essential Insurance Coverage</h3>
          <p>SPSV operators typically need:</p>
          <ul>
            <li><strong>SPSV-Specific Vehicle Insurance</strong> - Covers your vehicle for commercial passenger transport</li>
            <li><strong>Public Liability Insurance</strong> - Protects against claims for passenger injury or property damage</li>
            <li><strong>Personal Accident Insurance</strong> - Covers you if injured while working</li>
            <li><strong>Income Protection Insurance</strong> - Provides income if you're unable to work due to illness or injury</li>
            <li><strong>Legal Expenses Insurance</strong> - Covers legal costs if you face court proceedings</li>
          </ul>
          
          <h3>Insurance Considerations</h3>
          <p>When selecting insurance policies:</p>
          <ul>
            <li>Compare quotes from multiple providers specializing in SPSV coverage</li>
            <li>Check for coverage limitations and exclusions</li>
            <li>Consider excess amounts and how they affect premiums</li>
            <li>Ensure 24/7 breakdown assistance is included</li>
            <li>Verify coverage for all geographical areas where you operate</li>
            <li>Disclose all relevant information to avoid invalidating claims</li>
            <li>Review policies annually to ensure adequate coverage</li>
          </ul>
          
          <h3>Risk Management Strategies</h3>
          <p>Beyond insurance, manage risks through:</p>
          <ul>
            <li>Regular vehicle maintenance to prevent breakdowns</li>
            <li>Defensive driving techniques to reduce accident risk</li>
            <li>Security measures to prevent vehicle theft or vandalism</li>
            <li>Clear policies for handling disputes or incidents</li>
            <li>Emergency procedures for various scenarios</li>
            <li>Ongoing professional development and safety training</li>
          </ul>
          
          <h3>Documentation and Evidence</h3>
          <p>Maintain records that can help with claims:</p>
          <ul>
            <li>Dash camera footage</li>
            <li>Incident reports for any notable events</li>
            <li>Maintenance records showing proper vehicle care</li>
            <li>Driver logs and work records</li>
            <li>Passenger details when appropriate</li>
          </ul>
          
          <p>Never operate without proper insurance coverage as this is both illegal and exposes you to potentially catastrophic financial risk. The right insurance gives you peace of mind and protects your livelihood.</p>
        `,
        keyPoints: [
          "Ensure you have SPSV-specific vehicle insurance coverage",
          "Consider additional coverage like income protection",
          "Implement risk management strategies beyond insurance",
          "Maintain documentation that can support insurance claims"
        ]
      },
      {
        title: "Business Growth and Development",
        content: `
          <p>While many SPSV operators start as owner-drivers with a single vehicle, there are various ways to grow and develop your business over time. Strategic growth can increase income and build long-term value.</p>
          
          <h3>Growth Strategies</h3>
          <p>Consider these pathways for business development:</p>
          <ul>
            <li><strong>Service Enhancement</strong> - Improving your existing service
              <ul>
                <li>Developing a specialty or niche (airport transfers, corporate service, etc.)</li>
                <li>Adding premium features or amenities</li>
                <li>Optimizing your schedule for higher-earning periods</li>
                <li>Building a regular customer base</li>
              </ul>
            </li>
            <li><strong>Fleet Expansion</strong> - Adding vehicles
              <ul>
                <li>Acquiring additional SPSV licences</li>
                <li>Hiring and managing drivers</li>
                <li>Standardizing operations across multiple vehicles</li>
                <li>Implementing fleet management systems</li>
              </ul>
            </li>
            <li><strong>Diversification</strong> - Expanding service types
              <ul>
                <li>Operating different SPSV categories (taxi, hackney, limousine)</li>
                <li>Adding specialised vehicles (wheelchair accessible, electric)</li>
                <li>Offering complementary services (tours, courier work)</li>
              </ul>
            </li>
            <li><strong>Business Formalization</strong> - Organizational development
              <ul>
                <li>Establishing a company brand and identity</li>
                <li>Creating systems and procedures</li>
                <li>Developing a business location or office</li>
                <li>Building a team structure</li>
              </ul>
            </li>
          </ul>
          
          <h3>Planning for Growth</h3>
          <p>Before expanding, consider:</p>
          <ul>
            <li>Creating a formal business plan</li>
            <li>Analyzing market demand in your area</li>
            <li>Securing appropriate financing</li>
            <li>Understanding additional regulatory requirements</li>
            <li>Developing management skills and systems</li>
            <li>Planning for increased administrative workload</li>
          </ul>
          
          <h3>Building Business Value</h3>
          <p>Increase the long-term value of your business through:</p>
          <ul>
            <li>Developing a recognizable brand</li>
            <li>Building a database of regular customers</li>
            <li>Creating efficient operational systems</li>
            <li>Establishing relationships with corporate clients</li>
            <li>Maintaining well-documented financial records</li>
            <li>Investing in quality vehicles and equipment</li>
          </ul>
          
          <p>Growth should be strategic and controlled, ensuring that expansion doesn't compromise service quality or financial stability. Each step should be carefully planned and evaluated before moving forward.</p>
        `,
        keyPoints: [
          "Consider various growth strategies from service enhancement to fleet expansion",
          "Develop a formal business plan before significant expansion",
          "Build long-term business value through branding and customer relationships",
          "Ensure growth is strategic and doesn't compromise quality"
        ]
      }
    ],
    vehicleSpecificContent: {
      "taxi": {
        additionalContent: `
          <p>Taxi operators have specific business considerations:</p>
          
          <ul>
            <li>Taxi licences are limited in number and have a significant market value</li>
            <li>Consider the optimal operating hours for your area - night work often commands higher fares but comes with additional challenges</li>
            <li>Analyze the profitability of different operating strategies - ranks versus street hails versus app bookings</li>
            <li>Research the specific regulations in your local authority area regarding taxi operations</li>
            <li>Consider joining a local taxi association for collective representation and information sharing</li>
          </ul>
          
          <p>The taxi segment often has more regulatory requirements but can offer more flexibility in obtaining passengers through multiple channels (ranks, street hails, and pre-bookings).</p>
        `,
        additionalKeyPoints: [
          "Understand the value and transferability of taxi licences",
          "Analyze the most profitable operating hours in your area",
          "Compare profitability of ranks, street hails, and app bookings",
          "Consider joining a local taxi association"
        ]
      },
      "limousine": {
        additionalContent: `
          <p>The limousine business model has distinct characteristics:</p>
          
          <ul>
            <li>Focus on building relationships with wedding planners, event coordinators, and corporate travel departments</li>
            <li>Consider offering package deals for special occasions</li>
            <li>Develop a marketing strategy that targets the luxury transport segment</li>
            <li>Analyze the return on investment for higher-end vehicles</li>
            <li>Create a premium brand identity that appeals to high-value clients</li>
            <li>Consider specialization in specific types of events or corporate transport</li>
          </ul>
          
          <p>The limousine business typically involves lower volume but higher margin services, with greater emphasis on relationship building and brand development.</p>
        `,
        additionalKeyPoints: [
          "Develop relationships with wedding planners and event coordinators",
          "Create package deals for special occasions",
          "Establish a premium brand identity",
          "Analyze ROI for investing in luxury vehicles"
        ]
      }
    }
  },
  
  // Module 12: SPSV Career Development
  12: {
    pages: [
      {
        title: "Professional Development",
        content: `
          <p>Continuous professional development is essential for long-term success in the SPSV industry. Enhancing your skills and knowledge can improve service quality, increase earning potential, and provide career advancement opportunities.</p>
          
          <h3>Key Development Areas</h3>
          <p>Consider developing these professional skills:</p>
          <ul>
            <li><strong>Area Knowledge</strong> - Expanding your familiarity with different regions</li>
            <li><strong>Customer Service</strong> - Advanced techniques for passenger satisfaction</li>
            <li><strong>Defensive Driving</strong> - Specialized driving skills for safety</li>
            <li><strong>Language Skills</strong> - Additional languages for international visitors</li>
            <li><strong>Special Needs Assistance</strong> - Techniques for supporting passengers with disabilities</li>
            <li><strong>Technical Knowledge</strong> - Vehicle maintenance and technology systems</li>
            <li><strong>Business Management</strong> - Financial, marketing, and operational skills</li>
          </ul>
          
          <h3>Learning Opportunities</h3>
          <p>Pursue development through:</p>
          <ul>
            <li>Formal SPSV training programs</li>
            <li>Defensive driving courses</li>
            <li>Customer service workshops</li>
            <li>Business management courses</li>
            <li>Local area familiarization expeditions</li>
            <li>Industry seminars and conferences</li>
            <li>Online learning platforms</li>
            <li>Reading industry publications</li>
          </ul>
          
          <h3>Certifications and Qualifications</h3>
          <p>Consider valuable certifications such as:</p>
          <ul>
            <li>Advanced driving qualifications</li>
            <li>First aid certification</li>
            <li>Tourism guide accreditation</li>
            <li>Specialized vehicle maintenance knowledge</li>
            <li>Business management qualifications</li>
          </ul>
          
          <p>Investing in your professional development not only improves your service but can also open doors to specialised roles within the industry. Track your learning and be sure to highlight your qualifications to customers when relevant.</p>
        `,
        keyPoints: [
          "Continuously expand your area knowledge and customer service skills",
          "Consider formal certifications in relevant areas",
          "Participate in industry events and learning opportunities",
          "Highlight your qualifications and specializations to customers"
        ]
      },
      {
        title: "Specialization Opportunities",
        content: `
          <p>Specializing in a particular segment of the SPSV market can help differentiate your service, attract specific customer groups, and potentially increase your earnings. Various specialization options exist within the industry.</p>
          
          <h3>Service Type Specializations</h3>
          <p>Consider focusing on specific service types:</p>
          <ul>
            <li><strong>Executive Transport</strong> - Corporate clients with high service expectations</li>
            <li><strong>Airport Transfers</strong> - Specialized knowledge of flight schedules and terminals</li>
            <li><strong>Tourism Services</strong> - Combined transport and guided tours</li>
            <li><strong>Wedding and Event Transport</strong> - Special occasion services</li>
            <li><strong>Accessible Transport</strong> - Specializing in mobility solutions</li>
            <li><strong>School Runs</strong> - Regular transport for students</li>
            <li><strong>Night Service</strong> - Focusing on evening and late-night transport</li>
          </ul>
          
          <h3>Vehicle Specializations</h3>
          <p>Vehicle choices can define your specialization:</p>
          <ul>
            <li><strong>Luxury Vehicles</strong> - High-end cars for premium service</li>
            <li><strong>Wheelchair Accessible Vehicles</strong> - Specially equipped for accessibility</li>
            <li><strong>Electric/Green Vehicles</strong> - Eco-friendly transport options</li>
            <li><strong>Multi-Passenger Vehicles</strong> - Larger capacity for groups</li>
            <li><strong>Classic or Vintage Cars</strong> - Specialty vehicles for events</li>
          </ul>
          
          <h3>Developing a Specialization</h3>
          <p>To establish yourself in a specialised area:</p>
          <ul>
            <li>Research the market demand for your chosen specialization</li>
            <li>Acquire any necessary additional qualifications or knowledge</li>
            <li>Invest in appropriate vehicle and equipment</li>
            <li>Develop relationships with relevant businesses and organisations</li>
            <li>Create targeted marketing materials</li>
            <li>Join industry associations related to your specialization</li>
            <li>Consider specialised insurance coverage if needed</li>
          </ul>
          
          <p>Successful specialization requires a thorough understanding of the needs and expectations of your target customer segment. Take time to research the market before making significant investments in specializing your service.</p>
        `,
        keyPoints: [
          "Consider specializing in a specific service type or market segment",
          "Choose a vehicle that supports your specialization",
          "Research market demand before investing in specialization",
          "Develop relationships with businesses relevant to your specialty"
        ]
      },
      {
        title: "Building Your Brand and Reputation",
        content: `
          <p>In the SPSV industry, your personal brand and reputation are significant assets. A strong professional reputation can lead to repeat business, referrals, and higher earnings.</p>
          
          <h3>Elements of Your Professional Brand</h3>
          <p>Your brand is shaped by:</p>
          <ul>
            <li><strong>Service Quality</strong> - Consistency, reliability, and professionalism</li>
            <li><strong>Vehicle Presentation</strong> - Cleanliness, condition, and appropriateness</li>
            <li><strong>Personal Presentation</strong> - Appearance, communication, and conduct</li>
            <li><strong>Digital Presence</strong> - Online profiles, reviews, and website</li>
            <li><strong>Visual Identity</strong> - Business cards, vehicle livery, and logos</li>
            <li><strong>Communication Style</strong> - How you interact with customers</li>
          </ul>
          
          <h3>Building a Positive Reputation</h3>
          <p>To enhance your professional standing:</p>
          <ul>
            <li>Deliver consistently excellent service</li>
            <li>Be punctual and reliable</li>
            <li>Handle complaints professionally and promptly</li>
            <li>Maintain a clean, well-presented vehicle</li>
            <li>Develop expertise in your operating area</li>
            <li>Show genuine care for passenger comfort and safety</li>
            <li>Go above and beyond when opportunities arise</li>
          </ul>
          
          <h3>Managing Your Online Reputation</h3>
          <p>In today's digital world:</p>
          <ul>
            <li>Maintain complete, accurate profiles on booking platforms</li>
            <li>Respond professionally to all reviews, including negative ones</li>
            <li>Encourage satisfied customers to leave reviews</li>
            <li>Consider creating a simple professional website</li>
            <li>Use social media professionally if appropriate for your market</li>
            <li>Monitor mentions of your service online</li>
          </ul>
          
          <h3>Marketing Your Service</h3>
          <p>Promote your service through:</p>
          <ul>
            <li>Professional business cards</li>
            <li>Networking with local businesses</li>
            <li>Targeted advertising in relevant publications</li>
            <li>Relationship building with potential referral sources</li>
            <li>Community involvement and local events</li>
            <li>Loyalty programs for regular customers</li>
          </ul>
          
          <p>Remember that each passenger interaction is an opportunity to strengthen or weaken your professional reputation. Consistently positive experiences build a reputation that becomes one of your most valuable business assets.</p>
        `,
        keyPoints: [
          "Develop a consistent professional brand across all touchpoints",
          "Deliver reliable, high-quality service on every journey",
          "Manage your online reputation through platforms and reviews",
          "Build relationships with local businesses for referrals"
        ]
      },
      {
        title: "Health and Wellbeing",
        content: `
          <p>The SPSV profession can be physically and mentally demanding, with long hours spent driving and managing various challenges. Maintaining your health and wellbeing is essential for long-term career success and job satisfaction.</p>
          
          <h3>Physical Health Considerations</h3>
          <p>Address these common physical challenges:</p>
          <ul>
            <li><strong>Back and Neck Health</strong>
              <ul>
                <li>Use ergonomic seat cushions if needed</li>
                <li>Adjust your seat for proper posture</li>
                <li>Take regular breaks to stretch</li>
                <li>Consider periodic physiotherapy check-ups</li>
              </ul>
            </li>
            <li><strong>Cardiovascular Health</strong>
              <ul>
                <li>Build physical activity into your routine</li>
                <li>Use breaks for short walks</li>
                <li>Monitor blood pressure regularly</li>
                <li>Consider standing during breaks rather than sitting</li>
              </ul>
            </li>
            <li><strong>Nutrition</strong>
              <ul>
                <li>Prepare healthy meals and snacks in advance</li>
                <li>Limit fast food consumption while working</li>
                <li>Stay hydrated throughout your shift</li>
                <li>Be mindful of caffeine intake</li>
              </ul>
            </li>
          </ul>
          
          <h3>Mental Wellbeing</h3>
          <p>Strategies for maintaining mental health:</p>
          <ul>
            <li><strong>Stress Management</strong>
              <ul>
                <li>Develop techniques for handling difficult situations</li>
                <li>Take regular breaks during long shifts</li>
                <li>Practice stress-reduction techniques such as deep breathing</li>
                <li>Separate work issues from personal life</li>
              </ul>
            </li>
            <li><strong>Fatigue Management</strong>
              <ul>
                <li>Ensure adequate sleep between shifts</li>
                <li>Recognize signs of fatigue and respond appropriately</li>
                <li>Plan shifts to avoid overwork</li>
                <li>Take short power naps during breaks if needed</li>
              </ul>
            </li>
            <li><strong>Social Connection</strong>
              <ul>
                <li>Maintain relationships with family and friends</li>
                <li>Connect with other SPSV operators for peer support</li>
                <li>Join industry associations or online communities</li>
                <li>Ensure time for social activities outside work</li>
              </ul>
            </li>
          </ul>
          
          <h3>Work-Life Balance</h3>
          <p>Maintain balance through:</p>
          <ul>
            <li>Setting clear boundaries on working hours</li>
            <li>Scheduling regular days off and vacation time</li>
            <li>Making time for family, friends, and personal interests</li>
            <li>Being realistic about income goals versus quality of life</li>
            <li>Planning shifts around important personal events</li>
          </ul>
          
          <p>Remember that your health is your most important asset. Investing time in maintaining your physical and mental wellbeing will enable a longer, more satisfying career and improve your service quality.</p>
        `,
        keyPoints: [
          "Use ergonomic supports and proper posture to prevent back issues",
          "Prepare healthy meals and stay hydrated during shifts",
          "Develop strategies for managing stress and fatigue",
          "Maintain social connections and a healthy work-life balance"
        ]
      },
      {
        title: "Long-term Career Planning",
        content: `
          <p>A career in the SPSV industry can take many paths, from part-time work to business ownership. Thoughtful long-term planning can help you achieve your personal and professional goals within the industry.</p>
          
          <h3>Career Progression Paths</h3>
          <p>Consider these potential career trajectories:</p>
          <ul>
            <li><strong>Owner-Driver</strong> - Operating your own vehicle
              <ul>
                <li>Starting with a single vehicle</li>
                <li>Building a customer base</li>
                <li>Developing a specialization</li>
                <li>Optimizing operation for profitability</li>
              </ul>
            </li>
            <li><strong>Fleet Owner</strong> - Expanding to multiple vehicles
              <ul>
                <li>Acquiring additional SPSV licences</li>
                <li>Hiring and managing drivers</li>
                <li>Developing fleet management systems</li>
                <li>Building a company brand</li>
              </ul>
            </li>
            <li><strong>Industry Specialist</strong> - Developing expertise
              <ul>
                <li>Specialized transport services</li>
                <li>Training and education roles</li>
                <li>Consultancy and advisory services</li>
                <li>Industry representation</li>
              </ul>
            </li>
            <li><strong>Related Business Areas</strong> - Expanding beyond driving
              <ul>
                <li>Dispatch services</li>
                <li>SPSV industry suppliers</li>
                <li>Transport management</li>
                <li>Tourism and hospitality connections</li>
              </ul>
            </li>
          </ul>
          
          <h3>Setting Career Goals</h3>
          <p>Develop a structured approach to planning:</p>
          <ul>
            <li>Set clear short-term (1 year), medium-term (3-5 years), and long-term goals</li>
            <li>Identify the skills, qualifications, and resources needed for each goal</li>
            <li>Create a timeline with specific milestones</li>
            <li>Review and adjust your plan regularly</li>
            <li>Seek mentorship from experienced industry professionals</li>
            <li>Stay informed about industry trends and developments</li>
          </ul>
          
          <h3>Financial Planning for Career Development</h3>
          <p>Support your career goals with sound financial planning:</p>
          <ul>
            <li>Build savings for future investments (vehicles, licences, etc.)</li>
            <li>Develop a retirement strategy appropriate for self-employment</li>
            <li>Consider insurance products that protect your income</li>
            <li>Plan for the eventual sale or transfer of your business</li>
            <li>Seek professional financial advice for major decisions</li>
          </ul>
          
          <p>Whether you see the SPSV industry as a short-term opportunity or a lifelong career, having a clear plan will help you maximize the benefits and opportunities available to you.</p>
        `,
        keyPoints: [
          "Consider various career paths from owner-driver to fleet owner",
          "Set clear short, medium, and long-term career goals",
          "Develop financial plans to support your career development",
          "Stay informed about industry trends and opportunities"
        ]
      }
    ],
    vehicleSpecificContent: {
      "taxi": {
        additionalContent: `
          <p>Taxi operators have specific career development considerations:</p>
          
          <ul>
            <li>Understand the value and transferability of taxi licences in your planning, as these can represent a significant asset</li>
            <li>Consider specializing in specific ranks or areas where you can build regular clientele</li>
            <li>Explore opportunities with taxi companies that might offer benefits like guaranteed shifts or corporate accounts</li>
            <li>Investigate the potential for wheelchair accessible taxi operation, which may have different demand patterns and regulatory advantages</li>
            <li>Stay informed about local authority policies regarding taxi numbers and accessibility requirements</li>
          </ul>
          
          <p>The taxi segment offers particular opportunities for building a regular customer base through visibility at ranks and during street work, which can be developed into a valuable business asset.</p>
        `,
        additionalKeyPoints: [
          "Understand taxi licence value as a significant business asset",
          "Develop expertise in specific ranks or areas",
          "Consider opportunities with established taxi companies",
          "Explore wheelchair accessible taxi operation potential"
        ]
      },
      "limousine": {
        additionalContent: `
          <p>Limousine operators have unique career path opportunities:</p>
          
          <ul>
            <li>Focus on building relationships with event planners, luxury hotels, and corporate travel departments</li>
            <li>Consider acquiring specialised vehicles for different types of events (weddings, corporate travel, tours)</li>
            <li>Develop a progression plan from standard limousine to ultra-luxury or specialised vehicle services</li>
            <li>Explore opportunities to combine limousine services with event planning or luxury tourism experiences</li>
            <li>Build a personal brand as a luxury transport expert rather than just a driver</li>
            <li>Consider offering chauffeur training to expand your business into driver provision for privately-owned luxury vehicles</li>
          </ul>
          
          <p>The limousine segment offers significant opportunities for brand development and premium service specialization that can command higher rates and develop into a sophisticated business operation.</p>
        `,
        additionalKeyPoints: [
          "Build relationships with luxury hotels and event planners",
          "Develop a progression plan to ultra-luxury services",
          "Combine limousine services with other luxury experiences",
          "Consider chauffeur training as a business expansion"
        ]
      }
    }
  }
};

// Test Time Limits (in minutes)
export const TEST_TIME_LIMITS = {
  industry_knowledge: 30,
  area_knowledge: 45,
  rules_regulations: 30,
  mock_exam: 120
};

// License Durations
export const LICENSE_DURATIONS = [
  { id: 1, name: '1 Year' },
  { id: 3, name: '3 Years' },
  { id: 5, name: '5 Years' },
];

// License Fees (in EUR)
export const LICENSE_FEES = {
  driver: {
    new: 250,
    renewal: 200,
  },
  vehicle: {
    taxi: 150,
    wheelchair_accessible_taxi: 75,
    hackney: 150,
    wheelchair_accessible_hackney: 75,
    local_area_hackney: 50,
    limousine: 150,
  },
  services: {
    vehicle_suitability: 200,
    meter_verification: 55,
    driver_entry_test: 90,
  }
};

// Application price
export const PRICING_PLANS = {
  BASIC: {
    name: "Basic",
    price: 9.99,
    duration: 30, // days
    description: "Complete SPSV Training Package for 30 days access"
  },
  STANDARD: {
    name: "Standard",
    price: 19.99,
    duration: 60, // days
    description: "Complete SPSV Training Package for 60 days access"
  },
  PREMIUM: {
    name: "Premium",
    price: 49.99,
    duration: 365, // 12 months (365 days)
    description: "Complete SPSV Training Package for 12 months access"
  }
};

export const APPLICATION_PRICE = PRICING_PLANS.BASIC.price; // Default price for backward compatibility

// Vehicle-specific requirements and fees
export const VEHICLE_REQUIREMENTS = {
  taxi: {
    initialLicenseFee: 150,
    renewalFee: 150,
    suitabilityTestFee: 45,
    suitabilityFrequency: 12, // months
    maxAge: 10, // years
    meterCost: 55, // Taximeter verification fee
    vehicleRequirements: [
      "Must be less than 10 years old",
      "Minimum of 4 passenger doors",
      "Minimum interior space dimensions per NTA specifications",
      "Working taximeter calibrated by Legal Metrology Service",
      "Roof sign displaying 'TAXI/TACSAÍ'",
      "Tamper-proof roof sign light",
      "Distinctive identification including roof sign and door signage",
      "Valid NCT certificate",
      "Comprehensive insurance for carrying passengers for reward"
    ],
    acceptableVehicles: [
      "Toyota Avensis",
      "Toyota Prius",
      "Toyota Corolla",
      "VW Passat",
      "Skoda Octavia",
      "Ford Mondeo",
      "Skoda Superb",
      "Hyundai i40",
      "Kia Optima",
      "Peugeot 508"
    ]
  },
  wheelchair_accessible_taxi: {
    initialLicenseFee: 75, // 50% discount
    renewalFee: 75,
    suitabilityTestFee: 45,
    suitabilityFrequency: 12, // months
    maxAge: 10, // years
    meterCost: 55, // Taximeter verification fee
    vehicleRequirements: [
      "Must be less than 10 years old",
      "Must meet specific requirements for wheelchair access",
      "Compliant with European safety requirements",
      "Minimum door dimensions for wheelchair access",
      "Appropriate wheelchair restraints and seatbelts",
      "Suitable ramp or lift mechanism",
      "Taximeter required",
      "Valid NCT certificate",
      "Comprehensive insurance for carrying passengers for reward"
    ],
    acceptableVehicles: [
      "Volkswagen Caddy Maxi Life",
      "Mercedes-Benz V-Class",
      "Peugeot Traveller",
      "Citroën SpaceTourer",
      "Ford Tourneo Custom",
      "Renault Trafic Passenger",
      "LEVC TX",
      "Toyota Proace Verso",
      "Kia Carnival",
      "Vauxhall/Opel Vivaro Life"
    ]
  },
  hackney: {
    initialLicenseFee: 150,
    renewalFee: 150,
    suitabilityTestFee: 45,
    suitabilityFrequency: 12, // months
    maxAge: 10, // years
    vehicleRequirements: [
      "Must be less than 10 years old",
      "Minimum of 4 passenger doors",
      "Minimum interior space dimensions per NTA specifications",
      "No taximeter permitted",
      "No external markings identifying as SPSV",
      "Valid NCT certificate",
      "Comprehensive insurance for carrying passengers for reward"
    ],
    acceptableVehicles: [
      "Toyota Avensis",
      "Toyota Corolla",
      "VW Passat",
      "Skoda Octavia",
      "Ford Mondeo",
      "Skoda Superb",
      "Hyundai i40",
      "Kia Optima",
      "Peugeot 508",
      "Audi A4"
    ]
  },
  wheelchair_accessible_hackney: {
    initialLicenseFee: 75, // 50% discount
    renewalFee: 75,
    suitabilityTestFee: 45,
    suitabilityFrequency: 12, // months
    maxAge: 10, // years
    vehicleRequirements: [
      "Must be less than 10 years old",
      "Must meet specific requirements for wheelchair access",
      "Compliant with European safety requirements",
      "Minimum door dimensions for wheelchair access",
      "Appropriate wheelchair restraints and seatbelts",
      "Suitable ramp or lift mechanism",
      "No taximeter permitted",
      "Valid NCT certificate",
      "Comprehensive insurance for carrying passengers for reward"
    ],
    acceptableVehicles: [
      "Volkswagen Caddy Maxi Life",
      "Mercedes-Benz V-Class",
      "Peugeot Traveller",
      "Citroën SpaceTourer",
      "Ford Tourneo Custom",
      "Renault Trafic Passenger",
      "Toyota Proace Verso",
      "Kia Carnival",
      "Vauxhall/Opel Vivaro Life",
      "Peugeot Rifter"
    ]
  },
  limousine: {
    initialLicenseFee: 1000, // One-off fee
    renewalFee: 150,
    suitabilityTestFee: 45,
    suitabilityFrequency: 6, // months
    maxAge: 15, // years
    vehicleRequirements: [
      "Can be over 10 years old if maintained to manufacturer specifications",
      "Must be evidently suited for ceremonial occasions or corporate clients",
      "Stretched limousines must be certified for safety by recognised authority",
      "Minimum interior space dimensions per NTA specifications",
      "Seating facing forward or backward only",
      "Luxury features such as premium upholstery or interior fittings",
      "No taximeter permitted",
      "Valid NCT certificate or equivalent",
      "Comprehensive insurance for carrying passengers for reward"
    ],
    acceptableVehicles: [
      "Lincoln Town Car (stretched)",
      "Cadillac Escalade (stretched)",
      "Chrysler 300C (stretched)",
      "Mercedes-Benz S-Class",
      "BMW 7 Series",
      "Audi A8",
      "Bentley Continental",
      "Rolls-Royce Phantom",
      "Jaguar XJ",
      "Tesla Model S"
    ]
  },
  local_area_hackney: {
    initialLicenseFee: 50,
    renewalFee: 50,
    suitabilityTestFee: 45,
    suitabilityFrequency: 12, // months
    maxAge: 10, // years
    vehicleRequirements: [
      "Must be less than 10 years old",
      "Minimum of 4 passenger doors",
      "Operation limited to designated rural area (specific to licence)",
      "Maximum 7-seater vehicle",
      "No taximeter permitted",
      "Simple tamper-proof identification disc",
      "Valid NCT certificate",
      "Comprehensive insurance for carrying passengers for reward"
    ],
    acceptableVehicles: [
      "Toyota Avensis",
      "Toyota Corolla",
      "VW Passat",
      "Skoda Octavia",
      "Ford Mondeo",
      "Skoda Superb",
      "Hyundai i40",
      "Kia Optima",
      "Peugeot 508",
      "Ford Focus"
    ]
  }
};
