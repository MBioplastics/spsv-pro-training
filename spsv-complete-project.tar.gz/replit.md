# SPSV Pro Training - Irish Taxi Driver Certification Platform

## Overview

SPSV Pro Training is a comprehensive SaaS platform designed for professional drivers in Ireland seeking Small Public Service Vehicle (SPSV) certification. The application provides interactive training modules, practice examinations, and county-specific area knowledge tests for all 26 Irish counties. Built as a web-first React application with mobile app capabilities through Capacitor, it serves taxi drivers, hackney operators, limousine service providers, and other professional transport operators preparing for their SPSV certification exams.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **UI Library**: Radix UI components with shadcn/ui for consistent, accessible interface elements
- **Styling**: Tailwind CSS for utility-first styling with custom design system variables
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Client-side routing with protected routes for authenticated content
- **PWA Features**: Progressive Web App capabilities with service worker, offline functionality, and install prompts

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for full-stack type safety
- **API Design**: RESTful endpoints with structured JSON responses
- **Middleware**: CORS handling, JSON parsing, and error handling middleware
- **File Structure**: Modular routing with separate route handlers for different features

### Mobile Application
- **Framework**: Capacitor for cross-platform mobile deployment
- **Target Platforms**: Android (Google Play Store ready) and iOS capabilities
- **Build System**: Vite for fast development and optimized production builds
- **Native Features**: Splash screens, status bar customization, keyboard handling, and push notifications

### Data Storage Solutions
- **Primary Database**: PostgreSQL hosted on Neon for production scalability
- **ORM**: Drizzle ORM for type-safe database operations and migrations
- **Schema Management**: Centralized schema definitions in TypeScript with automated migrations
- **Caching**: Client-side caching through TanStack Query for improved performance

### Authentication and Authorization
- **Session Management**: Server-side session handling with secure cookie storage
- **Route Protection**: Client-side route guards for premium content access
- **User Roles**: Differentiated access levels for free and premium subscribers
- **Security**: HTTPS enforcement, secure headers, and input validation

## External Dependencies

### Payment Processing
- **Stripe**: Complete payment infrastructure for subscription management
- **Integration**: React Stripe.js for frontend payment forms
- **Webhooks**: Server-side webhook handling for payment confirmations
- **Products**: Multiple subscription tiers (30-day, 60-day, and 12-month plans)

### Email Services
- **SendGrid**: Transactional email delivery for user communications
- **Templates**: HTML email templates for registration, payment confirmations, and admin notifications
- **Webhook Integration**: Stripe webhook handler for purchase notifications sends admin alerts
- **Admin Notifications**: Automatic email alerts to support@spsvprotraining.ie for all customer purchases
- **Configuration**: Domain verification required for production email delivery

### Mobile App Deployment
- **Technology**: Capacitor for cross-platform mobile deployment (not Expo - Expo is for React Native, not web-based React apps)
- **Google Play Store**: Android app bundle (AAB) configuration with production signing keystore
- **GitHub Actions**: Automated APK/AAB building pipeline for continuous deployment via cloud builds
- **Signing**: Production keystore configured with credentials for Play Store submission
- **App ID**: ie.spsvprotraining.app configured and ready for store submission
- **Build Process**: Cloud-based builds resolve local Java version compatibility issues

### Development Tools
- **Build System**: Vite for fast development server and optimized production builds
- **Database Migrations**: Drizzle Kit for schema management and database migrations
- **Code Quality**: TypeScript compiler for static type checking
- **Deployment**: Automated build processes with environment-specific configurations

### Content Management
- **Training Data**: Static JSON files containing SPSV examination content and county-specific information
- **NTA Monitoring**: Automated system for tracking National Transport Authority regulation updates
- **SEO Optimization**: Dynamic meta tags, sitemap generation, and structured data markup